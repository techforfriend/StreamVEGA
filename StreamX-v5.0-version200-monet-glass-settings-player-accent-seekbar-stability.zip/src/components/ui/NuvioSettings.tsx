import React from 'react';
import {Pressable, View} from 'react-native';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import Animated, {FadeInDown} from 'react-native-reanimated';
import {useM3Colors} from '../../theme/M3PaletteContext';
import {withAlpha} from '../../theme/glass';
import AppText from './Text';

type NuvioIcon = React.ComponentProps<typeof MaterialCommunityIcons>['name'];

export interface NuvioRowProps {
  title: string;
  description?: string;
  icon: NuvioIcon;
  onPress?: () => void;
  trailing?: React.ReactNode;
  divider?: boolean;
  disabled?: boolean;
  compact?: boolean;
}

export const NuvioRow = ({
  title,
  description,
  icon,
  onPress,
  trailing,
  divider = true,
  disabled = false,
  compact = false,
}: NuvioRowProps) => {
  const colors = useM3Colors();
  const content = (
    <View
      style={{
        minHeight: compact ? (description ? 58 : 50) : (description ? 70 : 58),
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 12,
        paddingVertical: compact ? 4 : 7,
        borderBottomWidth: divider ? 1 : 0,
        borderBottomColor: withAlpha(colors.primary, 0.17),
        opacity: disabled ? 0.5 : 1,
      }}>
      <View
        style={{
          width: 40,
          height: 40,
          borderRadius: 13,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: withAlpha(colors.primary, 0.18),
        }}>
        <MaterialCommunityIcons name={icon} size={21} color={colors.primary} />
      </View>
      <View style={{flex: 1, minWidth: 0, marginLeft: 11, marginRight: 6}}>
        <AppText
          role="bodyLargeEmphasized"
          numberOfLines={2}
          style={{color: colors.onSurface}}>
          {title}
        </AppText>
        {description ? (
          <AppText
            role="bodySmall"
            numberOfLines={2}
            style={{color: colors.onSurfaceVariant, marginTop: 1}}>
            {description}
          </AppText>
        ) : null}
      </View>
      {trailing}
    </View>
  );

  return onPress && !disabled ? (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      android_ripple={{color: withAlpha(colors.primary, 0.16)}}>
      {content}
    </Pressable>
  ) : (
    content
  );
};

export const NuvioSection = ({
  title,
  children,
  delay = 0,
}: {
  title: string;
  children: React.ReactNode;
  delay?: number;
}) => {
  const colors = useM3Colors();
  return (
    <Animated.View entering={FadeInDown.delay(delay).duration(160)}>
      <View style={{marginBottom: 16}}>
        <AppText
          role="labelMediumEmphasized"
          style={{
            color: colors.primary,
            letterSpacing: 1.25,
            marginLeft: 2,
            marginBottom: 6,
          }}>
          {title.toUpperCase()}
        </AppText>
        <View
          style={{
            backgroundColor: withAlpha(colors.surfaceContainerHigh, 0.74),
            borderRadius: 24,
            borderWidth: 1,
            borderColor: withAlpha(colors.primary, 0.32),
            overflow: 'hidden',
            shadowColor: colors.primary,
            shadowOffset: {width: 0, height: 3},
            shadowOpacity: 0.07,
            shadowRadius: 10,
            elevation: 2,
          }}>
          <View
            pointerEvents="none"
            style={{
              position: 'absolute',
              top: 0,
              left: 14,
              right: 14,
              height: 1,
              backgroundColor: withAlpha(colors.primary, 0.42),
              zIndex: 1,
            }}
          />
          {children}
        </View>
      </View>
    </Animated.View>
  );
};

import React, {ReactNode} from 'react';
import {StyleSheet, View} from 'react-native';
import AppText from './Text';
import {useM3Colors} from '../../theme/M3PaletteContext';
import {withAlpha} from '../../theme/glass';

interface SettingsSectionProps {
  title: string;
  children: ReactNode;
}

const SettingsSection = ({title, children}: SettingsSectionProps) => {
  const colors = useM3Colors();
  return (
    <View style={{marginBottom: 12}}>
      <AppText
        role="labelMediumEmphasized"
        style={{
          color: colors.primary,
          letterSpacing: 1.25,
          marginLeft: 2,
          marginBottom: 6,
        }}>
        {title.toUpperCase()}
      </AppText>
      <View
        style={{
          backgroundColor: withAlpha(colors.surfaceContainerHigh, 0.74),
          borderRadius: 22,
          borderWidth: StyleSheet.hairlineWidth + 0.5,
          borderColor: withAlpha(colors.primary, 0.36),
          overflow: 'hidden',
          shadowColor: colors.primary,
          shadowOffset: {width: 0, height: 3},
          shadowOpacity: 0.08,
          shadowRadius: 10,
          elevation: 2,
        }}>
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            top: 0,
            left: 14,
            right: 14,
            height: 1,
            backgroundColor: withAlpha(colors.primary, 0.48),
            zIndex: 1,
          }}
        />
        {children}
      </View>
    </View>
  );
};

export default SettingsSection;

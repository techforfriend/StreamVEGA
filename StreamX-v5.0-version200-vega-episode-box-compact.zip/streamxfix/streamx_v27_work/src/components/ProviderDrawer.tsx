import {View, Text, ScrollView, TouchableOpacity, StyleSheet} from 'react-native';
import {BlurView} from 'expo-blur';
import React from 'react';
import useContentStore from '../lib/zustand/contentStore';
import {MaterialIcons} from '@expo/vector-icons';
import {useM3Colors} from '../theme/M3PaletteContext';
import {ContentSource} from '../lib/providers/contentSourceTypes';

const ProviderRow = ({
  item,
  selected,
  primary,
  onSelect,
}: {
  item: ContentSource;
  selected: boolean;
  primary: string;
  onSelect: () => void;
}) => (
  <TouchableOpacity
    onPress={onSelect}
    activeOpacity={0.78}
    style={{
      alignItems: 'center',
      backgroundColor: selected ? 'rgba(255,255,255,0.095)' : 'transparent',
      borderColor: selected ? 'rgba(255,255,255,0.17)' : 'transparent',
      borderRadius: 18,
      borderWidth: StyleSheet.hairlineWidth,
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginHorizontal: 5,
      marginVertical: 3,
      paddingHorizontal: 14,
      paddingVertical: 15,
    }}>
    <View className="flex-row items-center flex-1">
      <MaterialIcons
        name="movie"
        size={20}
        color={selected ? primary : '#888'}
      />
      <Text
        numberOfLines={1}
        className={`ml-3 text-base flex-1 ${
          selected ? 'text-white font-medium' : 'text-gray-400'
        }`}>
        {item.display_name.replace(/^Vega · /, '')}
      </Text>
    </View>
    {selected && <MaterialIcons name="check" size={20} color={primary} />}
  </TouchableOpacity>
);

const ProviderSection = ({
  title,
  providers,
  provider,
  primary,
  onSelect,
}: {
  title: string;
  providers: ContentSource[];
  provider: ContentSource;
  primary: string;
  onSelect: (item: ContentSource) => void;
}) => {
  if (providers.length === 0) return null;

  return (
    <View className="mb-3">
      <View className="px-4 pt-3 pb-1">
        <Text className="text-gray-400 text-xs font-semibold uppercase tracking-wider">
          {title}
        </Text>
      </View>
      {providers.map(item => (
        <ProviderRow
          key={item.value}
          item={item}
          selected={provider.value === item.value}
          primary={primary}
          onSelect={() => onSelect(item)}
        />
      ))}
    </View>
  );
};

const ProviderDrawer = ({onClose}: {onClose: () => void}) => {
  const {provider, setProvider, installedProviders} = useContentStore(
    state => state,
  );
  const primary = useM3Colors().primary;

  const stremioProviders = installedProviders.filter(
    item => !item.value.startsWith('vega:'),
  );
  const vegaProviders = installedProviders.filter(item =>
    item.value.startsWith('vega:'),
  );

  const handleSelect = (item: ContentSource) => {
    setProvider(item);
    onClose();
  };

  return (
    <View className="flex-1" style={{backgroundColor: 'rgba(7,7,7,0.30)', overflow: 'hidden'}}>
      <BlurView
        pointerEvents="none"
        intensity={55}
        tint="dark"
        style={StyleSheet.absoluteFillObject}
      />
      <View className="mt-10 px-4 pb-4 border-b border-white/10" style={{paddingTop: 4}}>
        <Text className="text-white text-2xl font-bold">Select Add-on</Text>
        <Text className="text-gray-400 mt-1 text-sm">Content source</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} className="flex-1 px-2">
        <ProviderSection
          title="Stremio Add-ons"
          providers={stremioProviders}
          provider={provider}
          primary={primary}
          onSelect={handleSelect}
        />

        <ProviderSection
          title="Vega Plugins"
          providers={vegaProviders}
          provider={provider}
          primary={primary}
          onSelect={handleSelect}
        />

        <View className="h-16" />
      </ScrollView>
    </View>
  );
};

export default ProviderDrawer;

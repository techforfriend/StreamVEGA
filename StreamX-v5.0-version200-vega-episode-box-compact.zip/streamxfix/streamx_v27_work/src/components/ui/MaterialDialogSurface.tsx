import {BasicAlertDialog, Host, RNHostView} from '@expo/ui/jetpack-compose';
import React from 'react';
import {StyleSheet, View, ViewStyle} from 'react-native';
import {BlurView} from 'expo-blur';
import {useM3HostTheme} from '../../theme/M3PaletteContext';

interface MaterialDialogSurfaceProps {
  visible: boolean;
  children: React.ReactNode;
  dismissible?: boolean;
  onDismiss: () => void;
  style?: ViewStyle;
}

const MaterialDialogSurface = ({
  visible,
  children,
  dismissible = true,
  onDismiss,
  style,
}: MaterialDialogSurfaceProps) => {
  const hostTheme = useM3HostTheme();

  if (!visible) {
    return null;
  }

  return (
    <View
      pointerEvents="box-none"
      style={{left: 0, position: 'absolute', top: 0, zIndex: 1000}}>
      <Host matchContents {...hostTheme}>
        <BasicAlertDialog
          onDismissRequest={() => {
            if (dismissible) {
              onDismiss();
            }
          }}>
          <RNHostView matchContents>
            <View
              style={[
                {
                  backgroundColor: 'rgba(24,24,24,0.50)',
                  borderColor: 'rgba(255,255,255,0.19)',
                  borderRadius: 28,
                  borderWidth: StyleSheet.hairlineWidth,
                  maxWidth: 420,
                  overflow: 'hidden',
                  padding: 24,
                  position: 'relative',
                  shadowColor: '#000000',
                  shadowOffset: {width: 0, height: 8},
                  shadowOpacity: 0.32,
                  shadowRadius: 20,
                  elevation: 16,
                  width: 340,
                },
                style,
              ]}>
              <BlurView
                pointerEvents="none"
                intensity={62}
                tint="dark"
                style={StyleSheet.absoluteFillObject}
              />
              {children}
            </View>
          </RNHostView>
        </BasicAlertDialog>
      </Host>
    </View>
  );
};

export default MaterialDialogSurface;

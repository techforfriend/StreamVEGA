import React, {useCallback, useEffect, useMemo, useState} from 'react';
import {ActivityIndicator, Alert, FlatList, Image, Modal, RefreshControl, ScrollView, Switch, TextInput, TouchableOpacity, View} from 'react-native';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {MaterialCommunityIcons} from '@expo/vector-icons';
import {SettingsStackParamList} from '../../App';
import AppText from '../../components/ui/Text';
import IconButton from '../../components/ui/IconButton';
import CompactSwitch from '../../components/ui/CompactSwitch';
import {useM3Colors} from '../../theme/M3PaletteContext';
import useTabBarScrollVisibility from '../../lib/hooks/useTabBarScrollVisibility';
import vegaPluginManager, {VegaPluginManifest} from '../../lib/services/VegaPluginManager';
import useContentStore from '../../lib/zustand/contentStore';
import type {SettingsField} from '../../lib/providers/types';
import {testProvider} from '../../lib/services/providerDiagnostics';

type Props = NativeStackScreenProps<SettingsStackParamList, 'VegaPlugins'>;
type SettingsTarget = {plugin: VegaPluginManifest; schema: SettingsField[]; values: Record<string, unknown>} | null;

const cardStyle = {borderRadius: 24, borderWidth: 1, padding: 16, marginBottom: 14} as const;

const VegaPlugins = ({navigation}: Props) => {
  const colors = useM3Colors();
  const tabBarScroll = useTabBarScrollVisibility();
  const syncProviders = useContentStore(state => state.syncStremioProviders);
  const [source, setSource] = useState('');
  const [available, setAvailable] = useState<VegaPluginManifest[]>([]);
  const [installed, setInstalled] = useState<VegaPluginManifest[]>(vegaPluginManager.listInstalled());
  const [refreshing, setRefreshing] = useState(false);
  const [testingKey, setTestingKey] = useState<string | null>(null);
  const [settingsTarget, setSettingsTarget] = useState<SettingsTarget>(null);
  const [settingsLoading, setSettingsLoading] = useState(false);
  const [settingsSaving, setSettingsSaving] = useState(false);

  const reloadInstalled = useCallback(() => {
    setInstalled(vegaPluginManager.listInstalled());
    syncProviders();
  }, [syncProviders]);

  const refresh = useCallback(async (input?: string) => {
    setRefreshing(true);
    try {
      const list = await vegaPluginManager.fetchAvailable(input ?? source);
      setAvailable(list);
      if ((input ?? source).trim()) setSource('');
      reloadInstalled();
    } catch (error) {
      Alert.alert('Vega Providers', error instanceof Error ? error.message : 'Unable to load provider manifest.');
    } finally {
      setRefreshing(false);
    }
  }, [reloadInstalled, source]);

  useEffect(() => {
    const saved = vegaPluginManager.getSource();
    if (saved) void vegaPluginManager.fetchAvailable().then(setAvailable).catch(error => Alert.alert('Vega Providers', error instanceof Error ? error.message : 'Unable to load providers.'));
  }, []);

  const install = async (plugin: VegaPluginManifest) => {
    try {
      await vegaPluginManager.install(plugin);
      reloadInstalled();
      Alert.alert('Installed', `${plugin.display_name} is ready to use.`);
    } catch (error) {
      Alert.alert('Install failed', error instanceof Error ? error.message : 'Unable to install provider.');
    }
  };

  const remove = (plugin: VegaPluginManifest) => {
    Alert.alert('Uninstall provider?', `Remove ${plugin.display_name} and its installed modules?`, [
      {text: 'Cancel', style: 'cancel'},
      {text: 'Uninstall', style: 'destructive', onPress: () => {
        vegaPluginManager.remove(plugin.value, plugin.source.author);
        vegaPluginManager.clearProviderStorage(plugin.value);
        reloadInstalled();
        setAvailable(items => items.map(item => item.value === plugin.value && item.source.author === plugin.source.author ? {...item, installed: false} : item));
      }},
    ]);
  };

  const toggle = (plugin: VegaPluginManifest) => {
    vegaPluginManager.setEnabled(plugin.value, !vegaPluginManager.isEnabled(plugin.value));
    reloadInstalled();
  };

  const runTest = async (plugin: VegaPluginManifest) => {
    const key = `${plugin.source.author}:${plugin.value}`;
    setTestingKey(key);
    try {
      const result = await testProvider(`vega:${plugin.value}`);
      Alert.alert('Provider test passed', `${plugin.display_name}\nCatalog: ${result.catalog.title}\nContent: ${result.metadata.title}\nStreams: ${result.streams.length}`);
    } catch (error) {
      Alert.alert('Provider test failed', error instanceof Error ? error.message : 'Provider test failed. Check the source or provider logs.');
    } finally {
      setTestingKey(null);
    }
  };

  const openSettings = async (plugin: VegaPluginManifest) => {
    setSettingsLoading(true);
    try {
      const schema = await vegaPluginManager.getSettingsSchema(plugin.value);
      const values = await vegaPluginManager.getSettingsValues(plugin.value, schema);
      setSettingsTarget({plugin, schema, values});
      if (!schema.length) Alert.alert('Provider settings', `${plugin.display_name} does not expose any settings fields.`);
    } catch (error) {
      Alert.alert('Settings unavailable', error instanceof Error ? error.message : 'Unable to load provider settings.');
    } finally {
      setSettingsLoading(false);
    }
  };

  const updateSetting = (key: string, value: unknown) => setSettingsTarget(current => current ? {...current, values: {...current.values, [key]: value}} : current);
  const saveSettings = async () => {
    if (!settingsTarget) return;
    setSettingsSaving(true);
    try {
      await vegaPluginManager.saveSettingsValues(settingsTarget.plugin.value, settingsTarget.values);
      const name = settingsTarget.plugin.display_name;
      setSettingsTarget(null);
      Alert.alert('Settings saved', `${name} settings have been saved and will be used by its next requests.`);
    } catch (error) {
      Alert.alert('Save failed', error instanceof Error ? error.message : 'Unable to save provider settings.');
    } finally {
      setSettingsSaving(false);
    }
  };

  const installedIds = useMemo(() => new Set(installed.map(item => `${item.source.author}:${item.value}`)), [installed]);
  const renderSettingsField = (field: SettingsField) => {
    if (!settingsTarget) return null;
    const value = settingsTarget.values[field.key];
    const inputStyle = {borderRadius: 12, borderWidth: 1, borderColor: colors.outlineVariant, paddingHorizontal: 12, paddingVertical: 10, color: colors.onSurface, backgroundColor: colors.surfaceContainerHighest, marginTop: 8} as const;
    return <View key={field.key} style={{marginBottom: 18}}>
      <AppText role="titleSmall" style={{color: colors.onSurface}}>{field.label}</AppText>
      {!!field.description && <AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 3}}>{field.description}</AppText>}
      {field.type === 'toggle' ? <View style={{alignItems: 'flex-start', marginTop: 8}}><Switch value={Boolean(value)} onValueChange={next => updateSetting(field.key, next)} /></View> : null}
      {field.type === 'text' ? <TextInput value={String(value ?? '')} onChangeText={next => updateSetting(field.key, next)} placeholder={field.placeholder || field.label} placeholderTextColor={colors.onSurfaceVariant} autoCapitalize="none" autoCorrect={false} style={inputStyle} /> : null}
      {field.type === 'number' ? <TextInput value={String(value ?? '')} onChangeText={raw => { const parsed = Number(raw); if (raw.trim() === '') updateSetting(field.key, ''); else if (Number.isFinite(parsed)) updateSetting(field.key, Math.min(field.max ?? Infinity, Math.max(field.min ?? -Infinity, parsed))); }} keyboardType="numeric" style={inputStyle} placeholder={field.label} placeholderTextColor={colors.onSurfaceVariant} /> : null}
      {field.type === 'select' || field.type === 'multiselect' ? <View style={{marginTop: 8, gap: 8}}>{(field.options || []).map(option => {
        const selected = field.type === 'multiselect' ? (Array.isArray(value) && value.includes(option.value)) : value === option.value;
        return <TouchableOpacity key={option.value} onPress={() => updateSetting(field.key, field.type === 'multiselect' ? (selected ? (Array.isArray(value) ? value.filter(item => item !== option.value) : []) : [...(Array.isArray(value) ? value : []), option.value]) : option.value)} style={{flexDirection: 'row', alignItems: 'center', padding: 12, borderRadius: 12, backgroundColor: selected ? colors.secondaryContainer : colors.surfaceContainerHighest}}><MaterialCommunityIcons name={selected ? (field.type === 'multiselect' ? 'checkbox-marked' : 'radiobox-marked') : (field.type === 'multiselect' ? 'checkbox-blank-outline' : 'radiobox-blank')} size={20} color={selected ? colors.primary : colors.onSurfaceVariant} /><AppText role="bodyMedium" style={{color: colors.onSurface, marginLeft: 10}}>{option.label}</AppText></TouchableOpacity>;
      })}</View> : null}
    </View>;
  };

  return <View style={{flex: 1, backgroundColor: colors.background}}>
    <View style={{flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingTop: 18, paddingBottom: 10}}>
      <IconButton icon="arrow-left" label="Back" buttonSize={46} onPress={() => navigation.goBack()} contentColor={colors.onSurface} />
      <View style={{flex: 1, marginLeft: 12}}><AppText role="headlineLargeEmphasized" style={{color: colors.onBackground, fontSize: 30}}>Providers</AppText><AppText role="bodyMedium" style={{color: colors.onSurfaceVariant}}>Install and test Vega streaming sources</AppText></View>
      <IconButton icon="refresh" label="Refresh providers" buttonSize={46} onPress={() => void refresh()} disabled={refreshing} contentColor={colors.primary} />
    </View>
    <FlatList
      data={available}
      keyExtractor={item => `${item.source.author}:${item.value}`}
      onScroll={tabBarScroll.onScroll} onScrollBeginDrag={tabBarScroll.onScrollBeginDrag} onScrollEndDrag={tabBarScroll.onScrollEndDrag} onMomentumScrollBegin={tabBarScroll.onMomentumScrollBegin} onMomentumScrollEnd={tabBarScroll.onMomentumScrollEnd} scrollEventThrottle={32}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void refresh()} />}
      contentContainerStyle={{paddingHorizontal: 18, paddingBottom: 138}}
      ListHeaderComponent={<View>
        <AppText role="titleMedium" style={{color: colors.onSurfaceVariant, marginTop: 16, marginBottom: 8}}>Provider source</AppText>
        <View style={{flexDirection: 'row', gap: 10, marginBottom: 28}}>
          <View style={{flex: 1, flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: colors.outlineVariant, backgroundColor: colors.surfaceContainerHighest, borderRadius: 24, paddingHorizontal: 14, minHeight: 78}}>
            <MaterialCommunityIcons name="source-branch" size={26} color={colors.onSurface} style={{marginRight: 12}} />
            <View style={{flex: 1}}><AppText role="bodySmall" style={{color: colors.onSurfaceVariant}}>Source URL or username</AppText><TextInput value={source} onChangeText={setSource} autoCapitalize="none" autoCorrect={false} placeholder={vegaPluginManager.getSource()?.author || 'Zenda-Cross'} placeholderTextColor={colors.onSurfaceVariant} style={{padding: 0, marginTop: 3, color: colors.onSurface, fontSize: 17}} /></View>
          </View>
          <TouchableOpacity accessibilityRole="button" accessibilityLabel="Load provider source" disabled={refreshing} onPress={() => void refresh(source)} style={{width: 78, borderRadius: 24, backgroundColor: colors.surfaceContainerHighest, alignItems: 'center', justifyContent: 'center'}}>{refreshing ? <ActivityIndicator color={colors.primary} /> : <MaterialCommunityIcons name="plus" size={36} color={colors.onSurface} />}</TouchableOpacity>
        </View>
        <View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14}}><AppText role="headlineMediumEmphasized" style={{color: colors.onBackground, fontSize: 25}}>Available providers</AppText><View style={{paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: colors.surfaceContainerHighest}}><AppText role="titleSmall" style={{color: colors.onSurface}}>{available.length}</AppText></View></View>
        {installed.length > 0 ? <View style={{marginBottom: 12}}><AppText role="titleMedium" style={{color: colors.onSurfaceVariant, marginBottom: 10}}>Installed providers</AppText>{installed.map(plugin => <View key={`${plugin.source.author}:${plugin.value}`} style={[cardStyle, {backgroundColor: colors.surfaceContainer, borderColor: colors.outlineVariant}]}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>{plugin.icon ? <Image source={{uri: plugin.icon}} style={{width: 64, height: 64, borderRadius: 16, marginRight: 14}} /> : <View style={{width: 64, height: 64, borderRadius: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.surfaceContainerHighest, marginRight: 14}}><MaterialCommunityIcons name="puzzle-outline" size={34} color={colors.primary} /></View>}<View style={{flex: 1}}><AppText role="titleLargeEmphasized" style={{color: colors.onSurface}}>{plugin.display_name}</AppText><AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 2}}>v{plugin.version}</AppText><AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 4}}><MaterialCommunityIcons name="account-outline" size={13} />  {plugin.source.author}</AppText></View><CompactSwitch accessibilityLabel={`Enable ${plugin.display_name}`} value={vegaPluginManager.isEnabled(plugin.value)} onValueChange={() => toggle(plugin)} /></View>
          <View style={{height: 1, backgroundColor: colors.outlineVariant, marginVertical: 16}} /><View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
            <TouchableOpacity disabled={testingKey === `${plugin.source.author}:${plugin.value}`} onPress={() => void runTest(plugin)} style={{flexDirection: 'row', alignItems: 'center', padding: 7}}>{testingKey === `${plugin.source.author}:${plugin.value}` ? <ActivityIndicator size="small" color={colors.primary} /> : <MaterialCommunityIcons name="flask-outline" size={21} color={colors.onSurface} />}<AppText role="labelLarge" style={{color: colors.onSurface, marginLeft: 6}}>Test</AppText></TouchableOpacity>
            <TouchableOpacity disabled={settingsLoading} onPress={() => void openSettings(plugin)} style={{flexDirection: 'row', alignItems: 'center', padding: 7}}>{settingsLoading ? <ActivityIndicator size="small" color={colors.primary} /> : <MaterialCommunityIcons name="cog-outline" size={21} color={colors.onSurface} />}<AppText role="labelLarge" style={{color: colors.onSurface, marginLeft: 6}}>Settings</AppText></TouchableOpacity>
            <TouchableOpacity onPress={() => remove(plugin)} style={{flexDirection: 'row', alignItems: 'center', padding: 7}}><MaterialCommunityIcons name="delete-outline" size={21} color={colors.error} /><AppText role="labelLarge" style={{color: colors.error, marginLeft: 6}}>Uninstall</AppText></TouchableOpacity>
          </View>
        </View>)}</View> : null}
      </View>}
      renderItem={({item}) => {
        const key = `${item.source.author}:${item.value}`;
        const isInstalled = installedIds.has(key);
        return <View style={[cardStyle, {backgroundColor: colors.surfaceContainer, borderColor: colors.outlineVariant}]}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>{item.icon ? <Image source={{uri: item.icon}} style={{width: 64, height: 64, borderRadius: 16, marginRight: 14}} /> : <View style={{width: 64, height: 64, borderRadius: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.surfaceContainerHighest, marginRight: 14}}><MaterialCommunityIcons name="puzzle-outline" size={34} color={colors.primary} /></View>}<View style={{flex: 1}}><AppText role="titleLargeEmphasized" style={{color: colors.onSurface}}>{item.display_name}</AppText><AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 3}}>v{item.version}</AppText><AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 5}}><MaterialCommunityIcons name="earth" size={13} />  {item.type || 'Global'}   ·   {item.source.author}</AppText></View></View>
          <View style={{height: 1, backgroundColor: colors.outlineVariant, marginVertical: 16}} />
          <TouchableOpacity disabled={isInstalled} onPress={() => void install(item)} style={{minHeight: 54, borderRadius: 28, backgroundColor: isInstalled ? colors.surfaceContainerHighest : colors.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center'}}><MaterialCommunityIcons name={isInstalled ? 'check' : 'download'} size={22} color={isInstalled ? colors.onSurfaceVariant : colors.onPrimary} /><AppText role="titleMediumEmphasized" style={{color: isInstalled ? colors.onSurfaceVariant : colors.onPrimary, marginLeft: 10}}>{isInstalled ? 'Installed' : 'Install'}</AppText></TouchableOpacity>
        </View>;
      }}
      ListEmptyComponent={<View style={{paddingVertical: 20, alignItems: 'center'}}><AppText role="bodyMedium" style={{color: colors.onSurfaceVariant}}>{refreshing ? 'Loading providers…' : 'Enter a Vega provider source and tap + to load available providers.'}</AppText></View>}
    />
    <Modal visible={!!settingsTarget} animationType="slide" transparent onRequestClose={() => setSettingsTarget(null)}>
      <View style={{flex: 1, justifyContent: 'flex-end', backgroundColor: '#0009'}}><View style={{maxHeight: '86%', backgroundColor: colors.surface, borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 22}}>
        <View style={{flexDirection: 'row', alignItems: 'center', marginBottom: 18}}><View style={{flex: 1}}><AppText role="headlineSmallEmphasized" style={{color: colors.onSurface}}>{settingsTarget?.plugin.display_name}</AppText><AppText role="bodyMedium" style={{color: colors.onSurfaceVariant}}>Provider settings</AppText></View><IconButton icon="close" label="Close settings" buttonSize={42} onPress={() => setSettingsTarget(null)} contentColor={colors.onSurface} /></View>
        <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{paddingBottom: 16}}>{settingsTarget?.schema.length ? settingsTarget.schema.map(renderSettingsField) : <AppText role="bodyMedium" style={{color: colors.onSurfaceVariant}}>This provider does not expose configurable settings.</AppText>}</ScrollView>
        <View style={{flexDirection: 'row', gap: 10, marginTop: 10}}><TouchableOpacity onPress={() => setSettingsTarget(null)} style={{flex: 1, borderWidth: 1, borderColor: colors.outline, borderRadius: 28, minHeight: 52, alignItems: 'center', justifyContent: 'center'}}><AppText role="titleMedium" style={{color: colors.onSurface}}>Cancel</AppText></TouchableOpacity><TouchableOpacity disabled={settingsSaving || !settingsTarget?.schema.length} onPress={() => void saveSettings()} style={{flex: 1, borderRadius: 28, minHeight: 52, alignItems: 'center', justifyContent: 'center', backgroundColor: settingsSaving ? colors.surfaceContainerHighest : colors.primary}}>{settingsSaving ? <ActivityIndicator color={colors.onPrimary} /> : <AppText role="titleMediumEmphasized" style={{color: colors.onPrimary}}>Save</AppText>}</TouchableOpacity></View>
      </View></View>
    </Modal>
  </View>;
};

export default VegaPlugins;

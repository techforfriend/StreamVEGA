import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import React, {useMemo} from 'react';
import {Image, Linking, Pressable, ScrollView, TouchableOpacity, View} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import AppText from '../../../components/ui/Text';
import SkeletonLoader from '../../../components/Skeleton';

const VEGA_ACCENT = '#20D7C6';

interface VegaContentOverviewProps {
  backgroundImage: string;
  posterImage?: string;
  genres?: string[];
  cast?: string[];
  inLibrary: boolean;
  isLoading: boolean;
  onBack: () => void;
  onOpenStory?: () => void;
  onOpenWeb?: () => void;
  onSearchTitle: () => void;
  onToggleLibrary: () => void;
  onToggleSynopsis: () => void;
  providerName: string;
  rating?: string;
  readMore: boolean;
  runtime?: string;
  synopsis: string;
  synopsisLoading: boolean;
  tags?: string[];
  title?: string;
  trailerUrl?: string;
  year?: string;
  tmdbRating?: number;
  tmdbVoteCount?: number;
  certification?: string;
}

const HeaderIcon = ({
  icon,
  label,
  onPress,
}: {
  icon: React.ComponentProps<typeof MaterialCommunityIcons>['name'];
  label: string;
  onPress: () => void;
}) => (
  <TouchableOpacity
    accessibilityRole="button"
    accessibilityLabel={label}
    onPress={onPress}
    style={{alignItems: 'center', justifyContent: 'center', height: 38, width: 36}}>
    <MaterialCommunityIcons name={icon} size={21} color={VEGA_ACCENT} />
  </TouchableOpacity>
);

const VegaContentOverview = ({
  backgroundImage,
  posterImage,
  genres,
  cast,
  inLibrary,
  isLoading,
  onBack,
  onOpenStory,
  onOpenWeb,
  onSearchTitle,
  onToggleLibrary,
  onToggleSynopsis,
  providerName,
  rating,
  readMore,
  runtime,
  synopsis,
  synopsisLoading,
  tags,
  title,
  trailerUrl,
  year,
  tmdbRating,
  tmdbVoteCount,
  certification,
}: VegaContentOverviewProps) => {
  const metadata = useMemo(
    () => [year, runtime, certification, ...(genres ?? []), ...(tags ?? [])]
      .filter(Boolean)
      .map(String)
      .filter((value, index, values) => values.findIndex(item => item.toLowerCase() === value.toLowerCase()) === index)
      .slice(0, 7),
    [certification, genres, runtime, tags, year],
  );
  const synopsisText = synopsis.length > 230 && !readMore
    ? `${synopsis.slice(0, 230).trimEnd()}…`
    : synopsis;
  const normalizedRating = rating?.replace(/\s*\/\s*10$/i, '').trim();
  const castNames = (cast ?? []).filter(Boolean).slice(0, 8);
  const heroImage = backgroundImage || posterImage;
  const sourceName = providerName.replace(/^Vega\s*[·-]\s*/i, '').trim();

  return (
    <View style={{backgroundColor: '#000000'}}>
      <View style={{height: 286, overflow: 'hidden', width: '100%', backgroundColor: '#090909'}}>
        {heroImage ? (
          <Image
            source={{uri: heroImage}}
            resizeMode="cover"
            style={{height: 286, position: 'absolute', top: 0, width: '100%'}}
          />
        ) : null}
        <LinearGradient
          colors={['rgba(0,0,0,0.03)', 'rgba(0,0,0,0.18)', 'rgba(0,0,0,0.72)', '#000000']}
          locations={[0, 0.42, 0.76, 1]}
          style={{height: 286, left: 0, position: 'absolute', right: 0, top: 0}}
        />
        <TouchableOpacity
          accessibilityRole="button"
          accessibilityLabel="Go back"
          onPress={onBack}
          style={{alignItems: 'center', height: 44, justifyContent: 'center', left: 12, position: 'absolute', top: 18, width: 44, zIndex: 2}}>
          <MaterialCommunityIcons name="arrow-left" size={27} color="#FFFFFF" />
        </TouchableOpacity>
        <View style={{alignItems: 'flex-end', bottom: 18, flexDirection: 'row', left: 20, position: 'absolute', right: 18}}>
          <View style={{flex: 1, minWidth: 0, paddingRight: 12}}>
            {isLoading && !title ? (
              <SkeletonLoader show height={34} width="82%" marginVertical={0} />
            ) : (
              <AppText
                role="headlineLargeEmphasized"
                numberOfLines={2}
                style={{color: '#FFFFFF', fontSize: 30, lineHeight: 35}}>
                {title || 'Unknown title'}
              </AppText>
            )}
          </View>
          {normalizedRating ? (
            <View style={{alignItems: 'baseline', flexDirection: 'row', paddingBottom: 4}}>
              <AppText role="headlineMediumEmphasized" style={{color: '#FFFFFF', fontSize: 23}}>{normalizedRating}</AppText>
              <AppText role="titleSmall" style={{color: '#E0E0E0', marginLeft: 2}}>/10</AppText>
            </View>
          ) : null}
        </View>
      </View>

      <View style={{paddingHorizontal: 16, paddingTop: 12}}>
        {tmdbRating ? (
          <View style={{flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 9}}>
            <MaterialCommunityIcons name="star" size={15} color={VEGA_ACCENT} />
            <AppText role="labelMedium" style={{color: '#E4E4E4'}}>
              TMDB {tmdbRating.toFixed(1)}{tmdbVoteCount ? ` · ${tmdbVoteCount.toLocaleString()} votes` : ''}
            </AppText>
          </View>
        ) : null}

        {metadata.length > 0 ? (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap: 7, paddingBottom: 3}}>
            {metadata.map(item => (
              <View key={item} style={{backgroundColor: '#202020', borderRadius: 7, paddingHorizontal: 9, paddingVertical: 5}}>
                <AppText role="labelSmall" style={{color: '#D5D5D5'}}>{item}</AppText>
              </View>
            ))}
          </ScrollView>
        ) : null}

        {castNames.length > 0 ? (
          <View style={{flexDirection: 'row', alignItems: 'center', marginTop: 12}}>
            <AppText role="labelMedium" style={{color: '#A8A8A8', marginRight: 10}}>Cast</AppText>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap: 6}}>
              {castNames.map(name => (
                <View key={name} style={{backgroundColor: '#171717', borderRadius: 5, paddingHorizontal: 7, paddingVertical: 4}}>
                  <AppText role="labelSmall" numberOfLines={1} style={{color: '#D0D0D0'}}>{name}</AppText>
                </View>
              ))}
            </ScrollView>
          </View>
        ) : null}

        <View style={{alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', marginTop: 14}}>
          <View style={{alignItems: 'center', flexDirection: 'row', flex: 1, minWidth: 0}}>
            <AppText role="titleMediumEmphasized" style={{color: '#E8E8E8', marginRight: 10}}>Synopsis</AppText>
            {sourceName ? (
              <AppText role="labelSmall" numberOfLines={1} style={{color: VEGA_ACCENT, flexShrink: 1}}>{sourceName}</AppText>
            ) : null}
          </View>
          <View style={{alignItems: 'center', flexDirection: 'row', marginLeft: 8}}>
            <HeaderIcon icon="magnify" label="Search title" onPress={onSearchTitle} />
            {onOpenWeb ? <HeaderIcon icon="web" label="Open web page" onPress={onOpenWeb} /> : null}
            {onOpenStory ? (
              <HeaderIcon icon="movie-open-outline" label="Explore content" onPress={onOpenStory} />
            ) : trailerUrl ? (
              <HeaderIcon icon="movie-play-outline" label="Play trailer" onPress={() => { void Linking.openURL(trailerUrl); }} />
            ) : null}
            <HeaderIcon
              icon={inLibrary ? 'bookmark' : 'bookmark-outline'}
              label={inLibrary ? 'Remove from watchlist' : 'Add to watchlist'}
              onPress={onToggleLibrary}
            />
          </View>
        </View>

        {synopsisLoading ? (
          <View style={{backgroundColor: '#161616', borderRadius: 9, gap: 8, marginTop: 6, padding: 12}}>
            <SkeletonLoader show height={16} width="100%" marginVertical={0} />
            <SkeletonLoader show height={16} width="94%" marginVertical={0} />
            <SkeletonLoader show height={16} width="72%" marginVertical={0} />
          </View>
        ) : (
          <View style={{backgroundColor: '#161616', borderRadius: 9, marginTop: 6, paddingHorizontal: 12, paddingVertical: 10}}>
            <AppText role="bodyMedium" style={{color: '#BEBEBE', lineHeight: 20}}>{synopsisText}</AppText>
          </View>
        )}

        {!synopsisLoading && synopsis.length > 230 ? (
          <Pressable onPress={onToggleSynopsis} style={{alignSelf: 'flex-start', paddingTop: 7, paddingBottom: 1}}>
            <AppText role="labelMediumEmphasized" style={{color: VEGA_ACCENT}}>{readMore ? 'Show less' : 'Read more'}</AppText>
          </Pressable>
        ) : null}
      </View>
    </View>
  );
};

export default VegaContentOverview;

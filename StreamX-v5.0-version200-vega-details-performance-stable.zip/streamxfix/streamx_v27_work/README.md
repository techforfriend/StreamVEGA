# StreamX Lite — Stremio-only extensions build

This build keeps the existing Android streaming UI, navigation and VLC playback flow, while removing the old StreamX provider-extension runtime and SkyStream integration.

## Extension model

Only Stremio add-ons are supported as external content sources.

Each installed add-on receives a source-scoped provider id:

```text
stremio:<addon-id>
```

Content links are also source-scoped:

```text
stremio://<addon-id>/<type>/<id>
```

Catalogs, metadata, episodes and streams are resolved against the same add-on that created the link. This prevents two add-ons with identical manifest/content ids from sharing the wrong metadata or stream endpoint.

## Settings

`Settings → Add-ons → Stremio Add-ons` provides:

- Manifest URL installation
- Enable/disable
- Removal
- Manifest refresh
- Add-on logo/name/description
- Back button and native stack back gesture support

The old StreamX provider manager, provider source manager and SkyStream UI are not included.

## Stremio support

The adapter handles:

- manifest installation and persistence
- catalog resources and Home sections
- catalog search
- `meta` resources and posters/backgrounds
- series `videos` → episode links
- `stream` resources
- source-scoped caching/links
- independent add-on identities

Stream-only add-ons can provide streams when the corresponding Stremio content link is used; catalog-capable add-ons appear as Home/Search providers.

## Removed

- StreamX downloadable provider extensions
- SkyStream plugin/add-on integration
- Old provider-source UI
- WARP UI/native module/binary
- ByeDPI UI/native module/binary
- About StreamX screen
- GitHub Star/promotion UI
- Provider sandbox runtime

## Build

```bash
npm install --legacy-peer-deps
npx expo prebuild --platform android --clean
cd android
./gradlew :app:assembleRelease -PreactNativeArchitectures=arm64-v8a
```

GitHub Actions is configured in `.github/workflows/build.yml`.

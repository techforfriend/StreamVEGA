const fs = require('fs');
const path = require('path');
const { withDangerousMod } = require('expo/config-plugins');

/**
 * This project now uses `com.akay` for both the Android applicationId and
 * Kotlin package namespace, so no Kotlin keyword escaping is required here.
 * The plugin is retained as a no-op compatibility guard for older generated
 * projects that may still invoke it.
 */
function withKotlinPackageKeywordFix(config) {
  return withDangerousMod(config, [
    'android',
    async cfg => {
      const projectRoot = cfg.modRequest.projectRoot;
      const packageName = cfg.android?.package;
      if (!packageName) return cfg;

      const kotlinPackageName = packageName
        .split('.')
        .map(part => part === 'in' ? '`in`' : part)
        .join('.');

      if (kotlinPackageName === packageName) return cfg;

      const sourceRoot = path.join(
        projectRoot,
        'android',
        'app',
        'src',
        'main',
        'java',
      );

      if (!fs.existsSync(sourceRoot)) return cfg;

      const visit = dir => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
          const fullPath = path.join(dir, entry.name);
          if (entry.isDirectory()) {
            visit(fullPath);
            continue;
          }
          if (!entry.isFile() || !entry.name.endsWith('.kt')) continue;

          let content = fs.readFileSync(fullPath, 'utf8');
          const updated = content
            .replace(
              new RegExp(`(^\\s*package\\s+)${escapeRegExp(packageName)}(?=\\s*$)`, 'm'),
              `$1${kotlinPackageName}`,
            )
            .replace(
              new RegExp(`(^\\s*import\\s+)${escapeRegExp(packageName)}(?=\\.)`, 'gm'),
              `$1${kotlinPackageName}`,
            );

          if (updated !== content) {
            fs.writeFileSync(fullPath, updated, 'utf8');
          }
        }
      };

      visit(sourceRoot);
      return cfg;
    },
  ]);
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&');
}

module.exports = withKotlinPackageKeywordFix;

const fs = require('fs');
const path = require('path');
const { withDangerousMod } = require('expo/config-plugins');

/**
 * Adds a real PCM gain stage to react-native-video v6's Android ExoPlayer.
 * The JS player volume remains 0..1; this gain is applied to decoded PCM
 * before it reaches Android's AudioTrack.
 */
module.exports = function withReactNativeVideoAudioBoost(config) {
  return withDangerousMod(config, [
    'android',
    async cfg => {
      const projectRoot = cfg.modRequest.projectRoot;
      const candidates = [
        path.join(
          projectRoot,
          'node_modules/react-native-video/android/src/main/java/com/brentvatne/exoplayer/ReactExoplayerView.java',
        ),
        path.join(
          projectRoot,
          'node_modules/react-native-video/android-exoplayer/src/main/java/com/brentvatne/exoplayer/ReactExoplayerView.java',
        ),
      ];
      const filePath = candidates.find(fs.existsSync);

      if (!filePath) {
        throw new Error(
          'StreamX audio boost: react-native-video ExoPlayer source was not found.',
        );
      }

      let source = fs.readFileSync(filePath, 'utf8');
      const marker = 'STREAMX_REAL_AUDIO_BOOST_V3';
      if (source.includes(marker)) {
        return cfg;
      }

      const imports = [
        'import androidx.media3.common.audio.AudioProcessor;',
        'import androidx.media3.common.audio.ChannelMixingAudioProcessor;',
        'import androidx.media3.common.audio.ChannelMixingMatrix;',
        'import androidx.media3.exoplayer.audio.AudioSink;',
        'import androidx.media3.exoplayer.audio.DefaultAudioSink;',
      ].join('\n');

      const importAnchor =
        'import androidx.media3.common.AudioAttributes;\n';
      if (!source.includes(importAnchor)) {
        throw new Error(
          'StreamX audio boost: expected react-native-video import anchor was not found.',
        );
      }
      source = source.replace(importAnchor, `${importAnchor}${imports}\n`);

      const oldFactory = `DefaultRenderersFactory renderersFactory =\n                new DefaultRenderersFactory(getContext())\n                        .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)\n                        .setEnableDecoderFallback(true)\n                        .forceEnableMediaCodecAsynchronousQueueing();`;

      const newFactory = `// ${marker}: apply a real 1.50x PCM gain before AudioTrack output.\n        DefaultRenderersFactory renderersFactory =\n                new DefaultRenderersFactory(getContext()) {\n                    @Override\n                    protected AudioSink buildAudioSink(\n                            Context context,\n                            boolean enableFloatOutput,\n                            boolean enableAudioTrackPlaybackParams) {\n                        ChannelMixingAudioProcessor gainProcessor = new ChannelMixingAudioProcessor();\n                        final float gain = 1.50f;\n                        for (int channels = 1; channels <= 8; channels++) {\n                            float[] coefficients = new float[channels * channels];\n                            for (int i = 0; i < channels; i++) {\n                                coefficients[i * channels + i] = gain;\n                            }\n                            gainProcessor.putChannelMixingMatrix(\n                                    new ChannelMixingMatrix(channels, channels, coefficients));\n                        }\n                        return new DefaultAudioSink.Builder(context)\n                                .setEnableFloatOutput(false)\n                                .setAudioProcessors(new AudioProcessor[]{gainProcessor})\n                                .build();\n                    }\n                }\n                        .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)\n                        .setEnableDecoderFallback(true)\n                        .forceEnableMediaCodecAsynchronousQueueing();`;

      if (!source.includes(oldFactory)) {
        throw new Error(
          'StreamX audio boost: expected react-native-video renderer factory block was not found.',
        );
      }
      source = source.replace(oldFactory, newFactory);

      fs.writeFileSync(filePath, source, 'utf8');
      return cfg;
    },
  ]);
};

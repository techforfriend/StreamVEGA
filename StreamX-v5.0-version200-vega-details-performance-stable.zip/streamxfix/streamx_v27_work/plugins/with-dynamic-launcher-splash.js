const fs = require('fs');
const path = require('path');
const {
  withAndroidManifest,
  withAndroidStyles,
  withDangerousMod,
  withMainActivity,
} = require('expo/config-plugins');

const variants = [
  {id: 'White', color: '#FFFFFFFF', enabled: true},
  {id: 'Tomato', color: '#FFFF6347', enabled: false},
  {id: 'Gray', color: '#FF9E9E9E', enabled: false},
  {id: 'Blue', color: '#FF2196F3', enabled: false},
  {id: 'Lavender', color: '#FFB2A4D4', enabled: false},
];

const setStyleItem = (style, name, value) => {
  style.item = Array.isArray(style.item) ? style.item : [];
  const existing = style.item.find(item => item?.$?.name === name);
  if (existing) {
    existing._ = value;
    return;
  }
  style.item.push({$: {name}, _: value});
};

const upsertStyle = (styles, name, parent, items = []) => {
  let style = styles.find(entry => entry?.$?.name === name);
  if (!style) {
    style = {$: {name}, item: []};
    styles.push(style);
  }
  if (parent) {
    style.$.parent = parent;
  }
  for (const [itemName, value] of items) {
    setStyleItem(style, itemName, value);
  }
};

const createLauncherAlias = (packageName, variant) => ({
  $: {
    'android:name': `.Launcher${variant.id}`,
    'android:enabled': String(variant.enabled),
    'android:exported': 'true',
    'android:icon': `@drawable/ic_launcher_${variant.id.toLowerCase()}`,
    'android:roundIcon': `@drawable/ic_launcher_${variant.id.toLowerCase()}`,
    'android:targetActivity': '.MainActivity',
    'android:theme': `@style/BootTheme.${variant.id}`,
  },
  'intent-filter': [
    {
      action: [{$: {'android:name': 'android.intent.action.MAIN'}}],
      category: [{$: {'android:name': 'android.intent.category.LAUNCHER'}}],
    },
  ],
});

const removeLauncherIntent = activity => {
  activity['intent-filter'] = (activity['intent-filter'] || []).filter(
    filter =>
      !filter.action?.some(
        action => action?.$?.['android:name'] === 'android.intent.action.MAIN',
      ),
  );
};

const withLauncherManifest = config =>
  withAndroidManifest(config, manifestConfig => {
    const application = manifestConfig.modResults.manifest.application?.[0];
    if (!application) {
      return manifestConfig;
    }
    // Always expose the real StreamX artwork as the application/launcher icon.
    // This prevents Android's themed/dynamic icon from replacing the artwork.
    application.$['android:icon'] = '@drawable/streamx_launcher';
    application.$['android:roundIcon'] = '@drawable/streamx_launcher';
    const mainActivity = application.activity?.find(
      activity => activity?.$?.['android:name'] === '.MainActivity',
    );
    if (mainActivity) {
      removeLauncherIntent(mainActivity);
      mainActivity.$['android:theme'] = '@style/BootTheme';
    }
    application['activity-alias'] = variants.map(variant =>
      createLauncherAlias(manifestConfig.android?.package, variant),
    );
    return manifestConfig;
  });

const withLauncherStyles = config =>
  withAndroidStyles(config, stylesConfig => {
    const styles = stylesConfig.modResults.resources.style || [];
    stylesConfig.modResults.resources.style = styles;
    upsertStyle(styles, 'BootTheme', 'BootTheme.White');
    const bootTheme = styles.find(style => style?.$?.name === 'BootTheme');
    if (bootTheme) {
      bootTheme.item = [];
    }
    upsertStyle(styles, 'BootTheme.Base', 'Theme.BootSplash.EdgeToEdge', [
      ['postBootSplashTheme', '@style/AppTheme'],
      ['bootSplashBackground', '#000000'],
    ]);
    for (const variant of variants) {
      upsertStyle(styles, `BootTheme.${variant.id}`, 'BootTheme.Base', [
        [
          'bootSplashLogo',
          `@drawable/bootsplash_logo_${variant.id.toLowerCase()}`,
        ],
      ]);
    }
    return stylesConfig;
  });

const bootThemeMethod = `  private fun getBootTheme(): Int {
    val launchedAlias = intent?.component?.className?.substringAfterLast('.')
    val selectedIcon = when (launchedAlias) {
      "LauncherWhite" -> "white"
      "LauncherTomato" -> "tomato"
      "LauncherGray" -> "gray"
      "LauncherBlue" -> "blue"
      "LauncherLavender" -> "lavender"
      else -> getSharedPreferences("vega_launcher", MODE_PRIVATE)
        .getString("icon", "white")
    }
    return when (selectedIcon) {
      "tomato" -> R.style.BootTheme_Tomato
      "gray" -> R.style.BootTheme_Gray
      "blue" -> R.style.BootTheme_Blue
      "lavender" -> R.style.BootTheme_Lavender
      else -> R.style.BootTheme_White
    }
  }

`;

const bootSplashInitialization = `val bootTheme = getBootTheme()
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
      splashScreen.setSplashScreenTheme(bootTheme)
    }
    RNBootSplash.init(this, bootTheme)`;

const withLauncherMainActivity = config =>
  withMainActivity(config, activityConfig => {
    let contents = activityConfig.modResults.contents;
    if (!contents.includes('private fun getBootTheme()')) {
      contents = contents.replace(
        /class MainActivity\s*:\s*ReactActivity\(\)\s*\{\n/,
        match => `${match}${bootThemeMethod}`,
      );
    }
    contents = contents.replace(
      /RNBootSplash\.init\(this,\s*(?:R\.style\.BootTheme|getBootTheme\(\))\)/,
      bootSplashInitialization,
    );
    activityConfig.modResults.contents = contents;
    return activityConfig;
  });

const writeLauncherResources = (projectRoot, resRoot) => {
  const drawable = path.join(resRoot, 'drawable');
  const drawableV26 = path.join(resRoot, 'drawable-v26');
  fs.mkdirSync(drawable, {recursive: true});
  fs.mkdirSync(drawableV26, {recursive: true});

  const launcherSource = path.join(projectRoot, 'assets', 'streamx_launcher.png');
  const launcherTarget = path.join(drawable, 'streamx_launcher.png');
  fs.copyFileSync(launcherSource, launcherTarget);

  // Keep the existing launcher-alias structure, but every alias now points to
  // the actual StreamX artwork instead of a dynamically tinted placeholder.
  for (const variant of variants) {
    const id = variant.id.toLowerCase();
    fs.copyFileSync(launcherSource, path.join(drawable, `ic_launcher_${id}.png`));
    fs.writeFileSync(
      path.join(drawableV26, `ic_launcher_${id}.xml`),
      `<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n` +
        `    <background android:drawable="@color/iconBackground" />\n` +
        `    <foreground android:drawable="@drawable/streamx_launcher_foreground" />\n` +
        `</adaptive-icon>\n`,
    );
  }

  fs.copyFileSync(launcherSource, path.join(drawable, 'streamx_launcher_foreground.png'));
};

const copySplashResources = (projectRoot, resRoot) => {
  const source = path.join(projectRoot, 'assets', 'streamx_splash_logo.png');
  for (const density of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) {
    const bucket = `drawable-${density}`;
    const targetDir = path.join(resRoot, bucket);
    fs.mkdirSync(targetDir, {recursive: true});
    const filename = 'bootsplash_logo_white.png';
    fs.copyFileSync(source, path.join(targetDir, filename));
    // Keep the generated splash resource names stable for the existing theme.
    for (const variant of variants) {
      const target = path.join(targetDir, `bootsplash_logo_${variant.id.toLowerCase()}.png`);
      fs.copyFileSync(source, target);
    }
  }
};

const patchGeneratedBootSplashFiles = (projectRoot, packageName) => {
  const mainActivityPath = path.join(
    projectRoot,
    'android',
    'app',
    'src',
    'main',
    'java',
    ...packageName.split('.'),
    'MainActivity.kt',
  );
  let mainActivity = fs.readFileSync(mainActivityPath, 'utf8');
  mainActivity = mainActivity.replace(
    /RNBootSplash\.init\(this,\s*(?:R\.style\.BootTheme|getBootTheme\(\))\)/,
    bootSplashInitialization,
  );
  fs.writeFileSync(mainActivityPath, mainActivity, 'utf8');
};

const withLauncherResources = config =>
  withDangerousMod(config, [
    'android',
    async modConfig => {
      const projectRoot = modConfig.modRequest.projectRoot;
      const resRoot = path.join(
        projectRoot,
        'android',
        'app',
        'src',
        'main',
        'res',
      );
      writeLauncherResources(projectRoot, resRoot);
      copySplashResources(projectRoot, resRoot);
      patchGeneratedBootSplashFiles(
        projectRoot,
        modConfig.android?.package || 'com.akay',
      );
      return modConfig;
    },
  ]);

module.exports = function withDynamicLauncherSplash(config) {
  config = withLauncherManifest(config);
  config = withLauncherStyles(config);
  config = withLauncherMainActivity(config);
  return withLauncherResources(config);
};

import type {BottomTabBarProps} from '@react-navigation/bottom-tabs';
import {BlurView} from 'expo-blur';
import React, {useEffect} from 'react';
import {
  StyleSheet,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from 'react-native';
import ReactNativeHapticFeedback from 'react-native-haptic-feedback';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import {settingsStorage} from '../../lib/storage';
import useNavigationPreferencesStore from '../../lib/zustand/navigationPreferencesStore';
import {useM3Colors} from '../../theme/M3PaletteContext';
import AppText from '../ui/Text';
import {AnimatedTabIcon, type AnimatedTabIconName} from './AnimatedTabIcon';

const TAB_ICONS: Record<string, AnimatedTabIconName> = {
  HomeStack: 'home',
  SearchStack: 'search',
  WatchListStack: 'watchlist',
  DownloadsStack: 'download',
  SettingsStack: 'settings',
};

const StreamingTabBar = ({
  state,
  descriptors,
  navigation,
}: BottomTabBarProps) => {
  const colors = useM3Colors();
  const insets = useSafeAreaInsets();
  const {width: windowWidth, height: windowHeight} = useWindowDimensions();
  const isNavigationRail = Math.min(windowWidth, windowHeight) >= 600;
  const hideTabBarLabels = useNavigationPreferencesStore(state => state.hideTabBarLabels);
  const showLabels = settingsStorage.showTabBarLabels() && !hideTabBarLabels;
  const tabBarHidden = useNavigationPreferencesStore(
    state => state.tabBarHidden,
  );
  const settingsTabActive = state.routes[state.index]?.name === 'SettingsStack';
  const effectiveTabBarHidden = tabBarHidden || settingsTabActive;
  const setTabBarHidden = useNavigationPreferencesStore(
    state => state.setTabBarHidden,
  );

  const translateY = useSharedValue(0);
  const opacity = useSharedValue(1);

  useEffect(() => {
    if (isNavigationRail) {
      translateY.value = 0;
      opacity.value = 1;
      return;
    }
    translateY.value = withTiming(effectiveTabBarHidden ? 104 : 0, {duration: 190});
    opacity.value = withTiming(effectiveTabBarHidden ? 0 : 1, {duration: 140});
  }, [effectiveTabBarHidden, isNavigationRail, opacity, translateY]);

  useEffect(() => {
    return () => setTabBarHidden(false);
  }, [setTabBarHidden]);

  const floatingStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{translateY: translateY.value}],
  }));

  if (isNavigationRail) {
    return (
      <View
        style={{
          backgroundColor: 'rgba(18,18,18,0.82)',
          borderRightColor: 'rgba(255,255,255,0.14)',
          borderRightWidth: StyleSheet.hairlineWidth,
          height: '100%',
          overflow: 'hidden',
          paddingBottom: Math.max(insets.bottom, 12),
          paddingLeft: insets.left,
          paddingRight: 4,
          paddingTop: Math.max(insets.top, 16),
          position: 'relative',
          width: 96 + insets.left,
        }}>
        <BlurView
          pointerEvents="none"
          intensity={22}
          tint="dark"
          style={StyleSheet.absoluteFillObject}
        />
        <View
          pointerEvents="none"
          style={[StyleSheet.absoluteFillObject, {backgroundColor: 'rgba(255,255,255,0.075)'}]}
        />
        <View
          style={{
            alignItems: 'center',
            flex: 1,
            flexDirection: 'column',
            gap: 8,
          }}>
          {state.routes.map((route, index) => {
            const descriptor = descriptors[route.key];
            const focused = state.index === index;
            const label =
              typeof descriptor.options.tabBarLabel === 'string'
                ? descriptor.options.tabBarLabel
                : typeof descriptor.options.title === 'string'
                  ? descriptor.options.title
                  : route.name;
            const icon = TAB_ICONS[route.name] ?? 'home';
            const onPress = () => {
              const event = navigation.emit({
                type: 'tabPress',
                target: route.key,
                canPreventDefault: true,
              });
              if (!focused && !event.defaultPrevented) {
                if (settingsStorage.isHapticFeedbackEnabled()) {
                  ReactNativeHapticFeedback.trigger('effectTick', {
                    enableVibrateFallback: true,
                    ignoreAndroidSystemSettings: false,
                  });
                }
                navigation.navigate(route.name, route.params);
              }
            };
            return (
              <TouchableOpacity
                key={route.key}
                accessibilityRole="button"
                accessibilityState={focused ? {selected: true} : {}}
                accessibilityLabel={descriptor.options.tabBarAccessibilityLabel}
                activeOpacity={0.8}
                onLongPress={() =>
                  navigation.emit({type: 'tabLongPress', target: route.key})
                }
                onPress={onPress}
                style={{
                  alignItems: 'center',
                  height: showLabels ? 72 : 56,
                  justifyContent: 'center',
                  minWidth: 48,
                  width: 88,
                }}>
                <View
                  pointerEvents="none"
                  style={{
                    alignItems: 'center',
                    backgroundColor: focused
                      ? colors.secondaryContainer
                      : 'transparent',
                    borderColor: focused ? 'rgba(255,255,255,0.16)' : 'transparent',
                    borderWidth: focused ? StyleSheet.hairlineWidth : 0,
                    borderRadius: 16,
                    height: 32,
                    justifyContent: 'center',
                    overflow: 'hidden',
                    width: 56,
                  }}>
                  <AnimatedTabIcon
                    name={icon}
                    active={focused}
                    color={
                      focused
                        ? colors.onSecondaryContainer
                        : colors.onSurfaceVariant
                    }
                    size={24}
                  />
                </View>
                {showLabels ? (
                  <AppText
                    role={focused ? 'labelMediumEmphasized' : 'labelMedium'}
                    numberOfLines={1}
                    style={{
                      color: focused ? colors.onSurface : colors.onSurfaceVariant,
                      marginTop: 4,
                      textAlign: 'center',
                    }}>
                    {label}
                  </AppText>
                ) : null}
              </TouchableOpacity>
            );
          })}
        </View>
      </View>
    );
  }

  return (
    <View
      pointerEvents="box-none"
      style={{
        bottom: 0,
        height: (showLabels ? 88 : 68) + Math.max(insets.bottom, 6),
        left: 0,
        position: 'absolute',
        right: 0,
      }}>
      <Animated.View
        pointerEvents={effectiveTabBarHidden ? 'none' : 'box-none'}
        style={[
          floatingStyle,
          {
            alignSelf: 'center',
            bottom: Math.max(insets.bottom, 7) + 7,
            elevation: 10,
            maxWidth: 560,
            position: 'absolute',
            shadowColor: '#000000',
            shadowOffset: {width: 0, height: 5},
            shadowOpacity: 0.3,
            shadowRadius: 12,
            width: showLabels ? Math.min(windowWidth - 32, 540) : Math.min(windowWidth - 112, 300),
          },
        ]}>
        <View
          style={{
            alignItems: 'center',
            backgroundColor: 'rgba(12,12,12,0.40)',
            borderColor: 'rgba(255,255,255,0.42)',
            overflow: 'hidden',
            borderRadius: showLabels ? 32 : 25,
            borderWidth: StyleSheet.hairlineWidth,
            flexDirection: 'row',
            minHeight: showLabels ? 60 : 46,
            paddingHorizontal: 8,
            paddingVertical: showLabels ? 6 : 4,
          }}>
          <BlurView
            pointerEvents="none"
            intensity={28}
            tint="dark"
            style={StyleSheet.absoluteFillObject}
          />
          <View
            pointerEvents="none"
            style={[StyleSheet.absoluteFillObject, {backgroundColor: 'rgba(255,255,255,0.075)'}]}
          />
          {state.routes.map((route, index) => {
            const descriptor = descriptors[route.key];
            const focused = state.index === index;
            const label =
              typeof descriptor.options.tabBarLabel === 'string'
                ? descriptor.options.tabBarLabel
                : typeof descriptor.options.title === 'string'
                  ? descriptor.options.title
                  : route.name;
            const icon = TAB_ICONS[route.name] ?? 'home';
            const onPress = () => {
              const event = navigation.emit({
                type: 'tabPress',
                target: route.key,
                canPreventDefault: true,
              });
              if (!focused && !event.defaultPrevented) {
                if (settingsStorage.isHapticFeedbackEnabled()) {
                  ReactNativeHapticFeedback.trigger('effectTick', {
                    enableVibrateFallback: true,
                    ignoreAndroidSystemSettings: false,
                  });
                }
                navigation.navigate(route.name, route.params);
              }
            };

            return (
              <TouchableOpacity
                key={route.key}
                accessibilityRole="button"
                accessibilityState={focused ? {selected: true} : {}}
                accessibilityLabel={descriptor.options.tabBarAccessibilityLabel}
                activeOpacity={0.82}
                onLongPress={() =>
                  navigation.emit({type: 'tabLongPress', target: route.key})
                }
                onPress={onPress}
                style={{
                  alignItems: 'center',
                  flex: 1,
                  height: showLabels ? 50 : 36,
                  justifyContent: 'center',
                  minWidth: 48,
                }}>
                <View
                  pointerEvents="none"
                  style={{
                    alignItems: 'center',
                    backgroundColor: focused
                      ? colors.secondaryContainer
                      : 'transparent',
                    borderColor: focused ? 'rgba(255,255,255,0.18)' : 'transparent',
                    borderWidth: focused ? StyleSheet.hairlineWidth : 0,
                    borderRadius: 22,
                    height: 40,
                    justifyContent: 'center',
                    width: 58,
                  }}>
                  <AnimatedTabIcon
                    name={icon}
                    active={focused}
                    color={
                      focused
                        ? colors.onSecondaryContainer
                        : colors.onSurfaceVariant
                    }
                    size={24}
                  />
                </View>
                {showLabels ? (
                  <AppText
                    role={focused ? 'labelMediumEmphasized' : 'labelMedium'}
                    numberOfLines={1}
                    style={{
                      color: focused ? colors.onSurface : colors.onSurfaceVariant,
                      marginTop: 1,
                      textAlign: 'center',
                    }}>
                    {label}
                  </AppText>
                ) : null}
              </TouchableOpacity>
            );
          })}
        </View>
      </Animated.View>
    </View>
  );
};

export default StreamingTabBar;

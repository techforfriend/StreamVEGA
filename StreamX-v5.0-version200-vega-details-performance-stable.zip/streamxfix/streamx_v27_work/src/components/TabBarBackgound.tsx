import {StyleSheet, View} from 'react-native';
import React, {memo} from 'react';
import {useM3Colors} from '../theme/M3PaletteContext';

const TabBarBackgound = memo(() => {
  const colors = useM3Colors();
  return (
    <View
      style={[
        StyleSheet.absoluteFill,
        {
          backgroundColor: colors.surfaceContainerHigh,
          borderColor: colors.outlineVariant,
          borderWidth: StyleSheet.hairlineWidth,
          borderRadius: 28,
          marginHorizontal: 10,
          marginBottom: 8,
        },
      ]}
    />
  );
});

export default TabBarBackgound;

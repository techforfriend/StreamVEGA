import React from 'react';
import {Pressable, View} from 'react-native';
import {useM3Colors} from '../../theme/M3PaletteContext';

interface CompactSwitchProps {
  value: boolean;
  onValueChange: (value: boolean) => void;
  accessibilityLabel?: string;
  disabled?: boolean;
}

const CompactSwitch = ({
  value,
  onValueChange,
  accessibilityLabel,
  disabled = false,
}: CompactSwitchProps) => {
  const colors = useM3Colors();
  return (
    <Pressable
      accessibilityRole="switch"
      accessibilityLabel={accessibilityLabel}
      accessibilityState={{checked: value, disabled}}
      disabled={disabled}
      onPress={() => onValueChange(!value)}
      style={{
        width: 48,
        height: 28,
        borderRadius: 14,
        padding: 3,
        justifyContent: 'center',
        backgroundColor: value ? colors.primary : colors.surfaceContainerHighest,
        borderWidth: 1,
        borderColor: value ? colors.primary : colors.outlineVariant,
        opacity: disabled ? 0.45 : 1,
      }}>
      <View
        style={{
          width: 20,
          height: 20,
          borderRadius: 10,
          alignSelf: value ? 'flex-end' : 'flex-start',
          backgroundColor: value ? colors.onPrimary : colors.onSurfaceVariant,
        }}
      />
    </Pressable>
  );
};

export default CompactSwitch;

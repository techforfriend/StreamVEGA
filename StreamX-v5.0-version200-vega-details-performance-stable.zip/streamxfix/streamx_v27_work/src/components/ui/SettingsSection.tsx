import React, {ReactNode} from 'react';
import {StyleSheet, View} from 'react-native';
import AppText from './Text';
import {useM3Colors} from '../../theme/M3PaletteContext';

interface SettingsSectionProps {
  title: string;
  children: ReactNode;
}

const SettingsSection = ({title, children}: SettingsSectionProps) => {
  const colors = useM3Colors();
  return (
    <View style={{marginBottom: 12}}>
      <AppText
        role="labelMediumEmphasized"
        style={{
          color: colors.onSurfaceVariant,
          letterSpacing: 1.25,
          marginLeft: 2,
          marginBottom: 6,
        }}>
        {title.toUpperCase()}
      </AppText>
      <View
        style={{
          backgroundColor: colors.surfaceContainer,
          borderRadius: 22,
          borderWidth: StyleSheet.hairlineWidth,
          borderColor: 'rgba(255,255,255,0.12)',
          overflow: 'hidden',
          shadowColor: '#000000',
          shadowOffset: {width: 0, height: 4},
          shadowOpacity: 0.16,
          shadowRadius: 12,
          elevation: 2,
        }}>
        {children}
      </View>
    </View>
  );
};

export default SettingsSection;

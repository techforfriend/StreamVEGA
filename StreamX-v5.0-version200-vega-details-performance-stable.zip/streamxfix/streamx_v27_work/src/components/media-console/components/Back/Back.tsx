import React from 'react';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import {Control} from '../Control';

interface BackProps {
  onBack: () => void;
  resetControlTimeout?: () => void;
  showControls: boolean;
}

export const Back = ({onBack, resetControlTimeout}: BackProps) => {
  return (
    <Control
      callback={onBack}
      hitSlop={{top: 28, bottom: 24, left: 30, right: 24}}
      resetControlTimeout={resetControlTimeout}
      style={{minWidth: 58, minHeight: 58, marginLeft: -6, marginTop: -4, alignItems: 'center', justifyContent: 'center'}}
    >
      <MaterialIcons
        name="arrow-back-ios-new"
        size={24}
        color="rgba(255,255,255,0.68)"
      />
    </Control>
  );
};

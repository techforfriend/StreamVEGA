import React, {useCallback, useEffect, useMemo, useState} from 'react';
import {
  Alert,
  FlatList,
  Image,
  Linking,
  Modal,
  Pressable,
  RefreshControl,
  Text,
  TextInput,
  View,
} from 'react-native';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {MaterialCommunityIcons} from '@expo/vector-icons';
import {SettingsStackParamList} from '../../App';
import AppText from '../../components/ui/Text';
import IconButton from '../../components/ui/IconButton';
import CompactSwitch from '../../components/ui/CompactSwitch';
import SettingsSection from '../../components/ui/SettingsSection';
import {useM3Colors} from '../../theme/M3PaletteContext';
import stremioAddonManager, {
  StremioAddon,
} from '../../lib/services/StremioAddonManager';
import useContentStore from '../../lib/zustand/contentStore';
import useTabBarScrollVisibility from '../../lib/hooks/useTabBarScrollVisibility';

type Props = NativeStackScreenProps<SettingsStackParamList, 'Extensions'>;

const isConfigurable = (addon: StremioAddon) =>
  addon.manifest.behaviorHints?.configurable === true ||
  addon.manifest.behaviorHints?.configurationRequired === true ||
  (Array.isArray(addon.manifest.config) && addon.manifest.config.length > 0);

const configureUrlFor = (addon: StremioAddon) => {
  try {
    return new URL('configure', `${addon.url.replace(/\/+$/, '')}/`).toString();
  } catch {
    return `${addon.url.replace(/\/+$/, '')}/configure`;
  }
};

const AddonBadge = React.memo(({
  label,
  selected = false,
}: {
  label: string;
  selected?: boolean;
}) => {
  const colors = useM3Colors();
  return (
    <View
      style={{
        backgroundColor: selected
          ? colors.secondaryContainer
          : colors.surfaceContainerHighest,
        borderRadius: 12,
        paddingHorizontal: 11,
        paddingVertical: 6,
      }}>
      <AppText
        role="labelMediumEmphasized"
        numberOfLines={1}
        style={{color: selected ? colors.onSecondaryContainer : colors.onSurfaceVariant}}>
        {label}
      </AppText>
    </View>
  );
});
AddonBadge.displayName = 'AddonBadge';

const Extensions = ({navigation, route}: Props) => {
  const colors = useM3Colors();
  const insets = useSafeAreaInsets();
  const tabBarScroll = useTabBarScrollVisibility();
  const syncProviders = useContentStore(state => state.syncStremioProviders);
  const [addons, setAddons] = useState<StremioAddon[]>([]);
  const [url, setUrl] = useState(route.params?.initialAddonUrl || '');
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [installedNotice, setInstalledNotice] = useState<string | null>(null);

  const reload = useCallback(() => {
    setAddons(stremioAddonManager.list());
    syncProviders();
  }, [syncProviders]);

  useEffect(() => {
    reload();
  }, [reload]);

  useEffect(() => {
    const incoming = route.params?.initialAddonUrl;
    if (incoming) {
      setUrl(incoming);
      navigation.setParams({initialAddonUrl: undefined});
    }
  }, [navigation, route.params?.initialAddonUrl]);

  const install = async () => {
    const value = url.trim();
    if (!value || busy) return;
    setBusy(true);
    try {
      const addon = await stremioAddonManager.install(value);
      setUrl('');
      reload();
      setInstalledNotice(addon.name);
    } catch (error) {
      Alert.alert(
        'Add-on error',
        error instanceof Error ? error.message : 'Unable to install this add-on',
      );
    } finally {
      setBusy(false);
    }
  };

  const refresh = async () => {
    setRefreshing(true);
    try {
      await stremioAddonManager.refreshAll({timeoutMs: 2500});
      reload();
    } finally {
      setRefreshing(false);
    }
  };

  const updateAddon = useCallback(
    async (addon: StremioAddon) => {
      if (updatingId) return;
      setUpdatingId(addon.id);
      try {
        await stremioAddonManager.refresh(addon.id);
        reload();
      } catch (error) {
        Alert.alert(
          'Update failed',
          error instanceof Error ? error.message : 'Unable to update this add-on',
        );
      } finally {
        setUpdatingId(null);
      }
    },
    [reload, updatingId],
  );

  const remove = (addon: StremioAddon) => {
    Alert.alert('Remove add-on?', addon.name, [
      {text: 'Cancel', style: 'cancel'},
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => {
          stremioAddonManager.remove(addon.id);
          reload();
        },
      },
    ]);
  };

  const toggle = (addon: StremioAddon) => {
    stremioAddonManager.setEnabled(addon.id, !addon.enabled);
    reload();
  };

  const openManifest = async (addon: StremioAddon) => {
    try {
      await Linking.openURL(`${addon.url.replace(/\/+$/, '')}/manifest.json`);
    } catch {
      Alert.alert('Unable to open', 'The add-on manifest URL could not be opened.');
    }
  };

  const configure = async (addon: StremioAddon) => {
    if (!isConfigurable(addon)) return;
    try {
      await Linking.openURL(configureUrlFor(addon));
    } catch {
      Alert.alert('Unable to configure', 'The add-on configuration page could not be opened.');
    }
  };

  const stats = useMemo(
    () => ({
      total: addons.length,
      active: addons.filter(addon => addon.enabled).length,
      catalogs: addons.reduce(
        (sum, addon) => sum + (addon.manifest.catalogs?.length || 0),
        0,
      ),
    }),
    [addons],
  );

  const resourceCount = useCallback((addon: StremioAddon) => {
    const resources = new Set(
      (addon.manifest.resources || []).map(resource =>
        typeof resource === 'string' ? resource : resource.name,
      ),
    );
    return resources.size;
  }, []);

  return (
    <View style={{flex: 1, backgroundColor: colors.background}}>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          paddingHorizontal: 18,
          paddingTop: insets.top + 18,
          paddingBottom: 10,
        }}>
        <IconButton
          icon="arrow-left"
          label="Back"
          buttonSize={40}
          onPress={() => navigation.goBack()}
          contentColor={colors.onSurface}
        />
        <View style={{flex: 1, marginLeft: 10}}>
          <AppText role="headlineLargeEmphasized" style={{color: colors.onBackground, fontSize: 30, lineHeight: 36}}>
            Addons
          </AppText>
        </View>
        <IconButton
          icon="refresh"
          label="Refresh add-ons"
          buttonSize={40}
          onPress={refresh}
          disabled={refreshing}
          contentColor={colors.primary}
        />
      </View>

      <FlatList
        data={addons}
        keyExtractor={item => item.id}
        onScroll={tabBarScroll.onScroll}
        onScrollBeginDrag={tabBarScroll.onScrollBeginDrag}
        onScrollEndDrag={tabBarScroll.onScrollEndDrag}
        onMomentumScrollBegin={tabBarScroll.onMomentumScrollBegin}
        onMomentumScrollEnd={tabBarScroll.onMomentumScrollEnd}
        scrollEventThrottle={32}
        initialNumToRender={6}
        maxToRenderPerBatch={6}
        windowSize={7}
        removeClippedSubviews
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} />}
        contentContainerStyle={{paddingHorizontal: 18, paddingBottom: 138}}
        ListHeaderComponent={
          <View style={{paddingBottom: 12}}>
            <SettingsSection title="Overview">
              <View style={{minHeight: 70, flexDirection: 'row', alignItems: 'center'}}>
                {[
                  ['Addons', String(stats.total)],
                  ['Active', String(stats.active)],
                  ['Catalogs', String(stats.catalogs)],
                ].map(([label, value], index) => (
                  <View
                    key={label}
                    style={{
                      alignItems: 'center',
                      borderLeftWidth: index === 0 ? 0 : 1,
                      borderLeftColor: colors.outlineVariant,
                      flex: 1,
                      paddingHorizontal: 8,
                    }}>
                    <AppText role="headlineMediumEmphasized" style={{color: colors.onSurface, fontSize: 24, lineHeight: 30}}>
                      {value}
                    </AppText>
                    <AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 1}}>
                      {label}
                    </AppText>
                  </View>
                ))}
              </View>
            </SettingsSection>

            <SettingsSection title="Add Addon">
              <View style={{paddingHorizontal: 12, paddingVertical: 9}}>
                <View
                  style={{
                    backgroundColor: colors.surfaceContainerHighest,
                    borderRadius: 16,
                    minHeight: 46,
                    paddingHorizontal: 14,
                    justifyContent: 'center',
                  }}>
                  <TextInput
                    value={url}
                    onChangeText={setUrl}
                    autoCapitalize="none"
                    autoCorrect={false}
                    keyboardType="url"
                    placeholder="Detected addon manifest URL"
                    placeholderTextColor={colors.onSurfaceVariant}
                    style={{color: colors.onSurface, fontSize: 15, paddingVertical: 0}}
                    onSubmitEditing={install}
                  />
                </View>
                <Pressable
                  disabled={busy || !url.trim()}
                  onPress={install}
                  style={({pressed}) => ({
                    alignItems: 'center',
                    backgroundColor: colors.primary,
                    borderRadius: 15,
                    justifyContent: 'center',
                    marginTop: 7,
                    minHeight: 44,
                    opacity: busy || !url.trim() ? 0.45 : pressed ? 0.82 : 1,
                  })}>
                  <AppText role="labelLargeEmphasized" style={{color: colors.onPrimary}}>
                    {busy ? 'Installing…' : 'Install Addon'}
                  </AppText>
                </Pressable>
              </View>
            </SettingsSection>

            <AppText role="labelMediumEmphasized" style={{color: colors.onSurfaceVariant, letterSpacing: 1.25, marginLeft: 2, marginBottom: 6}}>
              INSTALLED ADDONS
            </AppText>
          </View>
        }
        ListEmptyComponent={
          <View
            style={{
              alignItems: 'center',
              backgroundColor: colors.surfaceContainer,
              borderRadius: 24,
              borderWidth: 1,
              borderColor: colors.outlineVariant,
              paddingHorizontal: 16,
              paddingVertical: 18,
            }}>
            <MaterialCommunityIcons name="puzzle-outline" size={34} color={colors.primary} />
            <AppText role="bodyLargeEmphasized" style={{color: colors.onSurface, marginTop: 8}}>
              No Stremio add-ons installed
            </AppText>
            <AppText
              role="bodySmall"
              style={{color: colors.onSurfaceVariant, marginTop: 4, textAlign: 'center'}}>
              Add a manifest URL above to populate Home, Search, metadata, episodes and streams.
            </AppText>
          </View>
        }
        renderItem={({item}) => {
          const configurable = isConfigurable(item);
          const resources = resourceCount(item);
          const catalogs = item.manifest.catalogs?.length || 0;
          return (
            <View
              style={{
                backgroundColor: colors.surfaceContainer,
                borderRadius: 24,
                borderWidth: 1,
                borderColor: colors.outlineVariant,
                marginBottom: 8,
                opacity: item.enabled ? 1 : 0.62,
                paddingHorizontal: 12,
                paddingVertical: 9,
              }}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                {item.logo ? (
                  <Image
                    source={{uri: item.logo}}
                    style={{
                      backgroundColor: colors.surfaceContainerHighest,
                      borderRadius: 13,
                      height: 44,
                      width: 44,
                    }}
                  />
                ) : (
                  <View
                    style={{
                      alignItems: 'center',
                      backgroundColor: colors.primaryContainer,
                      borderRadius: 13,
                      height: 44,
                      justifyContent: 'center',
                      width: 44,
                    }}>
                    <MaterialCommunityIcons name="puzzle-outline" size={22} color={colors.primary} />
                  </View>
                )}
                <View style={{flex: 1, minWidth: 0, paddingLeft: 10, paddingRight: 8}}>
                  <AppText role="bodyLargeEmphasized" numberOfLines={1} style={{color: colors.onSurface}}>
                    {item.name}
                  </AppText>
                  <AppText role="bodySmall" numberOfLines={1} style={{color: colors.onSurfaceVariant, marginTop: 1}}>
                    Version {item.version || '—'}
                  </AppText>
                </View>
                <CompactSwitch
                  accessibilityLabel={`${item.name} ${item.enabled ? 'enabled' : 'disabled'}`}
                  value={item.enabled}
                  onValueChange={() => toggle(item)}
                />
              </View>

              <View
                style={{
                  borderBottomColor: colors.outlineVariant,
                  borderBottomWidth: 1,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginTop: 7,
                  paddingBottom: 1,
                }}>
                <IconButton icon="download-outline" label="Open add-on manifest" buttonSize={36} size={19} onPress={() => openManifest(item)} contentColor={colors.onSurfaceVariant} />
                <IconButton icon="refresh" label="Update add-on" buttonSize={36} size={19} onPress={() => updateAddon(item)} disabled={updatingId === item.id} contentColor={colors.primary} />
                {configurable ? (
                  <IconButton icon="cog" label="Configure add-on" buttonSize={36} size={19} onPress={() => configure(item)} contentColor={colors.primary} />
                ) : null}
                <IconButton icon="delete" label="Remove add-on" buttonSize={36} size={19} onPress={() => remove(item)} contentColor={colors.error} />
              </View>

              <View style={{flexDirection: 'row', flexWrap: 'wrap', gap: 5, marginTop: 6}}>
                <AddonBadge label={item.enabled ? 'Active' : 'Disabled'} selected={item.enabled} />
                <AddonBadge label={`${resources} ${resources === 1 ? 'resource' : 'resources'}`} />
                <AddonBadge label={`${catalogs} ${catalogs === 1 ? 'catalog' : 'catalogs'}`} />
                {configurable ? <AddonBadge label="Configurable" /> : null}
              </View>

              <AppText role="bodySmall" numberOfLines={2} style={{color: colors.onSurfaceVariant, marginTop: 6}}>
                {item.description || 'Stremio add-on'}
              </AppText>
            </View>
          );
        }}
      />

      <Modal
        visible={installedNotice !== null}
        transparent
        animationType="fade"
        onRequestClose={() => setInstalledNotice(null)}>
        <Pressable
          style={{
            alignItems: 'center',
            backgroundColor: 'rgba(0,0,0,0.52)',
            flex: 1,
            justifyContent: 'center',
            paddingHorizontal: 24,
          }}
          onPress={() => setInstalledNotice(null)}>
          <Pressable
            style={{
              backgroundColor: colors.surfaceContainerHigh,
              borderColor: colors.outlineVariant,
              borderRadius: 28,
              borderWidth: 1,
              maxWidth: 560,
              paddingHorizontal: 24,
              paddingVertical: 22,
              width: '88%',
            }}
            onPress={event => event.stopPropagation()}>
            <Text style={{color: colors.onSurface, fontSize: 22, fontWeight: '700'}}>
              Stremio add-on installed
            </Text>
            <Text style={{color: colors.onSurfaceVariant, fontSize: 17, marginTop: 10}}>
              {installedNotice || ''}
            </Text>
            <Pressable onPress={() => setInstalledNotice(null)} style={{alignSelf: 'flex-end', marginTop: 18, padding: 8}}>
              <Text style={{color: colors.primary, fontSize: 15, fontWeight: '800'}}>OK</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
};

export default Extensions;

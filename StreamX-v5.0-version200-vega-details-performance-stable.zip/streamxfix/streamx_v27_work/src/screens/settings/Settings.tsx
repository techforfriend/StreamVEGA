import {
  DevSettings,
  ToastAndroid,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import React, {useCallback, useMemo} from 'react';
import {
  settingsStorage,
  clearAllMMKVStorage,
} from '../../lib/storage';
import * as Updates from 'expo-updates';
import type {ContentSource} from '../../lib/providers/contentSourceTypes';
import ReactNativeHapticFeedback from 'react-native-haptic-feedback';
import useContentStore from '../../lib/zustand/contentStore';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {SettingsStackParamList} from '../../App';
import {MaterialIcons} from '@expo/vector-icons';
import Animated, {FadeInUp, Layout} from 'react-native-reanimated';
import RenderProviderFlagIcon from '../../components/RenderProviderFLagIcon';
import useNavigationPreferencesStore from '../../lib/zustand/navigationPreferencesStore';
import DnsPreference from './components/DnsPreference';
import IconButton from '../../components/ui/IconButton';
import AppText from '../../components/ui/Text';
import {useM3Colors} from '../../theme/M3PaletteContext';
import {showAppDialog} from '../../lib/zustand/appDialogStore';
import {clearAppCache, formatAppCacheSize, getAppCacheSizeBytes} from '../../lib/clearAppCache';
import useTabBarScrollVisibility from '../../lib/hooks/useTabBarScrollVisibility';
import {useFocusEffect} from '@react-navigation/native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

type Props = NativeStackScreenProps<SettingsStackParamList, 'Settings'>;
import CompactSwitch from '../../components/ui/CompactSwitch';
import {NuvioRow, NuvioSection} from '../../components/ui/NuvioSettings';

const ProviderStrip = ({
  providers,
  selectedValue,
  onSelect,
}: {
  providers: ContentSource[];
  selectedValue: string;
  onSelect: (provider: ContentSource) => void;
}) => {
  const colors = useM3Colors();
  return (
    <View style={{paddingHorizontal: 12, paddingTop: 2, paddingBottom: 9, minHeight: 76}}>
      <ScrollView
        horizontal
        nestedScrollEnabled
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{paddingTop: 1, paddingRight: 6}}>
        {providers.map(item => {
          const isSelected = selectedValue === item.value;
          return (
            <TouchableOpacity
              key={item.value}
              activeOpacity={0.72}
              onPress={() => onSelect(item)}
              style={{
                width: 112,
                height: 62,
                marginRight: 7,
                borderRadius: 15,
                borderWidth: isSelected ? 2 : 1,
                borderColor: isSelected ? colors.primary : colors.outlineVariant,
                backgroundColor: isSelected
                  ? colors.primaryContainer
                  : colors.surfaceContainerHighest,
                overflow: 'hidden',
              }}>
              <View style={{flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 7}}>
                <RenderProviderFlagIcon type={item.type} />
                <AppText
                  role="labelMediumEmphasized"
                  numberOfLines={1}
                  style={{
                    color: isSelected ? colors.onPrimaryContainer : colors.onSurface,
                    marginTop: 4,
                    textAlign: 'center',
                  }}>
                  {item.display_name}
                </AppText>
                {isSelected ? (
                  <MaterialIcons
                    name="check-circle"
                    size={14}
                    color={colors.onPrimaryContainer}
                    style={{position: 'absolute', top: 6, right: 6}}
                  />
                ) : null}
              </View>
            </TouchableOpacity>
          );
        })}
        {providers.length === 0 ? (
          <View style={{minHeight: 60, justifyContent: 'center'}}>
            <AppText role="bodySmall" style={{color: colors.onSurfaceVariant}}>
              No add-ons installed
            </AppText>
          </View>
        ) : null}
      </ScrollView>
    </View>
  );
};

const Settings = ({navigation}: Props) => {
  const colors = useM3Colors();
  const insets = useSafeAreaInsets();
  const tabBarScroll = useTabBarScrollVisibility();
  const provider = useContentStore(state => state.provider);
  const setProvider = useContentStore(state => state.setProvider);
  const installedProviders = useContentStore(state => state.installedProviders);
  const [p2pStreaming, setP2pStreaming] = React.useState(
    settingsStorage.isP2PStreamingEnabled(),
  );
  const [cacheSizeBytes, setCacheSizeBytes] = React.useState(0);
  const hideDownloadsTab = useNavigationPreferencesStore(state => state.hideDownloadsTab);

  const refreshCacheSize = React.useCallback(async () => {
    const size = await getAppCacheSizeBytes();
    setCacheSizeBytes(size);
  }, []);

  useFocusEffect(
    React.useCallback(() => {
      void refreshCacheSize();
      const timer = setInterval(() => {
        void refreshCacheSize();
      }, 10000);
      return () => clearInterval(timer);
    }, [refreshCacheSize]),
  );

  const handleProviderSelect = useCallback(
    (item: ContentSource) => {
      setProvider(item);
      if (settingsStorage.isHapticFeedbackEnabled()) {
        ReactNativeHapticFeedback.trigger('virtualKey', {
          enableVibrateFallback: true,
          ignoreAndroidSystemSettings: false,
        });
      }
    },
    [setProvider],
  );

  const clearCacheHandler = useCallback(async () => {
    if (settingsStorage.isHapticFeedbackEnabled()) {
      ReactNativeHapticFeedback.trigger('virtualKey', {
        enableVibrateFallback: true,
        ignoreAndroidSystemSettings: false,
      });
    }
    await clearAppCache();
    setCacheSizeBytes(0);
    ToastAndroid.show('App cache cleared', ToastAndroid.SHORT);
  }, []);

  const eraseAllLocalData = useCallback(async () => {
    clearAllMMKVStorage();
    if (Updates.isEnabled) {
      await Updates.reloadAsync();
      return;
    }
    DevSettings.reload('All MMKV storage erased');
  }, []);

  const confirmEraseAllLocalData = useCallback(() => {
    showAppDialog({
      title: 'Erase all local data?',
      message:
        'This permanently erases every StreamX MMKV store, including settings, installed provider data, Watchlist, Continue watching, download records, and cached state. This cannot be undone. Downloaded media files on disk are not deleted.',
      variant: 'error',
      actions: [
        {label: 'Cancel'},
        {
          label: 'Erase everything',
          variant: 'destructive',
          onPress: eraseAllLocalData,
        },
      ],
    });
  }, [eraseAllLocalData]);

  const providers = useMemo(() => installedProviders, [installedProviders]);

  return (
    <Animated.ScrollView
      className="h-full w-full bg-m3-background"
      showsVerticalScrollIndicator={false}
      onScroll={tabBarScroll.onScroll}
      onScrollBeginDrag={tabBarScroll.onScrollBeginDrag}
      onScrollEndDrag={tabBarScroll.onScrollEndDrag}
      onMomentumScrollBegin={tabBarScroll.onMomentumScrollBegin}
      onMomentumScrollEnd={tabBarScroll.onMomentumScrollEnd}
      scrollEventThrottle={32}
      keyboardShouldPersistTaps="handled"
      keyboardDismissMode="on-drag"
      bounces
      overScrollMode="always"
      entering={FadeInUp.springify()}
      contentContainerStyle={{paddingHorizontal: 18, paddingTop: insets.top + 18, paddingBottom: 138}}>
      <View>
        <AppText
          role="displaySmallEmphasized"
          style={{color: colors.onBackground, fontSize: 34, lineHeight: 40, marginBottom: 13}}>
          Settings
        </AppText>

        <NuvioSection title="Content Add-on" delay={50}>
          <NuvioRow
            title="Content Add-on"
            description="Choose the installed add-on used for content discovery"
            icon="puzzle-outline"
            divider={providers.length > 0}
            compact
          />
          <ProviderStrip
            providers={providers}
            selectedValue={provider.value}
            onSelect={handleProviderSelect}
          />
        </NuvioSection>

        <NuvioSection title="Add-ons" delay={80}>
          <NuvioRow
            title="Stremio Add-ons"
            description="Install and manage Stremio catalog, metadata and stream add-ons"
            icon="puzzle-outline"
            divider
            onPress={() => navigation.navigate('Extensions')}
          />
          <NuvioRow
            title="Vega Plugins"
            description="Install and manage Vega provider plugins separately from Stremio"
            icon="puzzle-outline"
            divider={false}
            onPress={() => navigation.navigate('VegaPlugins')}
          />
        </NuvioSection>

        <NuvioSection title="Home Layout" delay={95}>
          <NuvioRow
            title="Home Layout"
            description="Choose, hide, and arrange Home catalog rows"
            icon="view-dashboard-outline"
            divider={false}
            onPress={() => navigation.navigate('HomeLayout')}
          />
        </NuvioSection>

        <NuvioSection title="Playback" delay={110}>
          <NuvioRow
            title="P2P streaming"
            description="Allow torrent/P2P streams from Stremio add-ons"
            icon="play-outline"
            divider={false}
            trailing={(
              <CompactSwitch
                accessibilityLabel="P2P streaming"
                value={p2pStreaming}
                onValueChange={next => {
                  settingsStorage.setP2PStreamingEnabled(next);
                  setP2pStreaming(next);
                }}
              />
            )}
          />
        </NuvioSection>

        <NuvioSection title="Network" delay={140}>
          <DnsPreference />
        </NuvioSection>

        <NuvioSection title="Options" delay={170}>
          <NuvioRow
            title="Appearance"
            icon="palette-outline"
            onPress={() => navigation.navigate('Appearance')}
          />
          <NuvioRow
            title="Subtitle Style"
            icon="subtitles-outline"
            onPress={() => navigation.navigate('SubTitlesPreferences')}
          />
          {hideDownloadsTab && (
            <NuvioRow
              title="Downloads"
              icon="download-circle-outline"
              onPress={() => navigation.navigate('DownloadsStack')}
            />
          )}
          <NuvioRow
            title="Preferences"
            icon="tune-variant"
            divider={false}
            onPress={() => navigation.navigate('Preferences')}
          />
        </NuvioSection>

        <NuvioSection title="Data Management" delay={200}>
          <NuvioRow
            title="Clear Cache"
            description={`${formatAppCacheSize(cacheSizeBytes)} currently used`}
            icon="delete-outline"
            trailing={
              <IconButton
                icon="delete-outline"
                label="Clear cache"
                onPress={clearCacheHandler}
              />
            }
          />
          <NuvioRow
            title="Erase all local data"
            description="Erase all local data"
            icon="delete-alert-outline"
            divider={false}
            onPress={confirmEraseAllLocalData}
          />
        </NuvioSection>

        <NuvioSection title="Backup & Restore" delay={230}>
          <NuvioRow
            title="Backup & Restore"
            description="Save and restore your StreamX settings and saved app data"
            icon="backup-restore"
            divider={false}
            onPress={() => navigation.navigate('BackupRestore')}
          />
        </NuvioSection>
      </View>
    </Animated.ScrollView>
  );
};

export default Settings;

import React, {useCallback, useEffect, useState} from 'react';
import {ActivityIndicator, Alert, FlatList, Image, Modal, RefreshControl, ScrollView, TextInput, TouchableOpacity, View} from 'react-native';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {MaterialCommunityIcons} from '@expo/vector-icons';
import {SettingsStackParamList} from '../../App';
import AppText from '../../components/ui/Text';
import IconButton from '../../components/ui/IconButton';
import CompactSwitch from '../../components/ui/CompactSwitch';
import SettingsSection from '../../components/ui/SettingsSection';
import {useM3Colors} from '../../theme/M3PaletteContext';
import useTabBarScrollVisibility from '../../lib/hooks/useTabBarScrollVisibility';
import vegaPluginManager, {VegaPluginManifest} from '../../lib/services/VegaPluginManager';
import type {SettingsField} from '../../lib/providers/types';
import useContentStore from '../../lib/zustand/contentStore';

type Props = NativeStackScreenProps<SettingsStackParamList, 'VegaPlugins'>;

const VegaPlugins = ({navigation}: Props) => {
  const colors = useM3Colors();
  const tabBarScroll = useTabBarScrollVisibility();
  const syncProviders = useContentStore(state => state.syncStremioProviders);
  const [source, setSource] = useState('');
  const [available, setAvailable] = useState<VegaPluginManifest[]>([]);
  const [installed, setInstalled] = useState<VegaPluginManifest[]>(vegaPluginManager.listInstalled());
  const [refreshing, setRefreshing] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [settingsPlugin, setSettingsPlugin] = useState<VegaPluginManifest | null>(null);
  const [settingsSchema, setSettingsSchema] = useState<SettingsField[]>([]);
  const [settingsValues, setSettingsValues] = useState<Record<string, unknown>>({});
  const [settingsLoading, setSettingsLoading] = useState(false);

  const reloadInstalled = useCallback(() => {
    setInstalled(vegaPluginManager.listInstalled());
    syncProviders();
  }, [syncProviders]);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      const list = await vegaPluginManager.fetchAvailable(source);
      setAvailable(list);
      setSource('');
      reloadInstalled();
    } catch (error) {
      Alert.alert('Vega Plugins', error instanceof Error ? error.message : 'Unable to load the provider manifest.');
    } finally {
      setRefreshing(false);
    }
  }, [reloadInstalled, source]);

  useEffect(() => {
    const saved = vegaPluginManager.getSource();
    if (saved) {
      void vegaPluginManager.fetchAvailable().then(setAvailable).catch(() => undefined);
    }
  }, []);

  const install = async (plugin: VegaPluginManifest) => {
    try {
      await vegaPluginManager.install(plugin);
      reloadInstalled();
      Alert.alert('Installed', `${plugin.display_name} is now available under Vega Plugins.`);
    } catch (error) {
      Alert.alert('Install failed', error instanceof Error ? error.message : 'Unable to install this Vega plugin.');
    }
  };

  const remove = (plugin: VegaPluginManifest) => {
    Alert.alert('Remove Vega plugin?', plugin.display_name, [
      {text: 'Cancel', style: 'cancel'},
      {text: 'Remove', style: 'destructive', onPress: () => { vegaPluginManager.remove(plugin.value, plugin.source.author); reloadInstalled(); }},
    ]);
  };

  const testProvider = async (plugin: VegaPluginManifest) => {
    setTestingId(plugin.value);
    try {
      const result = await vegaPluginManager.testProvider(plugin.value);
      const details = result.stages.map(stage => `${stage.passed ? '✓' : '✗'} ${stage.name}: ${stage.detail}`).join('\n');
      Alert.alert(result.passed ? 'Provider test passed' : 'Provider test results', `${plugin.display_name}\n\n${details}`);
    } catch (error) {
      Alert.alert('Provider test failed', error instanceof Error ? error.message : 'Unable to test this Vega provider.');
    } finally {
      setTestingId(null);
    }
  };

  const openSettings = async (plugin: VegaPluginManifest) => {
    setSettingsPlugin(plugin);
    setSettingsLoading(true);
    try {
      const schema = await vegaPluginManager.getSettingsSchema(plugin.value);
      const saved = vegaPluginManager.getSettings(plugin.value);
      const initial: Record<string, unknown> = {...saved};
      schema.forEach(field => {
        if (initial[field.key] === undefined && 'defaultValue' in field) initial[field.key] = field.defaultValue;
        if (initial[field.key] === undefined) initial[field.key] = field.type === 'toggle' ? false : field.type === 'multiselect' ? [] : field.type === 'number' ? '' : '';
      });
      setSettingsSchema(schema);
      setSettingsValues(initial);
    } catch (error) {
      setSettingsSchema([]);
      setSettingsValues(vegaPluginManager.getSettings(plugin.value));
      Alert.alert('Provider settings', error instanceof Error ? error.message : 'Unable to load settings schema.');
    } finally {
      setSettingsLoading(false);
    }
  };

  const saveSettings = () => {
    if (!settingsPlugin) return;
    const normalized: Record<string, unknown> = {...settingsValues};
    settingsSchema.forEach(field => {
      if (field.type === 'number' && normalized[field.key] !== '' && normalized[field.key] !== undefined) {
        const parsed = Number(normalized[field.key]);
        if (Number.isFinite(parsed)) normalized[field.key] = parsed;
      }
    });
    vegaPluginManager.saveSettings(settingsPlugin.value, normalized);
    setSettingsPlugin(null);
    Alert.alert('Settings saved', `${settingsPlugin.display_name} settings are saved and will be passed to subsequent provider requests.`);
  };

  const toggle = (plugin: VegaPluginManifest) => {
    vegaPluginManager.setEnabled(plugin.value, !vegaPluginManager.isEnabled(plugin.value));
    reloadInstalled();
  };

  const installedIds = new Set(installed.map(item => `${item.source.author}:${item.value}`));
  const availableProviders = available.filter(item => !installedIds.has(`${item.source.author}:${item.value}`));

  return (
    <View style={{flex: 1, backgroundColor: colors.background}}>
      <View style={{flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingTop: 18, paddingBottom: 10}}>
        <IconButton icon="arrow-left" label="Back" buttonSize={40} onPress={() => navigation.goBack()} contentColor={colors.onSurface} />
        <AppText role="headlineLargeEmphasized" style={{flex: 1, marginLeft: 10, color: colors.onBackground, fontSize: 30}}>Vega Plugins</AppText>
        <IconButton icon="refresh" label="Refresh Vega plugins" buttonSize={40} onPress={refresh} disabled={refreshing} contentColor={colors.primary} />
      </View>

      <FlatList
        data={availableProviders}
        keyExtractor={item => `${item.source.author}:${item.value}`}
        onScroll={tabBarScroll.onScroll}
        onScrollBeginDrag={tabBarScroll.onScrollBeginDrag}
        onScrollEndDrag={tabBarScroll.onScrollEndDrag}
        onMomentumScrollBegin={tabBarScroll.onMomentumScrollBegin}
        onMomentumScrollEnd={tabBarScroll.onMomentumScrollEnd}
        scrollEventThrottle={32}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} />}
        contentContainerStyle={{paddingHorizontal: 18, paddingBottom: 138}}
        ListHeaderComponent={
          <View style={{paddingBottom: 12}}>
            <SettingsSection title="Vega source">
              <View style={{padding: 14}}>
                <AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginBottom: 8}}>
                  Enter a Vega provider username (for example Zenda-Cross or vega-org) or a repository URL. Vega plugins are managed independently from Stremio add-ons.
                </AppText>
                <View style={{flexDirection: 'row', alignItems: 'center', gap: 8}}>
                  <TextInput
                    value={source}
                    onChangeText={setSource}
                    autoCapitalize="none"
                    autoCorrect={false}
                    placeholder="Username or https://github.com/user/vega-providers"
                    placeholderTextColor={colors.onSurfaceVariant}
                    style={{flex: 1, minHeight: 46, borderRadius: 12, paddingHorizontal: 12, color: colors.onSurface, backgroundColor: colors.surfaceContainerHighest}}
                  />
                  <IconButton icon="download" label="Load source" buttonSize={46} onPress={refresh} contentColor={colors.primary} />
                </View>
              </View>
            </SettingsSection>

            <SettingsSection title="Installed Vega Plugins">
              {installed.length === 0 ? (
                <View style={{padding: 16}}><AppText role="bodyMedium" style={{color: colors.onSurfaceVariant}}>No Vega plugins installed.</AppText></View>
              ) : installed.map(plugin => (
                <View key={`${plugin.source.author}:${plugin.value}`} style={{backgroundColor: colors.surfaceContainerHighest, borderColor: colors.outlineVariant, borderRadius: 18, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 13, marginHorizontal: 10, marginBottom: 10}}>
                  <View style={{flexDirection: 'row', alignItems: 'center', minHeight: 52}}>
                    {plugin.icon ? <Image source={{uri: plugin.icon}} style={{width: 44, height: 44, borderRadius: 10, marginRight: 12}} /> : <MaterialCommunityIcons name="puzzle-outline" size={36} color={colors.primary} style={{marginRight: 12}} />}
                    <View style={{flex: 1, minWidth: 0}}>
                      <AppText role="titleMediumEmphasized" style={{color: colors.onSurface}}>{plugin.display_name}</AppText>
                      <AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 3}}>{plugin.source.author} · v{plugin.version}</AppText>
                    </View>
                    <View style={{marginLeft: 12, paddingHorizontal: 4, paddingVertical: 4}}>
                      <CompactSwitch accessibilityLabel={`Enable ${plugin.display_name}`} value={vegaPluginManager.isEnabled(plugin.value)} onValueChange={() => toggle(plugin)} />
                    </View>
                  </View>
                  <View style={{borderTopWidth: 1, borderTopColor: colors.outlineVariant, marginTop: 12, paddingTop: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 12}}>
                    <IconButton icon={testingId === plugin.value ? 'timer-sand' : 'flask-outline'} label={`Test ${plugin.display_name}`} buttonSize={42} onPress={() => void testProvider(plugin)} disabled={testingId !== null} contentColor={colors.primary} />
                    <IconButton icon="cog-outline" label={`Settings for ${plugin.display_name}`} buttonSize={42} onPress={() => void openSettings(plugin)} contentColor={colors.onSurface} />
                    <IconButton icon="delete-outline" label={`Uninstall ${plugin.display_name}`} buttonSize={42} onPress={() => remove(plugin)} contentColor={colors.error} />
                  </View>
                </View>
              ))}
            </SettingsSection>
            <SettingsSection title="Available Providers">
              {availableProviders.length > 0 ? <View style={{paddingHorizontal: 10, paddingBottom: 4}}><AppText role="bodySmall" style={{color: colors.onSurfaceVariant}}>Providers not currently installed</AppText></View> : null}
            </SettingsSection>
          </View>
        }
        renderItem={({item}) => {
          const key = `${item.source.author}:${item.value}`;
          return (
            <View key={key} style={{flexDirection: 'row', alignItems: 'center', paddingVertical: 15, paddingHorizontal: 16, marginBottom: 10, borderRadius: 20, borderWidth: 1, borderColor: colors.outlineVariant, backgroundColor: colors.surfaceContainerLow}}>
              {item.icon ? <Image source={{uri: item.icon}} style={{width: 46, height: 46, borderRadius: 12, marginRight: 14}} /> : <MaterialCommunityIcons name="puzzle-outline" size={38} color={colors.primary} style={{marginRight: 14}} />}
              <View style={{flex: 1, minWidth: 0, paddingRight: 8}}>
                <AppText role="titleMediumEmphasized" style={{color: colors.onSurface}}>{item.display_name}</AppText>
                <AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 3}}>{item.source.author} · v{item.version}</AppText>
              </View>
              <IconButton icon="download-outline" label={`Install ${item.display_name}`} buttonSize={46} onPress={() => void install(item)} contentColor={colors.primary} />
            </View>
          );
        }}
        ListEmptyComponent={available.length === 0 ? <View style={{padding: 18}}><AppText role="bodyMedium" style={{color: colors.onSurfaceVariant}}>Load a Vega provider repository above to see available plugins.</AppText></View> : <View style={{padding: 18}}><AppText role="bodyMedium" style={{color: colors.onSurfaceVariant}}>All providers from this source are already installed.</AppText></View>}
      />
      <Modal visible={Boolean(settingsPlugin)} transparent animationType="slide" onRequestClose={() => setSettingsPlugin(null)}>
        <View style={{flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.58)'}}>
          <View style={{maxHeight: '82%', borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 20, backgroundColor: colors.surfaceContainerLow}}>
            <View style={{flexDirection: 'row', alignItems: 'center', marginBottom: 14}}>
              {settingsPlugin?.icon ? <Image source={{uri: settingsPlugin.icon}} style={{width: 42, height: 42, borderRadius: 10, marginRight: 12}} /> : <MaterialCommunityIcons name="puzzle-outline" size={34} color={colors.primary} style={{marginRight: 12}} />}
              <View style={{flex: 1}}>
                <AppText role="titleLargeEmphasized" style={{color: colors.onSurface}}>{settingsPlugin?.display_name || 'Provider settings'}</AppText>
                <AppText role="bodySmall" style={{color: colors.onSurfaceVariant}}>Vega provider settings</AppText>
              </View>
              <IconButton icon="close" label="Close settings" buttonSize={38} onPress={() => setSettingsPlugin(null)} contentColor={colors.onSurface} />
            </View>
            {settingsLoading ? <View style={{padding: 30, alignItems: 'center'}}><ActivityIndicator color={colors.primary} /><AppText role="bodyMedium" style={{color: colors.onSurfaceVariant, marginTop: 10}}>Loading settings…</AppText></View> : (
              <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{gap: 14, paddingBottom: 14}}>
                {settingsSchema.length === 0 ? <AppText role="bodyMedium" style={{color: colors.onSurfaceVariant}}>This provider does not expose a settings schema.</AppText> : settingsSchema.map(field => (
                  <View key={field.key} style={{padding: 12, borderRadius: 16, backgroundColor: colors.surfaceContainerHighest}}>
                    <AppText role="titleSmallEmphasized" style={{color: colors.onSurface}}>{field.label}</AppText>
                    {field.description ? <AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 3, marginBottom: 8}}>{field.description}</AppText> : null}
                    {field.type === 'toggle' ? <CompactSwitch accessibilityLabel={field.label} value={Boolean(settingsValues[field.key])} onValueChange={value => setSettingsValues(current => ({...current, [field.key]: value}))} /> : null}
                    {field.type === 'text' || field.type === 'number' ? <TextInput value={String(settingsValues[field.key] ?? '')} onChangeText={value => setSettingsValues(current => ({...current, [field.key]: value}))} keyboardType={field.type === 'number' ? 'numeric' : 'default'} placeholder={field.type === 'text' ? field.placeholder : undefined} placeholderTextColor={colors.onSurfaceVariant} style={{color: colors.onSurface, backgroundColor: colors.surface, borderRadius: 12, paddingHorizontal: 12, minHeight: 44, marginTop: 8}} /> : null}
                    {field.type === 'select' ? <View style={{flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8}}>{field.options.map(option => <TouchableOpacity key={option.value} onPress={() => setSettingsValues(current => ({...current, [field.key]: option.value}))} style={{paddingHorizontal: 12, paddingVertical: 8, borderRadius: 14, backgroundColor: settingsValues[field.key] === option.value ? colors.primaryContainer : colors.surface, borderWidth: 1, borderColor: settingsValues[field.key] === option.value ? colors.primary : colors.outlineVariant}}><AppText role="labelLarge" style={{color: settingsValues[field.key] === option.value ? colors.onPrimaryContainer : colors.onSurface}}>{option.label}</AppText></TouchableOpacity>)}</View> : null}
                    {field.type === 'multiselect' ? <View style={{flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8}}>{field.options.map(option => {const selected = Array.isArray(settingsValues[field.key]) && (settingsValues[field.key] as unknown[]).includes(option.value); return <TouchableOpacity key={option.value} onPress={() => setSettingsValues(current => {const values = Array.isArray(current[field.key]) ? current[field.key] as unknown[] : []; return {...current, [field.key]: selected ? values.filter(value => value !== option.value) : [...values, option.value]};})} style={{paddingHorizontal: 12, paddingVertical: 8, borderRadius: 14, backgroundColor: selected ? colors.primaryContainer : colors.surface, borderWidth: 1, borderColor: selected ? colors.primary : colors.outlineVariant}}><AppText role="labelLarge" style={{color: selected ? colors.onPrimaryContainer : colors.onSurface}}>{option.label}</AppText></TouchableOpacity>;})}</View> : null}
                  </View>
                ))}
              </ScrollView>
            )}
            <View style={{flexDirection: 'row', gap: 10, marginTop: 12}}>
              <TouchableOpacity onPress={() => setSettingsPlugin(null)} style={{flex: 1, minHeight: 48, alignItems: 'center', justifyContent: 'center', borderRadius: 24, borderWidth: 1, borderColor: colors.outline}}><AppText role="labelLarge" style={{color: colors.onSurface}}>Cancel</AppText></TouchableOpacity>
              <TouchableOpacity disabled={settingsLoading} onPress={saveSettings} style={{flex: 1, minHeight: 48, alignItems: 'center', justifyContent: 'center', borderRadius: 24, backgroundColor: colors.primary}}><AppText role="labelLarge" style={{color: colors.onPrimary}}>Save</AppText></TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default VegaPlugins;

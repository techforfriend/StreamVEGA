import React, {useCallback, useState} from 'react';
import {useFocusEffect} from '@react-navigation/native';
import {Modal, Pressable, ScrollView, View} from 'react-native';
import {MaterialCommunityIcons} from '@expo/vector-icons';
import {settingsStorage} from '../../../lib/storage';
import useContentStore from '../../../lib/zustand/contentStore';
import {providerManager} from '../../../lib/services/ProviderManager';
import {Catalog} from '../../../lib/providers/types';
import {useM3Colors} from '../../../theme/M3PaletteContext';
import AppText from '../../../components/ui/Text';
import SettingsRow from '../../../components/ui/SettingsRow';

const CatalogVisibilityPreference = () => {
  const colors = useM3Colors();
  const provider = useContentStore(state => state.provider);
  const [catalogs, setCatalogs] = useState<Catalog[]>([]);
  const [hidden, setHidden] = useState<string[]>(() =>
    settingsStorage.getHiddenHomeCatalogs(),
  );
  const [open, setOpen] = useState(false);

  const loadCatalogs = useCallback(async () => {
    setHidden(settingsStorage.getHiddenHomeCatalogs());
    if (!provider?.value) {
      setCatalogs([]);
      return;
    }
    try {
      const data = await providerManager.getCatalog({providerValue: provider.value});
      setCatalogs(data);
    } catch {
      setCatalogs([]);
    }
  }, [provider?.value]);

  useFocusEffect(
    useCallback(() => {
      void loadCatalogs();
    }, [loadCatalogs]),
  );

  const toggleCatalog = (filter: string) => {
    const next = hidden.includes(filter)
      ? hidden.filter(item => item !== filter)
      : [...hidden, filter];
    setHidden(next);
    settingsStorage.setHiddenHomeCatalogs(next);
  };

  const showAll = () => {
    setHidden([]);
    settingsStorage.setHiddenHomeCatalogs([]);
  };

  const hiddenCount = catalogs.filter(item => hidden.includes(item.filter)).length;

  return (
    <>
      <SettingsRow
        title="Home catalog rows"
        description={hiddenCount > 0 ? `${hiddenCount} hidden` : 'Choose which catalog rows appear on Home'}
        icon="view-list-outline"
        onPress={() => setOpen(true)}
      />
      <Modal
        visible={open}
        transparent
        animationType="fade"
        onRequestClose={() => setOpen(false)}>
        <Pressable
          onPress={() => setOpen(false)}
          style={{
            backgroundColor: 'rgba(0,0,0,0.65)',
            flex: 1,
            justifyContent: 'center',
            padding: 20,
          }}>
          <Pressable
            onPress={event => event.stopPropagation()}
            style={{
              alignSelf: 'center',
              backgroundColor: colors.surfaceContainerHigh,
              borderColor: colors.outlineVariant,
              borderRadius: 26,
              borderWidth: 1,
              maxHeight: '80%',
              maxWidth: 560,
              overflow: 'hidden',
              width: '100%',
            }}>
            <View style={{paddingHorizontal: 20, paddingTop: 20, paddingBottom: 12}}>
              <AppText role="titleLargeEmphasized" style={{color: colors.onSurface}}>
                Home catalog rows
              </AppText>
              <AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 4}}>
                Hide rows you do not want on the Home screen.
              </AppText>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              {catalogs.map(item => {
                const isHidden = hidden.includes(item.filter);
                return (
                  <Pressable
                    key={item.filter}
                    onPress={() => toggleCatalog(item.filter)}
                    style={({pressed}) => ({
                      alignItems: 'center',
                      backgroundColor: pressed ? colors.surfaceContainerHighest : 'transparent',
                      flexDirection: 'row',
                      minHeight: 60,
                      paddingHorizontal: 20,
                    })}>
                    <View style={{flex: 1, minWidth: 0, paddingRight: 12}}>
                      <AppText
                        role="bodyLarge"
                        numberOfLines={1}
                        ellipsizeMode="tail"
                        style={{color: isHidden ? colors.onSurfaceVariant : colors.onSurface}}>
                        {item.title}
                      </AppText>
                    </View>
                    <MaterialCommunityIcons
                      name={isHidden ? 'eye-off-outline' : 'eye-outline'}
                      size={23}
                      color={isHidden ? colors.onSurfaceVariant : colors.primary}
                    />
                  </Pressable>
                );
              })}
              {catalogs.length === 0 ? (
                <AppText role="bodyMedium" style={{color: colors.onSurfaceVariant, padding: 20}}>
                  No catalogs available for the selected addon.
                </AppText>
              ) : null}
            </ScrollView>

            <Pressable
              onPress={showAll}
              style={{
                alignItems: 'center',
                borderTopColor: colors.outlineVariant,
                borderTopWidth: 1,
                minHeight: 56,
                justifyContent: 'center',
              }}>
              <AppText role="labelLargeEmphasized" style={{color: colors.primary}}>
                Show all
              </AppText>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>
    </>
  );
};

export default CatalogVisibilityPreference;

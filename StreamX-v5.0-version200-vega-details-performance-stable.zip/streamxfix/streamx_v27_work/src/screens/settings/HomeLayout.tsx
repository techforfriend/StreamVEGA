import React, {useCallback, useMemo, useState} from 'react';
import {Pressable, ScrollView, View} from 'react-native';
import {useFocusEffect} from '@react-navigation/native';
import {MaterialCommunityIcons} from '@expo/vector-icons';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {SettingsStackParamList} from '../../App';
import {settingsStorage} from '../../lib/storage';
import useContentStore from '../../lib/zustand/contentStore';
import {providerManager} from '../../lib/services/ProviderManager';
import {Catalog} from '../../lib/providers/types';
import {useM3Colors} from '../../theme/M3PaletteContext';
import AppText from '../../components/ui/Text';
import NuvioSection from '../../components/ui/SettingsSection';
import SettingsRow from '../../components/ui/SettingsRow';
import IconButton from '../../components/ui/IconButton';
import useTabBarScrollVisibility from '../../lib/hooks/useTabBarScrollVisibility';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

type Props = NativeStackScreenProps<SettingsStackParamList, 'HomeLayout'>;

const applySavedOrder = (catalogs: Catalog[], savedOrder: string[]) => {
  if (!savedOrder.length) return catalogs;
  const rank = new Map(savedOrder.map((filter, index) => [filter, index]));
  return [...catalogs].sort((a, b) => {
    const ai = rank.get(a.filter);
    const bi = rank.get(b.filter);
    if (ai === undefined && bi === undefined) return 0;
    if (ai === undefined) return 1;
    if (bi === undefined) return -1;
    return ai - bi;
  });
};

const HomeLayout = ({navigation}: Props) => {
  const colors = useM3Colors();
  const insets = useSafeAreaInsets();
  const tabBarScroll = useTabBarScrollVisibility();
  const provider = useContentStore(state => state.provider);
  const [catalogs, setCatalogs] = useState<Catalog[]>([]);
  const [hidden, setHidden] = useState<string[]>(() =>
    settingsStorage.getHiddenHomeCatalogs(),
  );
  const [loading, setLoading] = useState(true);

  const loadCatalogs = useCallback(async () => {
    setLoading(true);
    setHidden(settingsStorage.getHiddenHomeCatalogs());
    if (!provider?.value) {
      setCatalogs([]);
      setLoading(false);
      return;
    }
    try {
      const data = await providerManager.getCatalog({providerValue: provider.value});
      setCatalogs(applySavedOrder(data, settingsStorage.getHomeCatalogOrder()));
    } catch (error) {
      console.warn('[HomeLayout] Failed to load catalogs:', error);
      setCatalogs([]);
    } finally {
      setLoading(false);
    }
  }, [provider?.value]);

  useFocusEffect(
    useCallback(() => {
      void loadCatalogs();
    }, [loadCatalogs]),
  );

  const visibleCount = useMemo(
    () => catalogs.filter(item => !hidden.includes(item.filter)).length,
    [catalogs, hidden],
  );

  const toggleCatalog = useCallback((filter: string) => {
    setHidden(current => {
      const next = current.includes(filter)
        ? current.filter(item => item !== filter)
        : [...current, filter];
      settingsStorage.setHiddenHomeCatalogs(next);
      return next;
    });
  }, []);

  const moveCatalog = useCallback(
    (index: number, direction: -1 | 1) => {
      setCatalogs(current => {
        const target = index + direction;
        if (target < 0 || target >= current.length) return current;
        const next = [...current];
        [next[index], next[target]] = [next[target], next[index]];
        settingsStorage.setHomeCatalogOrder(next.map(item => item.filter));
        return next;
      });
    },
    [],
  );

  const resetToDefault = useCallback(() => {
    settingsStorage.resetHomeCatalogOrder();
    settingsStorage.setHiddenHomeCatalogs([]);
    setHidden([]);
    void loadCatalogs();
  }, [loadCatalogs]);

  return (
    <View style={{flex: 1, backgroundColor: colors.background}}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        onScroll={tabBarScroll.onScroll}
        onScrollBeginDrag={tabBarScroll.onScrollBeginDrag}
        onScrollEndDrag={tabBarScroll.onScrollEndDrag}
        onMomentumScrollBegin={tabBarScroll.onMomentumScrollBegin}
        onMomentumScrollEnd={tabBarScroll.onMomentumScrollEnd}
        scrollEventThrottle={32}
        contentContainerStyle={{
          paddingHorizontal: 18,
          paddingTop: insets.top + 18,
          paddingBottom: 138,
        }}>
        <View style={{flexDirection: 'row', alignItems: 'center', marginBottom: 12}}>
          <IconButton
            icon="arrow-left"
            label="Back"
            buttonSize={40}
            onPress={() => navigation.goBack()}
            contentColor={colors.onSurface}
          />
          <View style={{flex: 1, marginLeft: 2}}>
            <AppText
              role="headlineLargeEmphasized"
              style={{color: colors.onBackground, fontSize: 30, lineHeight: 36}}>
              Home Layout
            </AppText>
          </View>
        </View>

        <NuvioSection title="Home Layout">
          <SettingsRow
            title={provider?.display_name || 'No add-on selected'}
            description={`${visibleCount} of ${catalogs.length} rows visible`}
            icon="view-dashboard-outline"
            divider={false}
          />
        </NuvioSection>

        <View style={{flexDirection: 'row', alignItems: 'center', marginBottom: 6}}>
          <AppText role="labelMediumEmphasized" style={{color: colors.onSurfaceVariant, flex: 1, letterSpacing: 1.25}}>
            CATALOGS & COLLECTIONS
          </AppText>
          <Pressable
            accessibilityRole="button"
            onPress={resetToDefault}
            disabled={loading || catalogs.length === 0}
            style={({pressed}) => ({
              paddingHorizontal: 10,
              paddingVertical: 6,
              borderRadius: 14,
              backgroundColor: pressed ? colors.surfaceContainerHighest : 'transparent',
              opacity: loading || catalogs.length === 0 ? 0.45 : 1,
            })}>
            <AppText role="labelMediumEmphasized" style={{color: colors.primary}}>
              Reset
            </AppText>
          </Pressable>
        </View>

        {loading ? (
          <NuvioSection title="Loading">
            <SettingsRow
              title="Loading catalogs…"
              icon="progress-clock"
              divider={false}
            />
          </NuvioSection>
        ) : catalogs.length === 0 ? (
          <NuvioSection title="Catalogs">
            <SettingsRow
              title="No catalogs available"
              description="No catalogs are available for the selected add-on."
              icon="playlist-remove"
              divider={false}
            />
          </NuvioSection>
        ) : (
          <View style={{gap: 6}}>
            {catalogs.map((item, index) => {
              const isHidden = hidden.includes(item.filter);
              const isFirst = index === 0;
              const isLast = index === catalogs.length - 1;
              return (
                <View
                  key={item.filter}
                  style={{
                    minHeight: 60,
                    flexDirection: 'row',
                    alignItems: 'center',
                    paddingHorizontal: 12,
                    paddingVertical: 7,
                    borderRadius: 24,
                    borderWidth: 1,
                    borderColor: colors.outlineVariant,
                    backgroundColor: colors.surfaceContainer,
                    opacity: isHidden ? 0.62 : 1,
                  }}>
                  <MaterialCommunityIcons
                    name="drag-vertical"
                    size={20}
                    color={colors.onSurfaceVariant}
                    style={{marginRight: 7}}
                  />
                  <View style={{flex: 1, minWidth: 0}}>
                    <AppText role="bodyLargeEmphasized" numberOfLines={1} style={{color: colors.onSurface}}>
                      {item.title}
                    </AppText>
                    <AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 1}}>
                      {isHidden ? 'Hidden from Home' : 'Visible on Home'}
                    </AppText>
                  </View>
                  <Pressable
                    accessibilityRole="switch"
                    accessibilityLabel={`${item.title} ${isHidden ? 'hidden' : 'visible'}`}
                    accessibilityState={{checked: !isHidden}}
                    onPress={() => toggleCatalog(item.filter)}
                    style={{
                      width: 44,
                      height: 26,
                      borderRadius: 13,
                      padding: 3,
                      justifyContent: 'center',
                      backgroundColor: !isHidden ? colors.primary : colors.surfaceContainerHighest,
                      borderWidth: 1,
                      borderColor: !isHidden ? colors.primary : colors.outlineVariant,
                    }}>
                    <View
                      style={{
                        width: 18,
                        height: 18,
                        borderRadius: 9,
                        alignSelf: !isHidden ? 'flex-end' : 'flex-start',
                        backgroundColor: !isHidden ? colors.onPrimary : colors.onSurfaceVariant,
                      }}
                    />
                  </Pressable>
                  <IconButton
                    icon="chevron-up"
                    label={`Move ${item.title} up`}
                    size={20}
                    buttonSize={36}
                    disabled={isFirst}
                    onPress={() => moveCatalog(index, -1)}
                    contentColor={colors.primary}
                  />
                  <IconButton
                    icon="chevron-down"
                    label={`Move ${item.title} down`}
                    size={20}
                    buttonSize={36}
                    disabled={isLast}
                    onPress={() => moveCatalog(index, 1)}
                    contentColor={colors.primary}
                  />
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>
    </View>
  );
};

export default HomeLayout;

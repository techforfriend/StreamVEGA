import type {NativeStackScreenProps} from '@react-navigation/native-stack';
import React from 'react';
import {Pressable, ScrollView, View} from 'react-native';
import type {SettingsStackParamList} from '../../App';
import AppearancePreference from './components/AppearancePreference';
import AppText from '../../components/ui/Text';
import {useM3Colors} from '../../theme/M3PaletteContext';
import useTabBarScrollVisibility from '../../lib/hooks/useTabBarScrollVisibility';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import IconButton from '../../components/ui/IconButton';

type Props = NativeStackScreenProps<SettingsStackParamList, 'Appearance'>;

const Appearance = ({navigation}: Props) => {
  const colors = useM3Colors();
  const tabBarScroll = useTabBarScrollVisibility();
  const insets = useSafeAreaInsets();

  return (
    <ScrollView
      style={{backgroundColor: colors.background}}
      contentContainerStyle={{
        paddingHorizontal: 18,
        paddingTop: insets.top + 18,
        paddingBottom: 138,
      }}
      showsVerticalScrollIndicator={false}
      onScroll={tabBarScroll.onScroll}
      onScrollBeginDrag={tabBarScroll.onScrollBeginDrag}
      onScrollEndDrag={tabBarScroll.onScrollEndDrag}
      onMomentumScrollBegin={tabBarScroll.onMomentumScrollBegin}
      onMomentumScrollEnd={tabBarScroll.onMomentumScrollEnd}
      scrollEventThrottle={32}>
      <View style={{flexDirection: 'row', alignItems: 'center', marginBottom: 12}}>
        <IconButton
          icon="arrow-left"
          label="Back"
          buttonSize={40}
          onPress={() => navigation.goBack()}
          contentColor={colors.onSurface}
        />
        <AppText
          role="headlineLargeEmphasized"
          style={{color: colors.onBackground, fontSize: 30, lineHeight: 36, marginLeft: 2}}>
          Appearance
        </AppText>
      </View>
      <AppearancePreference />
    </ScrollView>
  );
};

export default Appearance;

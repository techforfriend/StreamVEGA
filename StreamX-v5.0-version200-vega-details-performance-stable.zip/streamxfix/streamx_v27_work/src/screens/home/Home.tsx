import {SafeAreaView, RefreshControl, View} from 'react-native';
import Slider from '../../components/Slider';
import React, {useCallback, useEffect, useMemo, useState} from 'react';
import {useFocusEffect} from '@react-navigation/native';
import HeroOptimized from '../../components/Hero';
import {mainStorage, settingsStorage} from '../../lib/storage';
import useContentStore from '../../lib/zustand/contentStore';
import useHeroStore from '../../lib/zustand/herostore';
import {syncFromSharedFolder} from '../../lib/sync/syncService';
import {
  useHomePageData,
  getRandomHeroPost,
  clearHeroCache,
} from '../../lib/hooks/useHomePageData';
import ProviderDrawer from '../../components/ProviderDrawer';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {HomeStackParamList} from '../../App';
import {Drawer} from 'react-native-drawer-layout';
import {GestureHandlerRootView, ScrollView} from 'react-native-gesture-handler';
import {providerManager} from '../../lib/services/ProviderManager';
import {Catalog} from '../../lib/providers/types';
import Tutorial from '../../components/Touturial';
import {QueryErrorBoundary} from '../../components/ErrorBoundary';
import {StatusBar} from 'expo-status-bar';
import AppText from '../../components/ui/Text';
import {useM3Colors} from '../../theme/M3PaletteContext';
import ContinueWatching from '../../components/ContinueWatching';
import StatusBarScrim from '../../components/ui/StatusBarScrim';
import useTabBarScrollVisibility from '../../lib/hooks/useTabBarScrollVisibility';
import stremioAddonManager from '../../lib/services/StremioAddonManager';
import {queryClient} from '../../lib/client';

type Props = NativeStackScreenProps<HomeStackParamList, 'Home'>;

const Home = ({}: Props) => {
  const colors = useM3Colors();
  const [statusBarScrimVisible, setStatusBarScrimVisible] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [manualRefreshing, setManualRefreshing] = useState(false);
  const [catalogVisibilityVersion, setCatalogVisibilityVersion] = useState(0);
  const tabBarScroll = useTabBarScrollVisibility();

  // Memoize static values
  const disableDrawer = useMemo(
    () => mainStorage.getBool('disableDrawer') || false,
    [],
  );

  const provider = useContentStore(state => state.provider);
  const installedProviders = useContentStore(state => state.installedProviders);
  const setHero = useHeroStore(state => state.setHero);
  const syncStremioProviders = useContentStore(state => state.syncStremioProviders);

  // React Query for home page data with better error handling
  const {
    data: homeData = [],
    isLoading,
    error,
    refetch,
    isRefetching,
    // isStale,
  } = useHomePageData({
    provider,
    enabled: !!(installedProviders?.length && provider?.value),
  });

  // Memoized scroll handler
  const handleScroll = useCallback((event: any) => {
    const shouldShowScrim = event.nativeEvent.contentOffset.y > 12;
    setStatusBarScrimVisible(current =>
      current === shouldShowScrim ? current : shouldShowScrim,
    );
  }, []);

  // Stable hero post calculation - uses provider value for caching
  const heroPost = useMemo(() => {
    if (!homeData || homeData.length === 0) {
      return null;
    }
    return getRandomHeroPost(homeData, provider?.value);
  }, [homeData, provider?.value]);

  // Update hero only when hero post actually changes
  React.useEffect(() => {
    if (heroPost) {
      setHero(heroPost);
    } else {
      setHero({link: '', image: '', title: ''});
    }
  }, [heroPost, setHero]);

  useFocusEffect(
    useCallback(() => {
      setCatalogVisibilityVersion(version => version + 1);
      syncFromSharedFolder().catch(e =>
        console.warn('[StreamXSync] Home focus sync failed:', e),
      );
    }, []),
  );

  // Pull-to-refresh refreshes addon manifests concurrently, syncs provider state,
  // forces a fresh Home/catalog request, and invalidates cached streams/episodes
  // so they can revalidate immediately in the background.
  const handleRefresh = useCallback(async () => {
    setManualRefreshing(true);
    try {
      clearHeroCache(provider?.value);

      await Promise.all([
        stremioAddonManager.refreshAll(),
        syncFromSharedFolder().catch(e =>
          console.warn('[StreamXSync] Home refresh sync failed:', e),
        ),
      ]);
      syncStremioProviders();
      setCatalogVisibilityVersion(version => version + 1);

      void queryClient.invalidateQueries({
        queryKey: ['catalog'],
        refetchType: 'all',
      });
      void queryClient.invalidateQueries({
        queryKey: ['stream'],
        refetchType: 'all',
      });
      void queryClient.invalidateQueries({
        queryKey: ['episodes'],
        refetchType: 'all',
      });

      await refetch();
    } catch (refreshError) {
      console.error('Error refreshing home data:', refreshError);
    } finally {
      setManualRefreshing(false);
    }
  }, [provider?.value, refetch, syncStremioProviders]);

  // Catalog is loaded from the active Stremio add-on.
  const [skeletonCatalog, setSkeletonCatalog] = useState<Catalog[]>([]);

  useEffect(() => {
    if (!provider?.value) {
      setSkeletonCatalog([]);
      return;
    }
    let cancelled = false;
    providerManager
      .getCatalog({providerValue: provider.value})
      .then(catalog => {
        if (!cancelled) {
          setSkeletonCatalog(catalog);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setSkeletonCatalog([]);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [provider?.value]);

  const homeCatalogOrder = useMemo(
    () => settingsStorage.getHomeCatalogOrder(),
    [catalogVisibilityVersion],
  );
  const catalogOrderRank = useMemo(
    () => new Map(homeCatalogOrder.map((filter, index) => [filter, index])),
    [homeCatalogOrder],
  );

  const sortCatalogsBySavedOrder = useCallback(
    <T extends {filter: string},>(items: T[]) =>
      [...items].sort((a, b) => {
        const ai = catalogOrderRank.get(a.filter);
        const bi = catalogOrderRank.get(b.filter);
        if (ai === undefined && bi === undefined) return 0;
        if (ai === undefined) return 1;
        if (bi === undefined) return -1;
        return ai - bi;
      }),
    [catalogOrderRank],
  );

  const hiddenCatalogs = useMemo(
    () => new Set(settingsStorage.getHiddenHomeCatalogs()),
    [homeData, catalogVisibilityVersion],
  );

  // Memoized loading skeleton
  const loadingSliders = useMemo(
    () =>
      sortCatalogsBySavedOrder(skeletonCatalog)
        .filter(item => !hiddenCatalogs.has(item.filter))
        .slice(0, 4)
        .map((item, index) => (
        <Slider
          isLoading={true}
          key={`loading-${item.filter}`}
          title={item.title}
          posts={[]}
          filter={item.filter}
        />
      )),
    [hiddenCatalogs, skeletonCatalog, sortCatalogsBySavedOrder],
  );

  // Memoized content sliders
  const contentSliders = useMemo(() => {
    return sortCatalogsBySavedOrder(homeData)
      .filter(item => !hiddenCatalogs.has(item.filter))
      .filter(item => item.Posts?.length > 0)
      .map((item, index) => (
        <Slider
          isLoading={false}
          key={`content-${item.filter}`}
          title={item.title}
          posts={item.Posts}
          filter={item.filter}
        />
      ));
  }, [hiddenCatalogs, homeData, sortCatalogsBySavedOrder]);

  // Memoized error message - only show if there is no cached data and an error occurred
  const errorComponent = useMemo(() => {
    if (homeData.length > 0 || isLoading || !error) {
      return null;
    }

    return (
      <View className="m-4 min-h-64 flex-1 items-center justify-center rounded-3xl bg-m3-error-container p-4">
        <AppText
          role="titleMediumEmphasized"
          className="text-center text-m3-on-error-container">
          {error?.message || 'Failed to load content'}
        </AppText>
        <AppText
          role="bodyMedium"
          className="mt-1 text-center text-m3-on-error-container">
          Pull to refresh and try again
        </AppText>
      </View>
    );
  }, [error, isLoading, homeData.length]);

  // Early return for no providers
  if (
    !installedProviders ||
    installedProviders.length === 0 ||
    !provider?.value
  ) {
    return <Tutorial />;
  }

  return (
    <QueryErrorBoundary>
      <GestureHandlerRootView style={{flex: 1}}>
        <StatusBarScrim visible={statusBarScrimVisible} />
        <SafeAreaView className="flex-1 bg-m3-background">
          <Drawer
            open={isDrawerOpen}
            onOpen={() => setIsDrawerOpen(true)}
            onClose={() => setIsDrawerOpen(false)}
            drawerPosition="left"
            drawerType="front"
            drawerStyle={{width: 200, backgroundColor: 'transparent'}}
            swipeEdgeWidth={disableDrawer ? 0 : 70}
            swipeEnabled={!disableDrawer}
            renderDrawerContent={() =>
              !disableDrawer ? (
                <ProviderDrawer onClose={() => setIsDrawerOpen(false)} />
              ) : null
            }>
            <StatusBar style="light" />

            <ScrollView
              onScroll={event => {
                handleScroll(event);
                tabBarScroll.onScroll(event);
              }}
              onScrollBeginDrag={tabBarScroll.onScrollBeginDrag}
              onScrollEndDrag={tabBarScroll.onScrollEndDrag}
              onMomentumScrollBegin={tabBarScroll.onMomentumScrollBegin}
              onMomentumScrollEnd={tabBarScroll.onMomentumScrollEnd}
              scrollEventThrottle={16}
              showsVerticalScrollIndicator={false}
              removeClippedSubviews
              className="bg-m3-background"
              refreshControl={
                <RefreshControl
                  colors={[colors.primary]}
                  tintColor={colors.primary}
                  progressBackgroundColor={colors.surfaceContainer}
                  progressViewOffset={8}
                  refreshing={manualRefreshing || isRefetching}
                  onRefresh={handleRefresh}
                />
              }>
              <HeroOptimized
                isDrawerOpen={isDrawerOpen}
                onOpenDrawer={() => setIsDrawerOpen(true)}
              />

              <View style={{marginTop: 8, paddingHorizontal: 14}}>
                <ContinueWatching />
              </View>

              <View className="relative z-20 pb-8" style={{paddingTop: 4}}>
                {isLoading ? loadingSliders : contentSliders}
                {errorComponent}
              </View>

              <View className="h-8" />
            </ScrollView>
          </Drawer>
        </SafeAreaView>
      </GestureHandlerRootView>
    </QueryErrorBoundary>
  );
};

export default React.memo(Home);

import React, {useEffect} from 'react';
import './global.css';
import Home from './screens/home/Home';
import Info from './screens/home/Info';
import Player from './screens/home/Player';
import Settings from './screens/settings/Settings';
import WatchList from './screens/WatchList';
import Search from './screens/Search';
import ScrollList from './screens/ScrollList';
import {
  NavigationContainer,
  createNavigationContainerRef,
} from '@react-navigation/native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import 'react-native-reanimated';
import 'react-native-gesture-handler';
import WebView from './screens/WebView';
import SearchResults from './screens/SearchResults';
import * as SystemUI from 'expo-system-ui';
import BootSplash from 'react-native-bootsplash';
import {SystemBars} from 'react-native-edge-to-edge';
import {enableFreeze, enableScreens} from 'react-native-screens';
import Preferences from './screens/settings/Preference';
import Appearance from './screens/settings/Appearance';
import {M3ThemeProvider} from './theme/M3ThemeProvider';
import {AppState, Linking, LogBox, useWindowDimensions, View} from 'react-native';
import {EpisodeLink, Stream} from './lib/providers/types';
import {
  SafeAreaProvider,
  useSafeAreaInsets,
} from 'react-native-safe-area-context';
import Downloads from './screens/downloads/Downloads';
import DownloadedDetails from './screens/downloads/DownloadedDetails';
import SubtitlePreference from './screens/settings/SubtitleSettings';
import Extensions from './screens/settings/Extensions';
import VegaPlugins from './screens/settings/VegaPlugins';
import HomeLayout from './screens/settings/HomeLayout';
import BackupRestore from './screens/settings/BackupRestore';
import Constants from 'expo-constants';
import {settingsStorage} from './lib/storage';
import {QueryClientProvider} from '@tanstack/react-query';
import {queryClient} from './lib/client';
import GlobalErrorBoundary from './components/GlobalErrorBoundary';
import notifee, {EventType} from '@notifee/react-native';
import notificationService from './lib/services/Notification';
import WafWebViewDialog from './components/WafWebViewDialog';
import {syncDohSettings} from './lib/services/dohService';
import stremioAddonManager from './lib/services/StremioAddonManager';
import useContentStore from './lib/zustand/contentStore';
import {
  reconcileCompletedDownloadOutputs,
  reconcileDownloadState,
} from './lib/downloadReconciliation';
import useDownloadsStore from './lib/zustand/downloadsStore';
import useNavigationPreferencesStore from './lib/zustand/navigationPreferencesStore';
import {
  initializeSyncService,
  publishSyncManifest,
  syncFromSharedFolder,
} from './lib/sync/syncService';
import StreamingTabBar from './components/navigation/StreamingTabBar';
import AppDialogHost from './components/AppDialogHost';
import {
  getAnalytics,
  getCrashlytics,
  isFirebaseNativeReady,
} from './lib/utils/firebaseSafe';

enableScreens(true);
enableFreeze(true);

export type HomeStackParamList = {
  Home: undefined;
  Info: {link: string; provider?: string; poster?: string};
  ScrollList: {
    filter: string;
    title?: string;
    providerValue?: string;
    isSearch: boolean;
  };
  Webview: {link: string};
};

export type RootStackParamList = {
  TabStack:
    | {
        screen?: keyof TabStackParamList;
        params?: {
          screen?: string;
          params?: {
            screen?: string;
            params?: any;
          };
        };
      }
    | undefined;
  Player: {
    linkIndex: number;
    episodeList: EpisodeLink[];
    directUrl?: string;
    type: string;
    primaryTitle?: string;
    secondaryTitle?: string;
    poster: {
      logo?: string;
      poster?: string;
      background?: string;
    };
    file?: string;
    providerValue?: string;
    infoUrl?: string;
    directStream?: Stream;
  };
};

export type SearchStackParamList = {
  Search: undefined;
  ScrollList: {
    filter: string;
    title?: string;
    providerValue?: string;
    isSearch: boolean;
  };
  Info: {link: string; provider?: string; poster?: string};
  SearchResults: {filter: string; availableProviders?: string[]};
};

export type WatchListStackParamList = {
  WatchList: undefined;
  Info: {link: string; provider?: string; poster?: string};
};

export type SettingsStackParamList = {
  Settings: undefined;
  Appearance: undefined;
  Preferences: undefined;
  SubTitlesPreferences: undefined;
  Extensions: {initialAddonUrl?: string} | undefined;
  VegaPlugins: undefined;
  HomeLayout: undefined;
  DownloadsStack: undefined;
  BackupRestore: undefined;
};

export type DownloadsStackParamList = {
  Downloads: undefined;
  DownloadedDetails: {groupId: string};
};

export type TabStackParamList = {
  HomeStack: undefined;
  SearchStack: undefined;
  WatchListStack: undefined;
  DownloadsStack: undefined;
  SettingsStack: undefined;
};
const Tab = createBottomTabNavigator<TabStackParamList>();
export const navigationRef = createNavigationContainerRef<RootStackParamList>();
let pendingDownloadsNavigation = false;

let pendingAddonInstallUrl: string | null = null;

export const normalizeAddonDeepLink = (incoming: string): string | null => {
  try {
    const value = incoming.trim();
    if (!value) return null;

    // Stremio install links use: stremio://<addon-host>/manifest.json
    // Convert the custom scheme to HTTPS before validating the manifest URL.
    if (!/^stremio:\/\//i.test(value)) return null;

    const converted = value.replace(/^stremio:\/\//i, 'https://');
    const parsed = new URL(converted);
    const pathname = decodeURIComponent(parsed.pathname);

    // The previous implementation accidentally matched a literal backslash
    // before the dot (`\\.json`), so valid /manifest.json links were rejected.
    if (!parsed.hostname || !/\/manifest\.json$/i.test(pathname)) return null;

    return parsed.toString();
  } catch {
    return null;
  }
};

export const openAddonInstallScreen = (addonUrl: string): void => {
  const normalized = normalizeAddonDeepLink(addonUrl) || addonUrl;
  if (!navigationRef.isReady()) {
    pendingAddonInstallUrl = normalized;
    return;
  }
  pendingAddonInstallUrl = null;
  navigationRef.navigate('TabStack', {
    screen: 'SettingsStack',
    params: {
      screen: 'Extensions',
      params: {initialAddonUrl: normalized},
    },
  });
};

export const openDownloadsScreen = (): void => {
  if (!navigationRef.isReady()) {
    pendingDownloadsNavigation = true;
    return;
  }
  pendingDownloadsNavigation = false;
  if (settingsStorage.hideDownloadsTab()) {
    navigationRef.navigate('TabStack', {
      screen: 'SettingsStack',
      params: {screen: 'DownloadsStack'},
    });
    return;
  }
  navigationRef.navigate('TabStack', {screen: 'DownloadsStack'});
};

const App = () => {
  const {width: windowWidth, height: windowHeight} = useWindowDimensions();
  const isLargeScreen = Math.min(windowWidth, windowHeight) >= 600;
  LogBox.ignoreLogs([
    'You have passed a style to FlashList',
    'new NativeEventEmitter()',
  ]);
  const HomeStack = createNativeStackNavigator<HomeStackParamList>();
  const Stack = createNativeStackNavigator<RootStackParamList>();
  const SearchStack = createNativeStackNavigator<SearchStackParamList>();
  const WatchListStack = createNativeStackNavigator<WatchListStackParamList>();
  const DownloadsStack = createNativeStackNavigator<DownloadsStackParamList>();
  const SettingsStack = createNativeStackNavigator<SettingsStackParamList>();
  const hasFirebase =
    Boolean(Constants?.expoConfig?.extra?.hasFirebase) &&
    isFirebaseNativeReady();

  // const showTabBarLables = settingsStorage.showTabBarLabels();

  useEffect(() => {
    let reconciled = false;
    const reconcile = () => {
      if (reconciled) {
        return;
      }
      reconciled = true;
      reconcileDownloadState()
        .then(() => initializeSyncService())
        .catch(error => console.error('Download startup failed:', error));
    };

    if (useDownloadsStore.persist.hasHydrated()) {
      reconcile();
      return;
    }
    return useDownloadsStore.persist.onFinishHydration(reconcile);
  }, []);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', state => {
      if (state === 'active') {
        reconcileCompletedDownloadOutputs().catch(error =>
          console.warn('Download foreground reconciliation failed:', error),
        );
        syncFromSharedFolder().catch(error =>
          console.warn('[StreamXSync] Foreground sync failed:', error),
        );
      } else {
        publishSyncManifest().catch(error =>
          console.warn('[StreamXSync] Background publish failed:', error),
        );
      }
    });
    return () => subscription.remove();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (AppState.currentState === 'active') {
        syncFromSharedFolder().catch(error =>
          console.warn('[StreamXSync] Periodic sync failed:', error),
        );
      }
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const optIn = settingsStorage.isTelemetryOptIn();
    if (hasFirebase) {
      try {
        const crashlytics = getCrashlytics();
        crashlytics && crashlytics().setCrashlyticsCollectionEnabled(optIn);
      } catch {}
      try {
        const analytics = getAnalytics();
        analytics && analytics().setAnalyticsCollectionEnabled(optIn);
      } catch {}
      try {
        const analytics = getAnalytics();
        analytics &&
          analytics().setConsent({
            analytics_storage: optIn,
            ad_storage: optIn,
            ad_user_data: optIn,
            ad_personalization: optIn,
          });
      } catch {}

      // Mark app open
      try {
        const analytics = getAnalytics();
        analytics && analytics().logAppOpen();
      } catch {}
      // Example user property: theme
      try {
        const analytics = getAnalytics();
        analytics &&
          analytics().setUserProperty('theme_preference', 'fixed-neutral');
      } catch {}

      // Initial Crashlytics log
      try {
        const crashlytics = getCrashlytics();
        crashlytics && crashlytics().log('App mounted');
      } catch {}
    }

    const unsubscribe = notifee.onForegroundEvent(({type, detail}) => {
      notificationService.actionHandler({type, detail});
    });
    notifee
      .getInitialNotification()
      .then(initialNotification => {
        if (!initialNotification) {
          return;
        }
        const pressActionId = initialNotification.pressAction?.id;
        return notificationService.actionHandler({
          type:
            pressActionId && pressActionId !== 'default'
              ? EventType.ACTION_PRESS
              : EventType.PRESS,
          detail: initialNotification,
        });
      })
      .catch(error =>
        console.warn('Failed to handle initial notification:', error),
      );
    return () => {
      unsubscribe();
    };
  }, []);

  // Initialize DNS over HTTPS.
  useEffect(() => {
    syncDohSettings().catch(e =>
      console.warn('[DoH] Failed to sync settings:', e),
    );
  }, []);

  // Capture Stremio add-on install links from websites.
  // Stremio's documented addon install protocol is stremio://<host>/manifest.json.
  useEffect(() => {
    const handleUrl = (incoming: string | null) => {
      if (!incoming) return;
      const normalized = normalizeAddonDeepLink(incoming);
      if (normalized) openAddonInstallScreen(normalized);
    };

    Linking.getInitialURL()
      .then(handleUrl)
      .catch(error => console.warn('[Stremio] Initial deep link failed:', error));

    const subscription = Linking.addEventListener('url', event => handleUrl(event.url));
    return () => subscription.remove();
  }, []);

  // Keep installed Stremio add-ons self-updating while the app is in the foreground.
  useEffect(() => {
    const refreshAddons = () => {
      void stremioAddonManager
        .refreshIfNeeded({timeoutMs: 2500, minIntervalMs: 15 * 60 * 1000})
        .then(() => useContentStore.getState().syncStremioProviders())
        .catch(error => console.warn('[Stremio] Automatic add-on refresh failed:', error));
    };

    refreshAddons();
    const subscription = AppState.addEventListener('change', state => {
      if (state === 'active') refreshAddons();
    });
    const interval = setInterval(() => {
      if (AppState.currentState === 'active') refreshAddons();
    }, 15 * 60 * 1000);

    return () => {
      subscription.remove();
      clearInterval(interval);
    };
  }, []);

  function HomeStackScreen() {
    return (
      <HomeStack.Navigator
        screenOptions={{
          headerShown: false,
          animation: 'ios_from_right',
          animationDuration: 200,
          freezeOnBlur: true,
          gestureEnabled: true,
        }}>
        <HomeStack.Screen name="Home" component={Home} />
        <HomeStack.Screen name="Info" component={Info} />
        <HomeStack.Screen name="ScrollList" component={ScrollList} />
        <HomeStack.Screen name="Webview" component={WebView} />
      </HomeStack.Navigator>
    );
  }

  function SearchStackScreen() {
    return (
      <SearchStack.Navigator
        screenOptions={{
          headerShown: false,
          animation: 'ios_from_right',
          animationDuration: 200,
          freezeOnBlur: true,
          gestureEnabled: true,
        }}>
        <SearchStack.Screen name="Search" component={Search} />
        <SearchStack.Screen name="ScrollList" component={ScrollList} />
        <SearchStack.Screen name="Info" component={Info} />
        <SearchStack.Screen name="SearchResults" component={SearchResults} />
        <HomeStack.Screen name="Webview" component={WebView} />
      </SearchStack.Navigator>
    );
  }

  function WatchListStackScreen() {
    return (
      <WatchListStack.Navigator
        screenOptions={{
          headerShown: false,
          animation: 'ios_from_right',
          animationDuration: 200,
          freezeOnBlur: true,
          gestureEnabled: true,
        }}>
        <WatchListStack.Screen name="WatchList" component={WatchList} />
        <WatchListStack.Screen name="Info" component={Info} />
      </WatchListStack.Navigator>
    );
  }

  function SettingsStackScreen() {
    const insets = useSafeAreaInsets();
    const subpageOptions = {
      contentStyle: {paddingTop: insets.top},
    };

    return (
      <SettingsStack.Navigator
        screenOptions={{
          headerShown: false,
          animation: 'ios_from_right',
          animationDuration: 200,
          freezeOnBlur: true,
          gestureEnabled: true,
        }}>
        <SettingsStack.Screen name="Settings" component={Settings} />
        <SettingsStack.Screen
          name="Appearance"
          component={Appearance}
          options={subpageOptions}
        />
        <SettingsStack.Screen
          name="Preferences"
          component={Preferences}
          options={subpageOptions}
        />
        <SettingsStack.Screen
          name="Extensions"
          component={Extensions}
          options={subpageOptions}
        />
        <SettingsStack.Screen
          name="VegaPlugins"
          component={VegaPlugins}
          options={subpageOptions}
        />
        <SettingsStack.Screen
          name="HomeLayout"
          component={HomeLayout}
          options={subpageOptions}
        />
        <SettingsStack.Screen
          name="DownloadsStack"
          component={DownloadsStackScreen}
          options={subpageOptions}
        />
        <SettingsStack.Screen
          name="SubTitlesPreferences"
          component={SubtitlePreference}
          options={subpageOptions}
        />
        <SettingsStack.Screen
          name="BackupRestore"
          component={BackupRestore}
          options={subpageOptions}
        />
      </SettingsStack.Navigator>
    );
  }

  function DownloadsStackScreen() {
    return (
      <DownloadsStack.Navigator
        screenOptions={{
          headerShown: false,
          animation: 'ios_from_right',
          animationDuration: 200,
          freezeOnBlur: true,
          gestureEnabled: true,
        }}>
        <DownloadsStack.Screen name="Downloads" component={Downloads} />
        <DownloadsStack.Screen
          name="DownloadedDetails"
          component={DownloadedDetails}
        />
      </DownloadsStack.Navigator>
    );
  }
  function TabStack() {
    const hideDownloadsTab = useNavigationPreferencesStore(
      state => state.hideDownloadsTab,
    );
    return (
      <Tab.Navigator
        detachInactiveScreens={true}
        tabBar={props => <StreamingTabBar {...props} />}
        screenOptions={{
          animation: 'shift',
          popToTopOnBlur: false,
          tabBarPosition: isLargeScreen ? 'left' : 'bottom',
          headerShown: false,
          freezeOnBlur: true,
          gestureEnabled: true,
          tabBarHideOnKeyboard: true,
        }}>
        <Tab.Screen
          name="HomeStack"
          component={HomeStackScreen}
          options={{
            title: 'Home',
            tabBarIcon: ({focused, color, size}) => (
              <MaterialCommunityIcons
                name={focused ? 'home-variant' : 'home-variant-outline'}
                color={color}
                size={size}
              />
            ),
          }}
        />
        <Tab.Screen
          name="SearchStack"
          component={SearchStackScreen}
          options={{
            title: 'Search',
            tabBarIcon: ({focused, color, size}) => (
              <MaterialCommunityIcons
                name={focused ? 'magnify' : 'magnify'}
                color={color}
                size={size}
              />
            ),
          }}
        />
        <Tab.Screen
          name="WatchListStack"
          component={WatchListStackScreen}
          options={{
            title: 'Watch List',
            tabBarIcon: ({focused, color, size}) => (
              <MaterialCommunityIcons
                name={focused ? 'bookmark' : 'bookmark-outline'}
                color={color}
                size={size}
              />
            ),
          }}
        />
        {!hideDownloadsTab && (
          <Tab.Screen
            name="DownloadsStack"
            component={DownloadsStackScreen}
            options={{
              title: 'Downloads',
              tabBarIcon: ({focused, color, size}) => (
                <MaterialCommunityIcons
                  name={focused ? 'download' : 'download-outline'}
                  color={color}
                  size={size}
                />
              ),
            }}
          />
        )}
        <Tab.Screen
          name="SettingsStack"
          component={SettingsStackScreen}
          options={{
            title: 'Settings',
            tabBarIcon: ({focused, color, size}) => (
              <MaterialCommunityIcons
                name={focused ? 'cog' : 'cog-outline'}
                color={color}
                size={size}
              />
            ),
          }}
        />
      </Tab.Navigator>
    );
  }


  return (
    <SafeAreaProvider>
      <SystemBars style="light" />
      <M3ThemeProvider>
        <AppDialogHost />
        <GlobalErrorBoundary>
          <QueryClientProvider client={queryClient}>
            <View className="flex-1 bg-black">
              <NavigationContainer
                ref={navigationRef}
                onReady={async () => {
                  if (pendingDownloadsNavigation) {
                    openDownloadsScreen();
                  }
                  if (pendingAddonInstallUrl) {
                    const addonUrl = pendingAddonInstallUrl;
                    pendingAddonInstallUrl = null;
                    openAddonInstallScreen(addonUrl);
                  }
                  // Hide bootsplash
                  await BootSplash.hide({fade: false});
                  // Track initial screen
                  if (hasFirebase) {
                    try {
                      const route = navigationRef.getCurrentRoute();
                      if (route?.name) {
                        const analytics = getAnalytics();
                        analytics &&
                          (await analytics().logScreenView({
                            screen_name: route.name,
                            screen_class: 'Navigation',
                          }));
                      }
                    } catch {}
                  }
                }}
                onStateChange={async () => {
                  if (hasFirebase) {
                    try {
                      const route = navigationRef.getCurrentRoute();
                      if (route?.name) {
                        const analytics = getAnalytics();
                        analytics &&
                          (await analytics().logScreenView({
                            screen_name: route.name,
                            screen_class: 'Navigation',
                          }));
                      }
                    } catch {}
                  }
                }}
                theme={{
                  fonts: {
                    regular: {
                      fontFamily: 'Inter_400Regular',
                      fontWeight: '400',
                    },
                    medium: {
                      fontFamily: 'Inter_500Medium',
                      fontWeight: '500',
                    },
                    bold: {
                      fontFamily: 'Inter_700Bold',
                      fontWeight: '700',
                    },
                    heavy: {
                      fontFamily: 'Inter_800ExtraBold',
                      fontWeight: '800',
                    },
                  },
                  dark: true,
                  colors: {
                    background: 'transparent',
                    card: 'black',
                    primary: '#E4E4E4',
                    text: 'white',
                    border: 'black',
                    notification: '#E4E4E4',
                  },
                }}>
                <Stack.Navigator
                  screenOptions={{
                    headerShown: false,
                    animation: 'ios_from_right',
                    animationDuration: 200,
                    freezeOnBlur: true,
          gestureEnabled: true,
                    contentStyle: {backgroundColor: 'transparent'},
                  }}>
                  <Stack.Screen name="TabStack" component={TabStack} />
                  <Stack.Screen
                    name="Player"
                    component={Player}
                    options={{
                      orientation: 'landscape',
                      animation: 'fade',
                      animationDuration: 220,
                      statusBarHidden: true,
                      navigationBarHidden: true,
                      autoHideHomeIndicator: true,
                    }}
                  />
                </Stack.Navigator>
              </NavigationContainer>
              {/* Global WAF / captcha solving dialog, triggered by providers via
                providerContext.openWebView */}
              <WafWebViewDialog />
              {/* Isolated realm that runs untrusted provider code. Must stay
                mounted for the app lifetime: every provider call is dispatched
                into it. */}
            </View>
          </QueryClientProvider>
        </GlobalErrorBoundary>
      </M3ThemeProvider>
    </SafeAreaProvider>
  );
};

export default App;

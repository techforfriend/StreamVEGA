import {NativeModules, Platform} from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import * as DocumentPicker from 'expo-document-picker';
import * as RNFS from '@dr.pogodin/react-native-fs';
import {mainStorage, providerKvStorage} from './storage/StorageService';
import type {StorageBackupEntry} from './storage/StorageService';

const BACKUP_FORMAT = 'streamx-backup';
const BACKUP_VERSION = 2;
const SUPPORTED_BACKUP_VERSIONS = new Set([1, BACKUP_VERSION]);
const BACKUP_FILE_PREFIX = 'StreamX-Backup';
const MIME_TYPE = 'application/json';

type StorageEntries = Record<string, StorageBackupEntry>;

export interface StreamXBackup {
  format: typeof BACKUP_FORMAT;
  version: 1 | typeof BACKUP_VERSION;
  createdAt: string;
  stores: {
    main: StorageEntries;
    providerKv: StorageEntries;
  };
}

export interface BackupResult {
  canceled: boolean;
  fileName?: string;
}

export interface RestoreResult {
  canceled: boolean;
  fileName?: string;
}

type SafCopyModule = {
  copyFileToUri?: (fromPath: string, toUri: string) => Promise<void>;
};

const getFileName = (): string => {
  const stamp = new Date()
    .toISOString()
    .replace(/[:.]/g, '-')
    .replace(/Z$/, 'Z');
  return `${BACKUP_FILE_PREFIX}-${stamp}.json`;
};

const buildBackup = async (): Promise<StreamXBackup> => ({
  format: BACKUP_FORMAT,
  version: BACKUP_VERSION,
  createdAt: new Date().toISOString(),
  stores: {
    main: await mainStorage.exportEntries(),
    providerKv: await providerKvStorage.exportEntries(),
  },
});

const validateEntries = (value: unknown): StorageEntries => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('Backup storage data is invalid');
  }

  for (const [key, entry] of Object.entries(value as Record<string, unknown>)) {
    if (!key || !entry || typeof entry !== 'object' || Array.isArray(entry)) {
      throw new Error('Backup contains invalid storage entries');
    }
    const typed = entry as Partial<StorageBackupEntry>;
    if (typed.type === 'string' && typeof typed.value === 'string') continue;
    if (typed.type === 'boolean' && typeof typed.value === 'boolean') continue;
    if (typed.type === 'number' && typeof typed.value === 'number' && Number.isFinite(typed.value)) continue;
    throw new Error('Backup contains invalid storage values');
  }

  return value as StorageEntries;
};

const validateBackup = (value: unknown): StreamXBackup => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('Invalid backup file');
  }

  const backup = value as Partial<StreamXBackup>;
  if (backup.format !== BACKUP_FORMAT || !SUPPORTED_BACKUP_VERSIONS.has(backup.version as number)) {
    throw new Error('Unsupported or invalid StreamX backup');
  }
  if (!backup.stores || typeof backup.stores !== 'object' || Array.isArray(backup.stores)) {
    throw new Error('Backup data is missing');
  }

  return {
    format: BACKUP_FORMAT,
    version: BACKUP_VERSION,
    createdAt:
      typeof backup.createdAt === 'string' ? backup.createdAt : new Date().toISOString(),
    stores: {
      main: validateEntries(backup.stores.main),
      providerKv: validateEntries(backup.stores.providerKv),
    },
  };
};

const createLocalBackupFile = async (
  fileName: string,
  contents: string,
): Promise<string> => {
  const localPath = `${RNFS.CachesDirectoryPath}/${fileName}`;
  await RNFS.writeFile(localPath, contents, 'utf8');
  return localPath;
};

const saveAndroidBackup = async (
  fileName: string,
  contents: string,
): Promise<BackupResult> => {
  const permissions =
    await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();
  if (!permissions.granted) {
    return {canceled: true};
  }

  const targetUri = await FileSystem.StorageAccessFramework.createFileAsync(
    permissions.directoryUri,
    fileName,
    MIME_TYPE,
  );

  const localPath = await createLocalBackupFile(fileName, contents);
  const safCopyModule = NativeModules.SafCopyModule as SafCopyModule | undefined;

  try {
    if (!safCopyModule?.copyFileToUri) {
      throw new Error('Backup file bridge is unavailable');
    }
    await safCopyModule.copyFileToUri(localPath, targetUri);
    return {canceled: false, fileName};
  } catch (error) {
    await FileSystem.StorageAccessFramework.deleteAsync(targetUri).catch(() => undefined);
    throw error;
  } finally {
    await RNFS.unlink(localPath).catch(() => undefined);
  }
};

const saveIosBackup = async (
  fileName: string,
  contents: string,
): Promise<BackupResult> => {
  const pickedFolders = await RNFS.pickFile({pickerType: 'folder'});
  const pickedFolder = pickedFolders[0];
  if (!pickedFolder) {
    return {canceled: true};
  }

  const folderPath = pickedFolder.replace(/^file:\/\//, '').replace(/\/+$/, '');
  await RNFS.writeFile(`${folderPath}/${fileName}`, contents, 'utf8');
  return {canceled: false, fileName};
};

export const createAndSaveBackup = async (): Promise<BackupResult> => {
  const backup = await buildBackup();
  const contents = JSON.stringify(backup, null, 2);
  const fileName = getFileName();

  if (Platform.OS === 'android') {
    return saveAndroidBackup(fileName, contents);
  }

  if (Platform.OS === 'ios') {
    return saveIosBackup(fileName, contents);
  }

  throw new Error('Backup is not supported on this platform');
};

export const pickAndRestoreBackup = async (): Promise<RestoreResult> => {
  // Some Android document providers do not expose application/json correctly.
  // Pick from all document types, then validate the filename/content ourselves.
  const result = await DocumentPicker.getDocumentAsync({
    type: '*/*',
    copyToCacheDirectory: true,
    multiple: false,
  });

  if (result.canceled) {
    return {canceled: true};
  }

  const asset = result.assets[0];
  if (!asset?.uri) {
    throw new Error('No backup file was selected');
  }

  const fileName = asset.name || 'backup.json';
  if (asset.name && !/\.json$/i.test(asset.name)) {
    throw new Error('Please select a StreamX JSON backup file');
  }

  const raw = await FileSystem.readAsStringAsync(asset.uri, {
    encoding: FileSystem.EncodingType.UTF8,
  });

  let parsed: unknown;
  try {
    parsed = JSON.parse(raw.replace(/^\uFEFF/, ''));
  } catch {
    throw new Error('Invalid backup JSON file');
  }
  const backup = validateBackup(parsed);

  // Clear only persistent stores covered by the backup. Cache data is intentionally
  // excluded because it is disposable and may contain stale device-local paths.
  mainStorage.clearAll();
  providerKvStorage.clearAll();
  await mainStorage.restoreEntries(backup.stores.main);
  await providerKvStorage.restoreEntries(backup.stores.providerKv);

  return {canceled: false, fileName};
};

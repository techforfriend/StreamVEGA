import * as RNFS from '@dr.pogodin/react-native-fs';
import {cache as imageColorsCache} from 'react-native-image-colors';
import {queryClient} from './client';
import {clearHeroCache} from './hooks/useHomePageData';
import {clearImageAccentCache} from './imageAccent';
import {clearDownloadedVideoThumbnailMemoryCache} from './downloadThumbnailCache';
import {cacheStorageService} from './storage';

const PRESERVED_CACHE_ENTRIES: Set<string> = new Set([]);

const clearFilesystemCache = async (): Promise<void> => {
  const entries = await RNFS.readDir(RNFS.CachesDirectoryPath).catch(() => []);
  await Promise.all(
    entries
      .filter(entry => !PRESERVED_CACHE_ENTRIES.has(entry.name))
      .map(entry => RNFS.unlink(entry.path).catch(() => undefined)),
  );
};


export const getAppCacheSizeBytes = async (): Promise<number> => {
  const visited = new Set<string>();
  const walk = async (path: string): Promise<number> => {
    if (visited.has(path)) return 0;
    visited.add(path);
    const entries = await RNFS.readDir(path).catch(() => [] as any[]);
    let total = 0;
    for (const entry of entries as any[]) {
      try {
        const isDir =
          typeof entry?.isDirectory === 'function'
            ? entry.isDirectory()
            : Boolean(entry?.isDirectory);
        if (isDir) {
          total += await walk(entry.path);
        } else {
          const size = Number(entry?.size);
          if (Number.isFinite(size) && size > 0) total += size;
        }
      } catch {}
    }
    return total;
  };
  return walk(RNFS.CachesDirectoryPath);
};

export const formatAppCacheSize = (bytes: number): string => {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  const digits = unit === 0 ? 0 : value >= 10 ? 1 : 2;
  return `${value.toFixed(digits)} ${units[unit]}`;
};

export const clearAppCache = async (): Promise<void> => {
  cacheStorageService.clearAll();
  queryClient.clear();
  imageColorsCache.clear();
  clearImageAccentCache();
  clearDownloadedVideoThumbnailMemoryCache();
  clearHeroCache();
  await clearFilesystemCache();
};

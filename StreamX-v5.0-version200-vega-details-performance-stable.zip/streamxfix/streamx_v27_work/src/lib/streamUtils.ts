import type {Stream} from './providers/types';

const QUALITY_PATTERNS: Array<[string, RegExp]> = [
  ['4K', /(?:\b4k\b|\b2160(?:p)?\b|\buhd\b)/i],
  ['2K', /(?:\b2k\b|\b1440(?:p)?\b|\bqhd\b)/i],
  ['1080p', /\b1080(?:p)?\b/i],
  ['720p', /\b720(?:p)?\b/i],
  ['480p', /\b480(?:p)?\b/i],
  ['360p', /\b360(?:p)?\b/i],
  ['HDR', /(?:\bhdr(?:10(?:\+)?|10|x)?\b|dolby[ -]?vision|dv\b)/i],
  ['SDR', /\bsdr\b/i],
];

export const getStreamQualityCategories = (stream: Partial<Stream> | null | undefined): string[] => {
  if (!stream) return [];
  const raw = [
    stream.quality,
    stream.tag,
    ...(Array.isArray(stream.tags) ? stream.tags : []),
    stream.type,
  ].filter(Boolean).join(' ');
  const categories = new Set<string>();
  for (const [label, pattern] of QUALITY_PATTERNS) {
    if (pattern.test(raw)) categories.add(label);
  }
  return [...categories];
};

export const isPotentiallyPlayableStream = (stream: Partial<Stream> | null | undefined): boolean => {
  if (!stream) return false;
  const rawLink = typeof stream.link === 'string' ? stream.link.trim() : '';
  const infoHash = typeof stream.infoHash === 'string' ? stream.infoHash.trim() : '';
  const type = String(stream.type || '').toLowerCase();
  if (type === 'torrent' || rawLink.toLowerCase().startsWith('magnet:') || Boolean(infoHash)) {
    if (infoHash && !/^[a-f0-9]{40}$/i.test(infoHash)) return false;
    if (rawLink && !rawLink.toLowerCase().startsWith('magnet:') && !/^https?:\/\//i.test(rawLink)) return false;
    if (!rawLink && !infoHash) return false;
    const dummy = /d41d0cfbf8baa3ce04a7074b0c486243dd5fbd00|d41d8cd98f00b204e9800998ecf8427e/i;
    return !dummy.test(rawLink) && !dummy.test(infoHash);
  }
  if (!rawLink) return false;
  if (/^https?:\/\//i.test(rawLink)) {
    try {
      const url = new URL(rawLink);
      return Boolean(url.hostname) && !/^localhost$|^127(?:\.\d{1,3}){3}$/i.test(url.hostname);
    } catch {
      return false;
    }
  }
  return /^(?:file|content|https?|rtmp|rtsp):/i.test(rawLink);
};

export const streamMatchesExcludedQuality = (stream: Partial<Stream>, excludedQualities: string[]): boolean => {
  if (!excludedQualities.length) return false;
  const categories = getStreamQualityCategories(stream);
  return excludedQualities.some(excluded => categories.includes(excluded));
};

export const getAutoStreamScore = (stream: Partial<Stream>): number => {
  const categories = getStreamQualityCategories(stream);
  const qualityScore = categories.includes('4K') ? 4000 :
    categories.includes('2K') ? 2000 :
    categories.includes('1080p') ? 1080 :
    categories.includes('720p') ? 720 :
    categories.includes('480p') ? 480 :
    categories.includes('360p') ? 360 : 0;
  const hdrBonus = categories.includes('HDR') ? 10 : categories.includes('SDR') ? 0 : 5;
  const torrentPenalty = String(stream.type || '').toLowerCase() === 'torrent' ? 0 : 2;
  return qualityScore * 100 + hdrBonus * 10 + torrentPenalty;
};

export const chooseBestStream = <T extends Partial<Stream>>(streams: T[]): T | null => {
  if (!streams.length) return null;
  return streams.reduce((best, item) =>
    getAutoStreamScore(item) > getAutoStreamScore(best) ? item : best, streams[0]);
};

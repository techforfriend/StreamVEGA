import {useCallback, useEffect, useRef, useState} from 'react';
import {cacheStorage} from '../storage';

interface UsePlayerProgressOptions {
  activeEpisode: any;
  onProgressSaved?: (position: number, duration: number) => void;
}

export const usePlayerProgress = ({
  activeEpisode,
  onProgressSaved,
}: UsePlayerProgressOptions) => {
  const videoPositionRef = useRef({position: 0, duration: 0});
  const lastSavedPositionRef = useRef(0);
  const mediaDurationRef = useRef(0);
  const latestProgressRef = useRef({position: 0, duration: 0});

  const persistLatestProgress = useCallback(() => {
    const {position, duration} = latestProgressRef.current;
    if (!activeEpisode?.link || !Number.isFinite(position) || position < 0) return;
    if (!Number.isFinite(duration) || duration <= 0) return;
    try {
      cacheStorage.setString(
        activeEpisode.link,
        JSON.stringify({position, duration}),
      );
    } catch (error) {
      console.warn('[PlayerProgress] Failed to persist progress:', error);
    }
    try {
      onProgressSaved?.(position, duration);
    } catch (error) {
      console.warn('[PlayerProgress] Progress callback failed:', error);
    }
  }, [activeEpisode?.link, onProgressSaved]);

  useEffect(() => {
    videoPositionRef.current = {position: 0, duration: 0};
    latestProgressRef.current = {position: 0, duration: 0};
    lastSavedPositionRef.current = 0;
    mediaDurationRef.current = 0;
    return () => {
      persistLatestProgress();
    };
  }, [activeEpisode?.link, persistLatestProgress]);

  const handleLoad = useCallback((duration?: number) => {
    if (Number.isFinite(duration) && Number(duration) > 0) {
      mediaDurationRef.current = Number(duration);
      videoPositionRef.current.duration = Number(duration);
    }
  }, []);

  // Memoized progress handler. react-native-video exposes seekableDuration
  // separately from the total media duration; Continue Watching needs the
  // latter so the stored time/percentage remains correct for normal streams.
  const handleProgress = useCallback(
    (e: {currentTime: number; seekableDuration?: number; duration?: number}) => {
      const episodeLink = activeEpisode?.link;
      if (!episodeLink) return;
      const {currentTime} = e;
      const eventDuration = Number(e.duration);
      const seekableDuration = Number(e.seekableDuration);
      if (Number.isFinite(eventDuration) && eventDuration > 0) {
        mediaDurationRef.current = eventDuration;
      } else if (mediaDurationRef.current <= 0 && seekableDuration > 0) {
        mediaDurationRef.current = seekableDuration;
      }

      const duration = mediaDurationRef.current > 0
        ? mediaDurationRef.current
        : seekableDuration > 0
          ? seekableDuration
          : videoPositionRef.current.duration;

      const safePosition = Number.isFinite(currentTime) ? Math.max(0, currentTime) : 0;
      videoPositionRef.current = {
        position: safePosition,
        duration,
      };
      latestProgressRef.current = {position: safePosition, duration};

      // Save progress periodically (every 5 seconds).
      if (
        Number.isFinite(currentTime) &&
        currentTime >= 0 &&
        Math.abs(currentTime - lastSavedPositionRef.current) >= 5
      ) {
        try {
          cacheStorage.setString(
            episodeLink,
            JSON.stringify({
              position: currentTime,
              duration,
            }),
          );
        } catch (error) {
          console.warn('[PlayerProgress] Failed to save progress:', error);
        }
        try {
          onProgressSaved?.(currentTime, duration);
        } catch (error) {
          console.warn('[PlayerProgress] Progress callback failed:', error);
        }
        lastSavedPositionRef.current = currentTime;
      }
    },
    [activeEpisode?.link, onProgressSaved],
  );

  return {
    videoPositionRef,
    handleLoad,
    handleProgress,
  };
};

// Hook for player settings and UI state
export const usePlayerSettings = () => {
  const [showControls, setShowControls] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [activeTab, setActiveTab] = useState<
    'audio' | 'subtitle' | 'server' | 'quality' | 'speed'
  >('audio');
  const [resizeMode, setResizeMode] = useState<any>('contain');
  const [playbackRate, setPlaybackRate] = useState(1.0);
  const [isPlayerLocked, setIsPlayerLocked] = useState(false);
  const [showUnlockButton, setShowUnlockButton] = useState(false);
  const [toastMessage, setToastMessage] = useState<string>('');
  const [showToast, setShowToast] = useState(false);
  const [isTextVisible, setIsTextVisible] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(true);

  const unlockButtonTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Memoized resize mode handler
  const handleResizeMode = useCallback(() => {
    const modes = [
      {mode: 'none', name: 'Fit'},
      {mode: 'cover', name: 'Cover'},
      {mode: 'stretch', name: 'Stretch'},
      {mode: 'contain', name: 'Contain'},
    ];
    const index = modes.findIndex(mode => mode.mode === resizeMode);
    const nextMode = modes[(index + 1) % modes.length];
    setResizeMode(nextMode.mode);
    setToast('Resize Mode: ' + nextMode.name, 2000);
  }, [resizeMode]);

  // Memoized toast setter
  const setToast = useCallback((message: string, duration: number) => {
    setToastMessage(message);
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
    }, duration);
  }, []);

  // Memoized player lock toggle
  const togglePlayerLock = useCallback(() => {
    const newLockState = !isPlayerLocked;
    setIsPlayerLocked(newLockState);

    if (!newLockState) {
      setShowControls(true);
    } else {
      setShowUnlockButton(false);
    }

    if (unlockButtonTimerRef.current) {
      clearTimeout(unlockButtonTimerRef.current);
      unlockButtonTimerRef.current = null;
    }

    setToast(newLockState ? 'Player Locked' : 'Player Unlocked', 2000);
  }, [isPlayerLocked, setToast]);

  // Memoized locked screen tap handler
  const handleLockedScreenTap = useCallback(() => {
    if (showUnlockButton) {
      setShowUnlockButton(false);
      return;
    }

    setShowUnlockButton(true);

    if (unlockButtonTimerRef.current) {
      clearTimeout(unlockButtonTimerRef.current);
    }

    unlockButtonTimerRef.current = setTimeout(() => {
      setShowUnlockButton(false);
    }, 10000);
  }, [showUnlockButton]);

  // Memoized fullscreen toggle
  const toggleFullScreen = useCallback(() => {
    setIsFullScreen(prev => !prev);
  }, []);

  return {
    showControls,
    setShowControls,
    showSettings,
    setShowSettings,
    activeTab,
    setActiveTab,
    resizeMode,
    setResizeMode,
    playbackRate,
    setPlaybackRate,
    isPlayerLocked,
    showUnlockButton,
    toastMessage,
    showToast,
    isTextVisible,
    setIsTextVisible,
    isFullScreen,
    setIsFullScreen,
    handleResizeMode,
    setToast,
    togglePlayerLock,
    toggleFullScreen,
    handleLockedScreenTap,
    unlockButtonTimerRef,
  };
};

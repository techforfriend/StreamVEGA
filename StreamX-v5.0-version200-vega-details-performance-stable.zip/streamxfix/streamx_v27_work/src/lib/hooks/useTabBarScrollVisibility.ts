import {useCallback, useRef} from 'react';
import {NativeScrollEvent, NativeSyntheticEvent} from 'react-native';
import {useFocusEffect} from '@react-navigation/native';
import useNavigationPreferencesStore from '../zustand/navigationPreferencesStore';

type ScrollEvent = NativeSyntheticEvent<NativeScrollEvent>;

export const useTabBarScrollVisibility = () => {
  const setTabBarHidden = useNavigationPreferencesStore(state => state.setTabBarHidden);
  const hiddenRef = useRef(false);
  const dragStartOffsetRef = useRef(0);
  const showTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const clearShowTimer = useCallback(() => { if (showTimerRef.current) { clearTimeout(showTimerRef.current); showTimerRef.current = null; } }, []);
  const show = useCallback(() => { clearShowTimer(); if (hiddenRef.current) { hiddenRef.current = false; setTabBarHidden(false); } }, [clearShowTimer, setTabBarHidden]);
  const hide = useCallback(() => { clearShowTimer(); if (!hiddenRef.current) { hiddenRef.current = true; setTabBarHidden(true); } }, [clearShowTimer, setTabBarHidden]);
  const scheduleShow = useCallback(() => { clearShowTimer(); showTimerRef.current = setTimeout(() => { showTimerRef.current = null; show(); }, 220); }, [clearShowTimer, show]);
  useFocusEffect(useCallback(() => { hiddenRef.current = false; dragStartOffsetRef.current = 0; clearShowTimer(); setTabBarHidden(false); return () => { clearShowTimer(); hiddenRef.current = false; setTabBarHidden(false); }; }, [clearShowTimer, setTabBarHidden]));
  const onScrollBeginDrag = useCallback((event?: ScrollEvent) => { dragStartOffsetRef.current = event?.nativeEvent.contentOffset.y ?? 0; }, []);
  const onScroll = useCallback((event: ScrollEvent) => { if (Math.abs(event.nativeEvent.contentOffset.y - dragStartOffsetRef.current) >= 28) hide(); }, [hide]);
  const onScrollEndDrag = useCallback(() => scheduleShow(), [scheduleShow]);
  const onMomentumScrollBegin = useCallback((event?: ScrollEvent) => { if (Math.abs((event?.nativeEvent.contentOffset.y ?? 0) - dragStartOffsetRef.current) >= 28) hide(); }, [hide]);
  const onMomentumScrollEnd = useCallback(() => show(), [show]);
  return {onScrollBeginDrag, onScroll, onScrollEndDrag, onMomentumScrollBegin, onMomentumScrollEnd};
};

export default useTabBarScrollVisibility;

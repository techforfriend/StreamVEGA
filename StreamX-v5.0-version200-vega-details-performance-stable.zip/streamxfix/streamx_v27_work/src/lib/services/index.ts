export {ProviderManager, providerManager} from './ProviderManager';
export {StremioAddonManager, stremioAddonManager} from './StremioAddonManager';
export {StremioProviderManager, stremioProviderManager} from './StremioProviderManager';
export {DownloadManager, downloadManager} from './DownloadManager';

export {VegaPluginManager, vegaPluginManager} from './VegaPluginManager';

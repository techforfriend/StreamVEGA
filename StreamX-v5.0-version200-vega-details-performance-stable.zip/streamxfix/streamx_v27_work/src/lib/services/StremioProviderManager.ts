import axios from 'axios';
import {Catalog, EpisodeLink, Info, Post, Stream} from '../providers/types';
import {settingsStorage} from '../storage';
import stremioAddonManager, {
  StremioAddon,
  StremioCatalogManifest,
  StremioResource,
} from './StremioAddonManager';
import {getStreamQualityCategories, isPotentiallyPlayableStream} from '../streamUtils';

const timeout = 10000;
// Keep addon calls bounded, but do not make normal mobile/network latency look
// like an addon failure. Requests are fanned out in parallel, so this remains
// fast while allowing slower Stremio endpoints to return.
const addonRequestTimeout = 4500;
const streamAddonRequestTimeout = 4000;
const streamCacheTtlMs = 15_000;

// Stremio's official Cinemeta addon resolves global IMDb `tt...` IDs even when
// a catalog addon intentionally exposes only the `catalog` resource. We use it
// as a metadata-only fallback and never expose it as an installed provider.
const CINEMETA_META_BASE = 'https://v3-cinemeta.strem.io';

const asArray = <T>(value: any, key?: string): T[] => {
  const result = key ? value?.[key] : value;
  return Array.isArray(result) ? result : [];
};

const text = (value: any, fallback = '') =>
  value === undefined || value === null ? fallback : String(value);

const normalizeType = (type: string) => {
  const normalized = String(type || '').toLowerCase();
  if (normalized === 'tv') return 'channel';
  if (normalized === 'series') return 'series';
  if (normalized === 'movie' || normalized === 'channel' || normalized === 'anime') {
    return normalized;
  }
  return normalized || 'movie';
};

const catalogSupports = (catalog: StremioCatalogManifest, type: string) =>
  !catalog.type || normalizeType(catalog.type) === normalizeType(type);

const normalizeResource = (resource: StremioResource | string): StremioResource =>
  typeof resource === 'string' ? {name: resource as any} : resource;

const hasResource = (addon: StremioAddon, name: 'catalog' | 'meta' | 'stream') =>
  Array.isArray(addon.manifest.resources) &&
  addon.manifest.resources.some(resource => normalizeResource(resource).name === name);

class StremioProviderManager {
  private readonly streamCache = new Map<string, {expiresAt: number; streams: Stream[]}>();
  private readonly streamInflight = new Map<string, Promise<Stream[]>>();

  isStremioProvider(providerValue: string) {
    return typeof providerValue === 'string' && providerValue.startsWith('stremio:');
  }

  private addonForProvider(providerValue: string): StremioAddon {
    const id = providerValue.slice('stremio:'.length);
    const addon = stremioAddonManager.getAddon(id);
    if (!addon || !addon.enabled) {
      throw new Error('Stremio addon is not installed or is disabled');
    }
    return addon;
  }

  private async get(
    url: string,
    signal?: AbortSignal,
    requestTimeoutMs: number = timeout,
  ) {
    const response = await axios.get(url, {
      timeout: requestTimeoutMs,
      signal,
      headers: {Accept: 'application/json'},
    });
    return response.data;
  }

  /**
   * Give every addon request its own timeout/cancellation boundary. A slow or
   * broken addon must never hold the entire Stremio fan-out hostage.
   */
  private async getAddonRequest(
    url: string,
    parentSignal?: AbortSignal,
    requestTimeoutMs: number | undefined = addonRequestTimeout,
  ) {
    const controller = new AbortController();
    let timeoutId: ReturnType<typeof setTimeout> | undefined;

    const abortFromParent = () => controller.abort();
    if (parentSignal?.aborted) {
      controller.abort();
    } else if (parentSignal) {
      parentSignal.addEventListener('abort', abortFromParent, {once: true});
    }

    if (requestTimeoutMs !== undefined && requestTimeoutMs > 0) {
      timeoutId = setTimeout(() => controller.abort(), requestTimeoutMs);
    }
    try {
      return await this.get(url, controller.signal);
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
      parentSignal?.removeEventListener('abort', abortFromParent);
    }
  }

  private catalogs(addon: StremioAddon): StremioCatalogManifest[] {
    return Array.isArray(addon.manifest.catalogs) ? addon.manifest.catalogs : [];
  }

  /**
   * Stremio resources can restrict both media type and id prefix. Only call an
   * addon when its manifest says it can handle the requested resource.
   */
  private supportsResource(
    addon: StremioAddon,
    resourceName: 'meta' | 'stream' | 'catalog',
    type: string,
    id: string,
  ) {
    const resources = Array.isArray(addon.manifest.resources)
      ? addon.manifest.resources.map(normalizeResource)
      : [];
    const resource = resources.find(item => item.name === resourceName);
    if (!resource) return false;

    const normalizedType = normalizeType(type);
    if (
      Array.isArray(resource.types) &&
      resource.types.length > 0 &&
      !resource.types.some(item => {
        const candidateType = normalizeType(String(item));
        return candidateType === normalizedType ||
          (normalizedType === 'channel' && (String(item).toLowerCase() === 'tv' || String(item).toLowerCase() === 'channel'));
      })
    ) {
      return false;
    }

    if (
      Array.isArray(resource.idPrefixes) &&
      resource.idPrefixes.length > 0 &&
      !resource.idPrefixes.some(prefix => String(id).startsWith(String(prefix)))
    ) {
      return false;
    }

    return true;
  }

  private resourceCandidates(
    resourceName: 'meta' | 'stream',
    type: string,
    id: string,
    preferredAddon?: StremioAddon,
  ) {
    const enabled = stremioAddonManager.list().filter(addon => addon.enabled);
    const declared = enabled.filter(addon =>
      this.supportsResource(addon, resourceName, type, id),
    );

    const ordered: StremioAddon[] = [];

    // Prefer the addon that produced the item only when its manifest can
    // actually serve this resource. This prevents a catalog-only addon from
    // receiving stream/meta requests that it cannot handle.
    if (preferredAddon?.enabled && this.supportsResource(preferredAddon, resourceName, type, id)) {
      ordered.push(preferredAddon);
    }

    // Then use addons whose manifest explicitly declares the requested
    // resource. This is the normal Stremio filtering path.
    for (const addon of declared) {
      if (!ordered.some(item => item.id === addon.id)) ordered.push(addon);
    }

    // For metadata, keep the normal Stremio filtering path tight. Catalog-only
    // addons commonly rely on the global IMDb/Cinemeta metadata service, which
    // is handled explicitly below instead of making every stream-only addon
    // time out on a /meta request.
    //
    // For streams, however, stream-only addons must remain eligible for every
    // catalog item, so those are appended below.

    // A stream-only addon is intentionally not a content provider, but its
    // streams should still be available for catalog items from every provider.
    // Keep those addons eligible even when their manifest filtering is too
    // narrow for the catalog item's exact ID.
    if (resourceName === 'stream') {
      for (const addon of enabled) {
        const hasCatalog =
          Array.isArray(addon.manifest.catalogs) && addon.manifest.catalogs.length > 0;
        const hasStream = hasResource(addon, 'stream');
        const supportsRequestedStream = this.supportsResource(
          addon,
          'stream',
          type,
          id,
        );
        if (
          hasStream &&
          supportsRequestedStream &&
          (!hasCatalog || type === 'channel') &&
          !ordered.some(item => item.id === addon.id)
        ) {
          ordered.push(addon);
        }
      }

      // Some community addons declare a generic stream resource but omit or
      // incorrectly narrow `types`/`idPrefixes`. Keep them as a final fallback
      // so one bad manifest cannot hide valid streams from another addon.
      for (const addon of enabled) {
        if (hasResource(addon, 'stream') && !ordered.some(item => item.id === addon.id)) {
          ordered.push(addon);
        }
      }
    }

    return ordered;
  }

  async getCatalog(providerValue: string): Promise<Catalog[]> {
    const addon = this.addonForProvider(providerValue);
    const catalogs = this.catalogs(addon);
    return catalogs.map((catalog, index) => ({
      title: text(catalog.name, catalog.id || `Catalog ${index + 1}`),
      filter: JSON.stringify({
        addonId: addon.id,
        catalogId: catalog.id,
        type: catalog.type,
        extra: catalog.extra || [],
      }),
    }));
  }

  private parseFilter(filter: string) {
    try {
      const parsed = JSON.parse(filter);
      if (parsed && parsed.addonId && parsed.catalogId) return parsed;
    } catch {}
    return undefined;
  }

  private async fetchCatalog(
    addon: StremioAddon,
    catalog: StremioCatalogManifest,
    page: number,
    search?: string,
    signal?: AbortSignal,
    forceSearch = false,
  ) {
    const extra: Record<string, string> = {};
    const supportedExtra = new Set((catalog.extra || []).map(item => item.name));
    if (search && (forceSearch || supportedExtra.has('search') || supportedExtra.size === 0)) {
      extra.search = search;
    }
    if (page > 1 && (supportedExtra.has('skip') || supportedExtra.size === 0)) {
      extra.skip = String((page - 1) * 100);
    }

    const url = stremioAddonManager.getResourceUrl(
      addon,
      'catalog',
      catalog.type,
      catalog.id,
      extra,
    );
    const data = await this.getAddonRequest(url, signal);
    return asArray<any>(data, 'metas');
  }

  private postFromMeta(addon: StremioAddon, meta: any): Post | null {
    if (!meta?.id) return null;
    const type = normalizeType(text(meta.type, 'movie'));
    const id = text(meta.id);
    return {
      title: text(meta.name, id),
      link: stremioAddonManager.makeLink(addon, type, id),
      image: text(meta.poster, text(meta.background)),
      provider: `stremio:${addon.id}`,
      aspectRatio: meta.posterShape === 'landscape' ? 16 / 9 : 2 / 3,
      tag: text(meta.releaseInfo || meta.year),
      cornerTag: text(meta.imdbRating),
    };
  }

  async getPosts({
    filter,
    page,
    providerValue,
    signal,
  }: {
    filter: string;
    page: number;
    providerValue: string;
    signal: AbortSignal;
  }): Promise<Post[]> {
    const addon = this.addonForProvider(providerValue);
    const parsed = this.parseFilter(filter);
    if (!parsed || parsed.addonId !== addon.id) return [];
    const catalog = this.catalogs(addon).find(item => item.id === parsed.catalogId);
    if (!catalog) return [];
    const metas = await this.fetchCatalog(addon, catalog, page, undefined, signal);
    return metas.map(meta => this.postFromMeta(addon, meta)).filter(Boolean) as Post[];
  }

  private readonly cinemetaSearchCache = new Map<string, Promise<any[]>>();

  private async fetchCinemetaSearch(
    type: 'movie' | 'series',
    query: string,
    page: number,
    signal?: AbortSignal,
  ): Promise<any[]> {
    const skip = Math.max(0, page - 1) * 100;
    const encodedQuery = encodeURIComponent(query);
    const suffix = skip > 0
      ? `/search=${encodedQuery}&skip=${skip}`
      : `/search=${encodedQuery}`;
    const endpoint = `${CINEMETA_META_BASE}/catalog/${type}/top${suffix}.json`;
    const cacheKey = `${type}|${query.trim().toLowerCase()}|${page}`;
    const cached = this.cinemetaSearchCache.get(cacheKey);
    if (cached) return cached;

    // Search is shared between provider sections. Do not issue the same
    // Cinemeta request once per installed addon; this keeps the search screen
    // responsive when several stream/catalog addons are installed.
    const request = this.get(endpoint)
      .then(data => asArray<any>(data, 'metas'))
      .catch(error => {
        this.cinemetaSearchCache.delete(cacheKey);
        if (signal?.aborted) throw error;
        console.warn(`[Stremio] Cinemeta ${type} search failed:`, error);
        return [];
      });

    this.cinemetaSearchCache.set(cacheKey, request);
    return request;
  }

  async getSearchPosts({
    searchQuery,
    page,
    providerValue,
    signal,
    allowGlobalFallback = true,
  }: {
    searchQuery: string;
    page: number;
    providerValue: string;
    signal: AbortSignal;
    allowGlobalFallback?: boolean;
  }): Promise<Post[]> {
    const addon = this.addonForProvider(providerValue);
    const query = searchQuery.trim();
    if (!query) return [];

    const normalize = (value: string) =>
      value
        .toLowerCase()
        .normalize('NFKD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, ' ')
        .trim();

    const queryText = normalize(query);
    const queryTokens = queryText.split(' ').filter(Boolean);
    const results: Post[] = [];
    let searchedAddonCatalog = false;

    // Prefer the addon's own searchable catalogs when they explicitly support
    // the Stremio `search` extra. This preserves provider-specific search.
    for (const catalog of this.catalogs(addon)) {
      if (signal.aborted) break;
      if (!catalogSupports(catalog, 'movie') && !catalogSupports(catalog, 'series')) continue;

      const extras = Array.isArray(catalog.extra) ? catalog.extra : [];
      const supportsSearch =
        extras.some(item => String(item?.name || '').toLowerCase() === 'search') ||
        (Array.isArray(catalog.extraSupported) &&
          catalog.extraSupported.some(item => String(item).toLowerCase() === 'search'));

      // The home/hero search is explicitly provider-local. When global fallback
      // is disabled, try the provider's catalog endpoint even if its manifest
      // did not advertise the `search` extra; some real-world addons still
      // accept the standard search parameter.
      if (!supportsSearch && allowGlobalFallback) continue;
      searchedAddonCatalog = true;

      try {
        const metas = await this.fetchCatalog(addon, catalog, page, query, signal, !supportsSearch);
        for (const meta of metas) {
          const title = text(meta?.name || meta?.title);
          const normalizedTitle = normalize(title);
          if (!normalizedTitle) continue;

          const matches =
            !queryText ||
            normalizedTitle.includes(queryText) ||
            queryTokens.every(token => normalizedTitle.includes(token));
          if (!matches) continue;

          const post = this.postFromMeta(addon, meta);
          if (post) results.push(post);
        }
      } catch (error) {
        if (signal.aborted) break;
        console.warn(`[Stremio] Search failed for ${catalog.id}:`, error);
      }
    }

    // Many real-world addons (including catalog-only addons without a `search`
    // extra and stream-only addons) do not expose a searchable catalog. The
    // app still needs global search to work for those providers. Cinemeta is
    // Stremio's primary movie/series catalog and its search returns IMDb IDs;
    // use those IDs while keeping the clicked result associated with the
    // installed addon so getStream() can fan out to stream addons later.
    if (allowGlobalFallback && !searchedAddonCatalog && !signal.aborted) {
      const [movieMetas, seriesMetas] = await Promise.all([
        this.fetchCinemetaSearch('movie', query, page, signal),
        this.fetchCinemetaSearch('series', query, page, signal),
      ]);

      for (const meta of [...movieMetas, ...seriesMetas]) {
        if (signal.aborted) break;
        const id = text(meta?.id);
        if (!/^tt\d+$/i.test(id)) continue;
        const type = normalizeType(text(meta?.type, 'movie'));
        if (type !== 'movie' && type !== 'series') continue;

        // Cinemeta already performed the title match. Still keep a defensive
        // title check so malformed upstream responses cannot pollute search.
        const title = text(meta?.name || meta?.title);
        const normalizedTitle = normalize(title);
        if (!normalizedTitle) continue;
        if (queryText &&
            !normalizedTitle.includes(queryText) &&
            !queryTokens.every(token => normalizedTitle.includes(token))) {
          continue;
        }

        const post = this.postFromMeta(addon, {...meta, id, type});
        if (post) results.push(post);
      }
    }

    const seen = new Set<string>();
    return results.filter(item => {
      if (seen.has(item.link)) return false;
      seen.add(item.link);
      return true;
    });
  }

  private async fetchMetaFromBase(
    baseUrl: string,
    type: string,
    id: string,
    signal?: AbortSignal,
  ) {
    const endpoint = `${baseUrl.replace(/\/+$/, '')}/meta/${encodeURIComponent(type)}/${encodeURIComponent(id)}.json`;
    const data = await this.get(endpoint, signal, 0);
    const meta = data?.meta || data;
    if (!meta?.id) throw new Error('Metadata fallback returned no metadata');
    return meta;
  }

  private async fetchMeta(
    addon: StremioAddon,
    type: string,
    id: string,
    signal?: AbortSignal,
  ) {
    const url = stremioAddonManager.getResourceUrl(addon, 'meta', type, id);
    // Details-page metadata must not be auto-cancelled by an addon timeout.
    // The request remains alive until it succeeds, fails, or the caller
    // explicitly aborts (for example by leaving the Details page).
    const data = await this.getAddonRequest(url, signal, undefined);
    const meta = data?.meta || data;
    if (!meta?.id) throw new Error(`Addon ${addon.name} returned no metadata`);
    return meta;
  }

  async getMetaData({
    link,
    provider: _provider,
    signal,
  }: {
    link: string;
    provider: string;
    signal?: AbortSignal;
  }): Promise<Info> {
    const parsed = stremioAddonManager.parseLink(link);
    if (!parsed) throw new Error('Invalid Stremio content link');

    // The link itself is the authoritative source identity. Do not require the
    // currently selected provider to equal the addon that produced the link;
    // this prevents the old "provider" metadata failure when the user switches
    // addons after opening a catalog result.
    const sourceAddon = stremioAddonManager.getAddon(parsed.addonId);
    const preferred = sourceAddon?.enabled ? sourceAddon : undefined;
    const candidates = this.resourceCandidates('meta', parsed.type, parsed.id, preferred);

    let meta: any = null;
    let metaAddon: StremioAddon | undefined;
    let lastError: unknown;

    // Try compatible metadata addons concurrently. A slow source addon must
    // not prevent a working fallback addon (or Cinemeta) from resolving the
    // Details page. Each request still remains open until completion unless
    // the caller explicitly aborts it.
    if (candidates.length > 0) {
      try {
        const resolved = await Promise.any(
          candidates.map(async addon => ({
            addon,
            meta: await this.fetchMeta(addon, parsed.type, parsed.id, signal),
          })),
        );
        meta = resolved.meta;
        metaAddon = resolved.addon;
      } catch (error) {
        lastError = error;
      }
    }
    // Catalog addons are allowed to expose only `catalog`. For IMDb IDs,
    // Stremio itself resolves the Details page through Cinemeta. Mirror that
    // behavior so catalog-only addons still get a full Details page.
    if (!meta && /^tt\d+$/i.test(parsed.id)) {
      try {
        meta = await this.fetchMetaFromBase(CINEMETA_META_BASE, parsed.type, parsed.id, signal);
        metaAddon = undefined;
      } catch (error) {
        lastError = error;
      }
    }

    // Live TV/channel catalogs often expose stream endpoints without a meta endpoint.
    // Keep the catalog identity usable so the Details page can still expose Stream/Play.
    if (!meta && normalizeType(parsed.type) === 'channel') {
      meta = {
        id: parsed.id,
        name: parsed.id,
        type: 'channel',
        description: '',
      };
      metaAddon = sourceAddon?.enabled ? sourceAddon : candidates[0];
    }

    if (!meta) {
      throw lastError instanceof Error ? lastError : new Error('Failed to load metadata');
    }

    const type = normalizeType(text(meta.type, parsed.type));
    const info: Info = {
      title: text(meta.name, parsed.id),
      image: text(meta.background, text(meta.poster)),
      logo: text(meta.logo) || undefined,
      poster: text(meta.poster) || undefined,
      synopsis: text(meta.description),
      imdbId:
        text(meta.imdb_id) ||
        (String(meta.id).startsWith('tt') ? String(meta.id) : undefined),
      tmdbId: meta.tmdb_id,
      type,
      webUrl:
        text(meta.links?.find?.((item: any) => item?.category === 'imdb')?.url) ||
        undefined,
      tags: Array.isArray(meta.genres) ? meta.genres.map(String) : undefined,
      cast: Array.isArray(meta.cast)
        ? meta.cast
            .map((item: any) =>
              typeof item === 'string' ? item : text(item?.name),
            )
            .filter(Boolean)
        : undefined,
      rating: meta.imdbRating
        ? String(meta.imdbRating)
        : meta.rating
        ? String(meta.rating)
        : undefined,
      trailerUrl: this.findTrailer(meta),
      linkList: [],
    };

    const videos = asArray<any>(meta.videos);
    const episodeLinkAddon =
      metaAddon || sourceAddon || candidates.find(addon => addon.enabled);

    if (type === 'series' || videos.length > 0) {
      if (!episodeLinkAddon) {
        throw new Error('Unable to resolve an addon identity for episodes');
      }
      const episodesLink = stremioAddonManager.makeLink(episodeLinkAddon, type, parsed.id);
      const seasonNumbers = Array.from(
        new Set(
          videos
            .map(video => Number(video?.season))
            .filter(value => Number.isFinite(value) && value >= 0),
        ),
      ).sort((a, b) => a - b);

      if (seasonNumbers.length > 0) {
        info.linkList.push(
          ...seasonNumbers.map(season => ({
            title: season === 0 ? 'Specials' : `Season ${season}`,
            season,
            episodesLink,
          })),
        );
      } else {
        info.linkList.push({
          title: 'Episodes',
          episodesLink,
        });
      }
    } else {
      // Keep the source addon identity in the link. getStream() will fan out to
      // every compatible installed stream addon for the actual playable links.
      info.linkList.push({
        title: 'Play',
        directLinks: [{title: 'Play', link, type}],
      });
    }

    return info;
  }

  private findTrailer(meta: any) {
    const trailer = asArray<any>(meta.trailers || meta.trailer).find(
      item => item?.source || item?.url,
    );
    if (!trailer) return undefined;
    const source = text(trailer.source || trailer.url);
    if (/^https?:\/\//i.test(source)) return source;
    if (/^[A-Za-z0-9_-]{8,}$/.test(source)) {
      return `https://www.youtube.com/watch?v=${source}`;
    }
    return undefined;
  }

  async getEpisodes({
    url,
    providerValue: _providerValue,
    signal,
  }: {
    url: string;
    providerValue: string;
    signal?: AbortSignal;
  }): Promise<EpisodeLink[]> {
    const parsed = stremioAddonManager.parseLink(url);
    if (!parsed) return [];

    const sourceAddon = stremioAddonManager.getAddon(parsed.addonId);
    const candidates = this.resourceCandidates(
      'meta',
      parsed.type,
      parsed.id,
      sourceAddon?.enabled ? sourceAddon : undefined,
    );

    // Episode metadata can be supplied by more than one addon. Query all
    // compatible metadata addons in parallel and merge their video objects.
    // One slow/broken addon must never prevent another addon from supplying
    // the episode list.
    const metadataResults = await Promise.allSettled(
      candidates.map(async addon => ({
        addon,
        meta: await this.fetchMeta(addon, parsed.type, parsed.id, signal),
      })),
    );

    const videos: any[] = [];
    const seen = new Set<string>();

    const appendVideos = (meta: any) => {
      for (const video of asArray<any>(meta?.videos)) {
        const episodeId = text(
          video.id,
          `${parsed.id}:${video.season || 0}:${video.episode || 0}`,
        );
        const key = `${video.season || 0}:${video.episode || 0}:${episodeId}`;
        if (seen.has(key)) continue;
        seen.add(key);
        videos.push({...video, __episodeId: episodeId});
      }
    };

    for (const result of metadataResults) {
      if (result.status === 'fulfilled') appendVideos(result.value.meta);
    }

    // If no addon supplied episodes, retain the existing Cinemeta fallback for
    // IMDb IDs. This also handles catalog-only addons cleanly.
    if (videos.length === 0 && /^tt\d+$/i.test(parsed.id)) {
      try {
        const fallbackMeta = await this.fetchMetaFromBase(
          CINEMETA_META_BASE,
          parsed.type,
          parsed.id,
          signal,
        );
        appendVideos(fallbackMeta);
      } catch {}
    }

    if (videos.length === 0) return [];

    videos.sort((a, b) => {
      const seasonA = Number.isFinite(Number(a?.season)) ? Number(a.season) : 0;
      const seasonB = Number.isFinite(Number(b?.season)) ? Number(b.season) : 0;
      if (seasonA !== seasonB) return seasonA - seasonB;
      const episodeA = Number.isFinite(Number(a?.episode)) ? Number(a.episode) : 0;
      const episodeB = Number.isFinite(Number(b?.episode)) ? Number(b.episode) : 0;
      return episodeA - episodeB;
    });

    const linkAddon =
      sourceAddon?.enabled
        ? sourceAddon
        : (metadataResults.find(result => result.status === 'fulfilled') as PromiseFulfilledResult<{addon: StremioAddon; meta: any}> | undefined)?.value.addon
        || candidates[0]
        || stremioAddonManager.list().find(addon => addon.enabled);
    if (!linkAddon) return [];

    return videos.map(video => {
      const episodeId = text(video.__episodeId);
      const episodeType = normalizeType(text(video.type, parsed.type));
      const season = Number(video.season);
      const episode = Number(video.episode);
      return {
        id: episodeId,
        season: Number.isFinite(season) ? season : undefined,
        episode: Number.isFinite(episode) ? episode : undefined,
        title: text(
          video.name,
          `S${String(Number.isFinite(season) ? season : 0).padStart(2, '0')} E${String(
            Number.isFinite(episode) ? episode : 0,
          ).padStart(2, '0')}`,
        ),
        link: stremioAddonManager.makeLink(linkAddon, episodeType, episodeId),
        sourceLink: url,
        description: text(video.overview || video.description),
        image: text(video.thumbnail) || undefined,
      };
    });
  }

  async getStream({
    link,
    type,
    providerValue,
    signal,
    forceRefresh = false,
  }: {
    link: string;
    type: string;
    providerValue: string;
    signal?: AbortSignal;
    isDownload?: boolean;
    forceRefresh?: boolean;
  }): Promise<Stream[]> {
    const cacheKey = `${providerValue}|${type}|${link}`;
    const cached = this.streamCache.get(cacheKey);
    if (!forceRefresh && cached && cached.expiresAt > Date.now()) {
      return this.waitForStreamResult(Promise.resolve(cached.streams), signal);
    }
    if (cached) this.streamCache.delete(cacheKey);

    const inflight = this.streamInflight.get(cacheKey);
    if (inflight) {
      return this.waitForStreamResult(inflight, signal);
    }

    const request = this.fetchStreamsUncached(link, type, providerValue, signal)
      .then(streams => {
        this.streamCache.set(cacheKey, {expiresAt: Date.now() + streamCacheTtlMs, streams});
        return streams;
      })
      .finally(() => {
        this.streamInflight.delete(cacheKey);
      });
    this.streamInflight.set(cacheKey, request);
    return this.waitForStreamResult(request, signal);
  }

  private async waitForStreamResult(
    request: Promise<Stream[]>,
    signal?: AbortSignal,
  ): Promise<Stream[]> {
    if (!signal) return request;
    if (signal.aborted) {
      const error = new Error('Aborted');
      error.name = 'AbortError';
      throw error;
    }
    let onAbort: (() => void) | undefined;
    const abortPromise = new Promise<Stream[]>((_, reject) => {
      onAbort = () => {
        const error = new Error('Aborted');
        error.name = 'AbortError';
        reject(error);
      };
      signal.addEventListener('abort', onAbort, {once: true});
    });
    try {
      return await Promise.race([request, abortPromise]);
    } finally {
      if (onAbort) signal.removeEventListener('abort', onAbort);
    }
  }

  private async fetchStreamsUncached(
    link: string,
    type: string,
    providerValue: string,
    signal?: AbortSignal,
  ): Promise<Stream[]> {
    const parsed = stremioAddonManager.parseLink(link);
    if (!parsed) throw new Error('Invalid Stremio stream link');

    const sourceAddon = stremioAddonManager.getAddon(parsed.addonId);
    const requestType = normalizeType(parsed.type || type);
    const candidates = this.resourceCandidates(
      'stream',
      requestType,
      parsed.id,
      sourceAddon?.enabled ? sourceAddon : undefined,
    );

    if (candidates.length === 0) {
      throw new Error('No installed Stremio addon supports streams for this item');
    }

    const results = await Promise.allSettled(
      candidates.map(async addon => {
        if (signal?.aborted) {
          const abortError = new Error('Aborted');
          abortError.name = 'AbortError';
          throw abortError;
        }
        const endpoint = stremioAddonManager.getResourceUrl(
          addon,
          'stream',
          requestType,
          parsed.id,
        );
        const data = await this.getAddonRequest(
          endpoint,
          signal,
          streamAddonRequestTimeout,
        );
        return {addon, streams: asArray<any>(data, 'streams')};
      }),
    );

    if (signal?.aborted) {
      const abortError = new Error('Aborted');
      abortError.name = 'AbortError';
      throw abortError;
    }

    const output: Stream[] = [];
    const seen = new Set<string>();
    for (const result of results) {
      if (result.status !== 'fulfilled') continue;
      const {addon, streams} = result.value;
      for (const stream of streams) {
        const infoHash = text(
          stream.infoHash ||
            stream.behaviorHints?.infoHash ||
            stream.behaviorHints?.videoHash,
        ).trim();
        const rawFileIdx =
          stream.fileIdx ??
          stream.behaviorHints?.fileIdx ??
          stream.behaviorHints?.videoFileIdx;
        const parsedFileIdx = Number(rawFileIdx);
        const fileIdx = Number.isFinite(parsedFileIdx) && parsedFileIdx >= 0
          ? parsedFileIdx
          : undefined;
        let streamUrl = text(stream.url || stream.externalUrl || stream.ytId);
        const isTorrent =
          Boolean(infoHash) ||
          /^magnet:/i.test(streamUrl) ||
          String(stream.type || '').toLowerCase() === 'torrent' ||
          String(stream.behaviorHints?.p2p || '').toLowerCase() === 'true';

        // Stremio torrent addons may return a torrent identity without an HTTP
        // URL. Convert it to the magnet form already understood by the native
        // torrent engine. Do not hard-code any addon name.
        if (!streamUrl && infoHash) {
          streamUrl = `magnet:?xt=urn:btih:${encodeURIComponent(infoHash)}`;
        }

        // P2P can be disabled independently of normal HTTP/HTTPS streams.
        if (isTorrent && !settingsStorage.isP2PStreamingEnabled()) continue;
        if (!streamUrl) continue;

        const candidateStream = {
          link: streamUrl,
          type: isTorrent ? 'torrent' : text(stream.type, 'video/mp4'),
          infoHash: infoHash || undefined,
        } as Stream;
        if (!isPotentiallyPlayableStream(candidateStream)) continue;

        const headers = stream.headers || stream.behaviorHints?.headers;
        const dedupeKey = `${streamUrl}|${fileIdx ?? ''}|${JSON.stringify(headers || {})}`;
        if (seen.has(dedupeKey)) continue;
        seen.add(dedupeKey);

        const streamName = text(stream.name || stream.title);
        const streamQuality =
          text(stream.quality) ||
          getStreamQualityCategories({
            ...stream,
            tag: streamName,
          } as any)[0] ||
          text(streamName).match(/(?:8k|4k|2160p|1440p|1080p|720p|576p|480p|360p|240p|144p)/i)?.[0] ||
          undefined;

        output.push({
          // Keep provider identity stable so stream-only addons can be grouped
          // under their own provider name in the UI.
          server: addon.name,
          link: streamUrl,
          type: isTorrent ? 'torrent' : text(stream.type, 'video/mp4'),
          quality: streamQuality,
          tag: streamName || undefined,
          tags: Array.isArray(stream.tags) ? stream.tags.map(String) : undefined,
          headers,
          size: stream.size ?? stream.fileSize ?? stream.filesize ?? stream.behaviorHints?.videoSize ?? stream.behaviorHints?.video_size ?? stream.behaviorHints?.size,
          infoHash: infoHash || undefined,
          fileIdx,
          subtitles: Array.isArray(stream.subtitles)
            ? stream.subtitles
            : undefined,
          skip: Array.isArray(stream.skip)
            ? stream.skip
            : Array.isArray(stream.behaviorHints?.skip)
            ? stream.behaviorHints.skip
            : undefined,
        });
      }
    }

    return output;
  }
}

export const stremioProviderManager = new StremioProviderManager();
export default stremioProviderManager;

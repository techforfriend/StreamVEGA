import axios from 'axios';
import {mainStorage} from '../storage/StorageService';

export type StremioResourceType = 'catalog' | 'meta' | 'stream';

export interface StremioExtra {
  name: string;
  isRequired?: boolean;
  options?: string[];
  optionsLimit?: number;
}

export interface StremioCatalogManifest {
  type: string;
  id: string;
  name?: string;
  extra?: StremioExtra[];
  genres?: string[];
  extraSupported?: string[];
}

export interface StremioResource {
  name: StremioResourceType;
  types?: string[];
  idPrefixes?: string[];
  extra?: StremioExtra[];
}

export interface StremioManifest {
  id: string;
  version?: string;
  name: string;
  description?: string;
  logo?: string;
  background?: string;
  types?: string[];
  catalogs?: StremioCatalogManifest[];
  endpoint?: string;
  resources?: Array<StremioResourceType | StremioResource>;
  config?: Array<{
    key: string;
    type: string;
    default?: string;
    title?: string;
    options?: string[];
    required?: boolean;
  }>;
  behaviorHints?: {
    configurable?: boolean;
    configurationRequired?: boolean;
    [key: string]: unknown;
  };
}

export interface StremioAddon {
  /** Stable identity scoped to the normalized manifest URL. */
  id: string;
  url: string;
  manifest: StremioManifest;
  name: string;
  version?: string;
  description?: string;
  logo?: string;
  types: string[];
  enabled: boolean;
  installedAt: number;
}

const KEY = 'stremioAddons.v2';
const LEGACY_KEY = 'stremioAddons';

const normalizeUrl = (url: string) => {
  let value = url.trim();
  if (!value) return '';
  if (!/^https?:\/\//i.test(value)) {
    value = `https://${value}`;
  }
  return value.replace(/\/+$/, '');
};

export const manifestUrl = (url: string) => {
  const normalized = normalizeUrl(url);
  return normalized.endsWith('/manifest.json')
    ? normalized
    : `${normalized}/manifest.json`;
};

const stableId = (url: string, manifestId: string) => {
  // Keep the URL in the identity. Two manifests with the same manifest id
  // must never overwrite each other.
  const input = `${normalizeUrl(url)}|${manifestId}`;
  let hash = 2166136261;
  for (let i = 0; i < input.length; i += 1) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return `stremio_${(hash >>> 0).toString(36)}`;
};

const normalizeResource = (resource: StremioResource | StremioResourceType): StremioResource =>
  typeof resource === 'string' ? {name: resource} : resource;

const isResourceSupported = (
  addon: StremioAddon,
  name: StremioResourceType,
) => {
  const resources = addon.manifest.resources || [];
  return resources.some(resource => normalizeResource(resource).name === name);
};

class StremioAddonManager {
  list(): StremioAddon[] {
    const current = mainStorage.getArray<StremioAddon>(KEY);
    if (current && current.length > 0) return current;

    // Migrate the earlier lightweight format without losing installed addons.
    const legacy = mainStorage.getArray<any>(LEGACY_KEY) || [];
    if (!legacy.length) return [];
    const migrated: StremioAddon[] = legacy.map(item => {
      const catalogs = Array.isArray(item.catalogs) ? item.catalogs : [];
      return {
        ...item,
        id: stableId(item.url || '', String(item.id || item.name || 'addon')),
        manifest: {
          id: String(item.id || item.name || 'addon'),
          name: String(item.name || item.id || 'Addon'),
          types: Array.isArray(item.types) ? item.types : [],
          catalogs,
          resources: catalogs.length > 0 ? ['catalog', 'meta', 'stream'] : ['stream'],
        },
      };
    });
    this.save(migrated);
    return migrated;
  }

  private save(items: StremioAddon[]) {
    mainStorage.setArray(KEY, items);
  }

  private refreshInFlight: Promise<StremioAddon[]> | null = null;
  private lastRefreshAt = 0;

  async install(url: string): Promise<StremioAddon> {
    const source = normalizeUrl(url).replace(/\/manifest\.json$/i, '');
    if (!source) throw new Error('Addon URL is required');

    const response = await axios.get(manifestUrl(source), {
      timeout: 8000,
      headers: {Accept: 'application/json'},
    });

    const manifest = response.data as StremioManifest;
    if (!manifest || typeof manifest !== 'object' || !manifest.id || !manifest.name) {
      throw new Error('Invalid Stremio addon manifest');
    }

    const normalizedCatalogs = Array.isArray(manifest.catalogs)
      ? manifest.catalogs
      : [];
    const normalizedResources = Array.isArray(manifest.resources)
      ? manifest.resources
      : normalizedCatalogs.length > 0
      ? ['catalog', 'meta', 'stream']
      : ['stream'];

    const normalizedManifest: StremioManifest = {
      ...manifest,
      id: String(manifest.id),
      name: String(manifest.name),
      types: Array.isArray(manifest.types) ? manifest.types.map(String) : [],
      catalogs: normalizedCatalogs,
      resources: normalizedResources,
    };

    const addon: StremioAddon = {
      id: stableId(source, normalizedManifest.id),
      url: source,
      manifest: normalizedManifest,
      name: normalizedManifest.name,
      version: normalizedManifest.version ? String(normalizedManifest.version) : undefined,
      description: normalizedManifest.description ? String(normalizedManifest.description) : undefined,
      logo: normalizedManifest.logo ? String(normalizedManifest.logo) : undefined,
      types: normalizedManifest.types || [],
      enabled: true,
      installedAt: Date.now(),
    };

    const existing = this.list().find(item => item.id === addon.id);
    const items = this.list().filter(item => item.id !== addon.id);
    if (existing) addon.enabled = existing.enabled;
    items.push(addon);
    this.save(items);
    return addon;
  }


  async refreshAll(options: {timeoutMs?: number; force?: boolean} = {}): Promise<StremioAddon[]> {
    const timeoutMs = options.timeoutMs ?? 3000;
    if (this.refreshInFlight) return this.refreshInFlight;
    if (!options.force && Date.now() - this.lastRefreshAt < 5 * 60 * 1000) {
      return this.list();
    }

    const current = this.list();
    if (current.length === 0) return [];

    const task = (async () => {
      const results = await Promise.allSettled(
        current.map(async existing => {
        const source = normalizeUrl(existing.url).replace(/\/manifest\.json$/i, '');
        const response = await axios.get(manifestUrl(source), {
          timeout: timeoutMs,
          headers: {Accept: 'application/json'},
        });
        const manifest = response.data as StremioManifest;
        if (
          !manifest ||
          typeof manifest !== 'object' ||
          !manifest.id ||
          !manifest.name
        ) {
          throw new Error('Invalid Stremio addon manifest');
        }

        const normalizedCatalogs = Array.isArray(manifest.catalogs)
          ? manifest.catalogs
          : [];
        const normalizedResources = Array.isArray(manifest.resources)
          ? manifest.resources
          : normalizedCatalogs.length > 0
            ? ['catalog', 'meta', 'stream']
            : ['stream'];

        const normalizedManifest: StremioManifest = {
          ...manifest,
          id: String(manifest.id),
          name: String(manifest.name),
          types: Array.isArray(manifest.types)
            ? manifest.types.map(String)
            : [],
          catalogs: normalizedCatalogs,
          resources: normalizedResources,
        };

        return {
          id: stableId(source, normalizedManifest.id),
          url: source,
          manifest: normalizedManifest,
          name: normalizedManifest.name,
          version: normalizedManifest.version
            ? String(normalizedManifest.version)
            : undefined,
          description: normalizedManifest.description
            ? String(normalizedManifest.description)
            : undefined,
          logo: normalizedManifest.logo
            ? String(normalizedManifest.logo)
            : undefined,
          types: normalizedManifest.types || [],
          enabled: existing.enabled,
          installedAt: existing.installedAt,
        };
      }),
    );

      const next = results.map((result, index) =>
        result.status === 'fulfilled' ? result.value : current[index],
      );
      this.save(next);
      this.lastRefreshAt = Date.now();
      return next;
    })();

    this.refreshInFlight = task;
    try {
      return await task;
    } finally {
      this.refreshInFlight = null;
    }
  }

  async refresh(id: string, timeoutMs: number = 8000): Promise<StremioAddon | undefined> {
    const existing = this.getAddon(id);
    if (!existing) return undefined;

    const source = normalizeUrl(existing.url).replace(/\/manifest\.json$/i, '');
    const response = await axios.get(manifestUrl(source), {
      timeout: timeoutMs,
      headers: {Accept: 'application/json'},
    });
    const manifest = response.data as StremioManifest;
    if (!manifest || typeof manifest !== 'object' || !manifest.id || !manifest.name) {
      throw new Error('Invalid Stremio addon manifest');
    }

    const normalizedCatalogs = Array.isArray(manifest.catalogs)
      ? manifest.catalogs
      : [];
    const normalizedResources = Array.isArray(manifest.resources)
      ? manifest.resources
      : normalizedCatalogs.length > 0
        ? ['catalog', 'meta', 'stream']
        : ['stream'];

    const normalizedManifest: StremioManifest = {
      ...manifest,
      id: String(manifest.id),
      name: String(manifest.name),
      types: Array.isArray(manifest.types)
        ? manifest.types.map(String)
        : [],
      catalogs: normalizedCatalogs,
      resources: normalizedResources,
    };

    const updated: StremioAddon = {
      ...existing,
      id: stableId(source, normalizedManifest.id),
      url: source,
      manifest: normalizedManifest,
      name: normalizedManifest.name,
      version: normalizedManifest.version
        ? String(normalizedManifest.version)
        : undefined,
      description: normalizedManifest.description
        ? String(normalizedManifest.description)
        : undefined,
      logo: normalizedManifest.logo
        ? String(normalizedManifest.logo)
        : undefined,
      types: normalizedManifest.types || [],
    };

    const current = this.list();
    this.save(current.map(item => (item.id === id ? updated : item)));
    return updated;
  }

  async refreshIfNeeded(options: {timeoutMs?: number; minIntervalMs?: number} = {}): Promise<StremioAddon[]> {
    const minIntervalMs = options.minIntervalMs ?? 15 * 60 * 1000;
    if (this.refreshInFlight) return this.refreshInFlight;
    if (Date.now() - this.lastRefreshAt < minIntervalMs) return this.list();
    return this.refreshAll({timeoutMs: options.timeoutMs ?? 2500, force: true});
  }

  remove(id: string) {
    this.save(this.list().filter(item => item.id !== id));
  }

  setEnabled(id: string, enabled: boolean) {
    this.save(this.list().map(item => (item.id === id ? {...item, enabled} : item)));
  }

  getCatalogAddons() {
    return this.list().filter(addon => addon.enabled && (addon.manifest.catalogs?.length || isResourceSupported(addon, 'catalog')));
  }

  getResourceAddons(resource: StremioResourceType) {
    return this.list().filter(addon => addon.enabled && isResourceSupported(addon, resource));
  }

  getResourceUrl(
    addon: StremioAddon,
    resource: StremioResourceType,
    type: string,
    id: string,
    extra: Record<string, string | number | boolean | undefined> = {},
  ) {
    const path = [resource, encodeURIComponent(type)];
    if (id) path.push(encodeURIComponent(id));

    Object.entries(extra).forEach(([key, value]) => {
      if (value !== undefined && value !== '') {
        path.push(`${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`);
      }
    });

    const rawEndpoint = typeof addon.manifest.endpoint === 'string'
      ? addon.manifest.endpoint.trim()
      : '';
    let endpoint = addon.url;
    if (rawEndpoint) {
      try {
        endpoint = new URL(rawEndpoint, `${addon.url}/`).toString().replace(/\/+$/, '');
      } catch {
        endpoint = addon.url;
      }
    }
    return `${endpoint}/${path.join('/')}.json`;
  }

  /** Build the Stremio protocol-style identity used internally by StreamX. */
  makeLink(addon: StremioAddon, type: string, id: string) {
    return `stremio://${encodeURIComponent(addon.id)}/${encodeURIComponent(type)}/${encodeURIComponent(id)}`;
  }

  parseLink(link: string) {
    const match = /^stremio:\/\/([^/]+)\/([^/]+)\/(.+)$/i.exec(link);
    if (!match) return undefined;
    return {
      addonId: decodeURIComponent(match[1]),
      type: decodeURIComponent(match[2]),
      id: decodeURIComponent(match[3]),
    };
  }

  getAddon(id: string) {
    return this.list().find(item => item.id === id);
  }

  getResource(addon: StremioAddon, name: StremioResourceType) {
    return (addon.manifest.resources || [])
      .map(normalizeResource)
      .find(resource => resource.name === name);
  }
}

export const stremioAddonManager = new StremioAddonManager();
export default stremioAddonManager;

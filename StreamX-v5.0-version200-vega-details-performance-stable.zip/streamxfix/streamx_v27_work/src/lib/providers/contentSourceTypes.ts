export type ProviderKind = 'global' | 'english' | 'india' | 'italy' | 'anime' | 'drama';

/** Compatibility shape used by the existing provider-selection UI. */
export interface ContentSource {
  value: string;
  display_name: string;
  source: {author: string; url: string};
  version: string;
  icon: string;
  disabled: boolean;
  type: ProviderKind;
  installed: boolean;
  hasSettings?: boolean;
  installedAt?: number;
  lastUpdated?: number;
}

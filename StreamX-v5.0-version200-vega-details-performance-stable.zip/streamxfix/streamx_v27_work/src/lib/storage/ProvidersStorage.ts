import {mainStorage} from './StorageService';
import stremioAddonManager from '../services/StremioAddonManager';

export enum ProvidersKeys {
  DISABLED_PROVIDERS = 'disabledProviders',
}

/** Compatibility storage for screens that still refer to "providers". */
export class ProvidersStorage {
  getDisabledProviders(): string[] {
    return mainStorage.getObject<string[]>(ProvidersKeys.DISABLED_PROVIDERS) || [];
  }

  setDisabledProviders(providers: string[]): void {
    mainStorage.setObject(ProvidersKeys.DISABLED_PROVIDERS, providers);
  }

  enableAllProviders(): void {
    this.setDisabledProviders([]);
  }

  toggleProvider(providerId: string): string[] {
    const disabled = this.getDisabledProviders();
    const next = disabled.includes(providerId)
      ? disabled.filter(id => id !== providerId)
      : [...disabled, providerId];
    this.setDisabledProviders(next);
    return next;
  }

  isProviderDisabled(providerId: string): boolean {
    return this.getDisabledProviders().includes(providerId);
  }

  getInstalledProviderIds(): string[] {
    return stremioAddonManager.list().filter(addon => addon.enabled).map(addon => `stremio:${addon.id}`);
  }
}

export const providersStorage = new ProvidersStorage();

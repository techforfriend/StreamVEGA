import {create} from 'zustand';
import {settingsStorage} from '../storage';

interface NavigationPreferencesState {
  hideDownloadsTab: boolean;
  hideTabBarLabels: boolean;
  tabBarHidden: boolean;
  setHideDownloadsTab: (hide: boolean) => void;
  setHideTabBarLabels: (hide: boolean) => void;
  setTabBarHidden: (hidden: boolean) => void;
}

const useNavigationPreferencesStore = create<NavigationPreferencesState>(
  set => ({
    hideDownloadsTab: settingsStorage.hideDownloadsTab(),
    hideTabBarLabels: settingsStorage.hideTabBarLabels(),
    tabBarHidden: false,
    setHideDownloadsTab: hide => {
      settingsStorage.setHideDownloadsTab(hide);
      set({hideDownloadsTab: hide});
    },
    setHideTabBarLabels: hide => {
      settingsStorage.setHideTabBarLabels(hide);
      set({hideTabBarLabels: hide});
    },
    setTabBarHidden: hidden => set({tabBarHidden: hidden}),
  }),
);

export default useNavigationPreferencesStore;

import {create} from 'zustand';
import {persist, createJSONStorage} from 'zustand/middleware';
import {MMKVLoader} from 'react-native-mmkv-storage';
import {ContentSource} from '../providers/contentSourceTypes';
import stremioAddonManager from '../services/StremioAddonManager';
import vegaPluginManager from '../services/VegaPluginManager';

const storage = new MMKVLoader().initialize();

export interface Content {
  provider: ContentSource;
  setProvider: (type: ContentSource) => void;
  installedProviders: ContentSource[];
  availableProviders: ContentSource[];
  setInstalledProviders: (providers: ContentSource[]) => void;
  setAvailableProviders: (providers: ContentSource[]) => void;
  activeExtensionProvider: ContentSource | null;
  setActiveExtensionProvider: (provider: ContentSource | null) => void;
  syncStremioProviders: () => void;
}

export const stremioAddonToProvider = (addon: ReturnType<typeof stremioAddonManager.list>[number]): ContentSource => ({
  value: `stremio:${addon.id}`,
  display_name: addon.name,
  type: 'global',
  installed: true,
  disabled: !addon.enabled,
  version: addon.version || '1.0.0',
  icon: addon.logo || '',
  source: {author: 'Stremio', url: addon.url},
  installedAt: addon.installedAt,
  lastUpdated: addon.installedAt,
});

const getStremioProviders = () =>
  stremioAddonManager.list()
    .filter(addon => addon.enabled && (addon.manifest.catalogs?.length || addon.manifest.resources?.some(resource => typeof resource === 'string' ? resource === 'catalog' : resource.name === 'catalog')))
    .map(stremioAddonToProvider)
    .sort((a, b) => a.display_name.localeCompare(b.display_name));

const getVegaProviders = () =>
  vegaPluginManager.listInstalled()
    .filter(plugin => vegaPluginManager.isEnabled(plugin.value))
    .map(plugin => ({
      value: `vega:${plugin.value}`,
      display_name: `Vega · ${plugin.display_name}`,
      type: 'global' as const,
      installed: true,
      disabled: false,
      version: plugin.version,
      icon: plugin.icon || '',
      source: {author: plugin.source.author, url: plugin.source.url},
      installedAt: 0,
      lastUpdated: 0,
    }));

const getAllProviders = () => [...getStremioProviders(), ...getVegaProviders()]
  .sort((a, b) => a.display_name.localeCompare(b.display_name));

const initialProviders = getAllProviders();
const initialProvider = initialProviders[0] || {
  value: '',
  display_name: '',
  type: 'global' as const,
  installed: false,
  disabled: false,
  version: '0.0.0',
  icon: '',
  source: {author: '', url: ''},
  installedAt: 0,
  lastUpdated: 0,
};

const useContentStore = create<Content>()(
  persist(
    (set, get) => ({
      provider: initialProvider,
      installedProviders: initialProviders,
      availableProviders: initialProviders,
      activeExtensionProvider: initialProviders[0] || null,

      setProvider: provider => set({provider}),

      setInstalledProviders: providers =>
        set({
          installedProviders: [...providers].sort((a, b) =>
            a.display_name.localeCompare(b.display_name),
          ),
        }),

      setAvailableProviders: providers => set({availableProviders: providers}),

      setActiveExtensionProvider: provider =>
        set({activeExtensionProvider: provider}),

      syncStremioProviders: () => {
        const providers = getAllProviders();
        const current = get().provider;
        const selected = providers.find(item => item.value === current.value) || providers[0] || initialProvider;
        set({
          installedProviders: providers,
          availableProviders: providers,
          provider: selected,
          activeExtensionProvider: selected.value ? selected : null,
        });
      },
    }),
    {
      name: 'content-storage-separated-sources',
      storage: createJSONStorage(() => storage as any),
      partialize: state => ({
        provider: state.provider,
        activeExtensionProvider: state.activeExtensionProvider,
      }),
      onRehydrateStorage: () => state => {
        state?.syncStremioProviders();
      },
    },
  ),
);

export default useContentStore;

import React, {
  useState,
  useMemo,
  useCallback,
  useEffect,
  useRef,
} from 'react';
import {
  View,
  TouchableOpacity,
  ToastAndroid,
  BackHandler,
  FlatList,
  ActivityIndicator,
  Image,
  ScrollView,
  TextInput,
  Modal,
} from 'react-native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {useNavigation} from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import Feather from '@expo/vector-icons/Feather';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
  cancelAnimation,
} from 'react-native-reanimated';
import * as IntentLauncher from 'expo-intent-launcher';
import Orientation from 'react-native-orientation-locker';
import RNReactNativeHapticFeedback from 'react-native-haptic-feedback';
import {EpisodeLink, Link, Stream} from '../lib/providers/types';
import {RootStackParamList} from '../App';
import Downloader from './Downloader';
import {cacheStorage, mainStorage, settingsStorage} from '../lib/storage';
import {ifExists} from '../lib/file/ifExists';
import {useEpisodes, useStreamData} from '../lib/hooks/useEpisodes';
import SkeletonLoader from './Skeleton';
import DropdownField from './ui/DropdownField';
import {
  createDesktopCompatibleFileName,
  createDirectDownloadId,
  createSeriesDownloadId,
} from '../lib/downloadId';
import useDownloadsStore from '../lib/zustand/downloadsStore';
import {useM3Colors} from '../theme/M3PaletteContext';
import MaterialDialogSurface from './ui/MaterialDialogSurface';
import LoadingIndicator from './ui/LoadingIndicator';
import {LEGACY_TERTIARY_BACKGROUND} from '../theme/seeds';
import {withAlpha} from '../theme/glass';
import Text from './ui/Text';
import EpisodeRowContent, {getValidImageUri} from './EpisodeRowContent';
import {setSyncedEpisodeProgress} from '../lib/sync/syncService';
import {chooseBestStream, getStreamQualityCategories, isPotentiallyPlayableStream} from '../lib/streamUtils';

const CONTROL_TEXT = '#F5F0EF';
const CONTROL_TEXT_MUTED = '#D4CBC9';
// const CONTROL_OUTLINE = '#494240';

const QUALITY_FILTERS = ['All', '4K', '2K', '1080p', '720p', '480p', 'HDR'] as const;
type QualityFilter = (typeof QUALITY_FILTERS)[number];

const getStreamAddonName = (stream: Stream): string =>
  String(stream.server || 'Unknown add-on').trim() || 'Unknown add-on';

const isPromotionalStreamText = (value: unknown): boolean => {
  const text = String(value ?? '').replace(/[._-]+/g, ' ').trim().toLowerCase();
  return /donation\s*needed|join\s+the\s+discord(?:\s+server)?|i\s+support\s+the\s+project/.test(text);
};

const isPromotionalStream = (stream: any): boolean =>
  isPromotionalStreamText(stream?.title) ||
  isPromotionalStreamText(stream?.name) ||
  isPromotionalStreamText(stream?.tag) ||
  isPromotionalStreamText(stream?.server) ||
  isPromotionalStreamText(stream?.description);

const formatStreamFileSize = (stream: Stream): string | undefined => {
  const raw =
    stream?.size ??
    stream?.fileSize ??
    (stream as any)?.filesize ??
    (stream as any)?.behaviorHints?.videoSize ??
    (stream as any)?.behaviorHints?.video_size ??
    (stream as any)?.behaviorHints?.size;
  if (raw === undefined || raw === null || raw === '') return undefined;
  if (typeof raw === 'string') {
    const trimmed = raw.trim();
    if (!trimmed) return undefined;
    if (/^\d+(?:\.\d+)?\s*(?:b|kb|mb|gb|tb)$/i.test(trimmed)) return trimmed;
    const numeric = Number(trimmed);
    if (!Number.isFinite(numeric) || numeric <= 0) return trimmed;
    return formatStreamFileSize({server: stream.server, link: stream.link, type: stream.type, size: numeric});
  }
  const bytes = Number(raw);
  if (!Number.isFinite(bytes) || bytes <= 0) return undefined;
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let value = bytes;
  let unitIndex = 0;
  while (value >= 1024 && unitIndex < units.length - 1) {
    value /= 1024;
    unitIndex += 1;
  }
  const digits = unitIndex === 0 ? 0 : value >= 10 ? 1 : 2;
  return `${value.toFixed(digits)} ${units[unitIndex]}`;
};

interface SeasonListProps {
  LinkList: Link[];
  poster: {
    logo?: string;
    poster?: string;
    background?: string;
  };
  type: string;
  metaTitle: string;
  providerValue: string;
  refreshing?: boolean;
  routeParams: Readonly<{
    link: string;
    provider?: string;
    poster?: string;
  }>;
  imdbId?: string;
  synopsis?: string;
  refreshVersion?: number;
  quickDownload?: boolean;
}

interface PlayHandlerProps {
  linkIndex: number;
  type: string;
  primaryTitle: string;
  seasonTitle: string;
  episodeData: EpisodeLink[] | Link['directLinks'];
  selectedStream?: Stream;
}

interface StickyMenuState {
  active: boolean;
  link?: string;
  type?: string;
}

interface EpisodeDetailsState {
  title: string;
  description: string;
  image?: string;
}

const getSeasonLabel = (item: Link, index: number, type: string): string => {
  const raw = String(item?.title || '').trim();
  if (type !== 'series') return raw || `Option ${index + 1}`;
  const seasonMatch = raw.match(/(?:season\s*|^s)\s*(\d+)/i);
  if (seasonMatch) return `Season ${seasonMatch[1]}`;
  if (/^(episodes|default|all)$/i.test(raw) || !raw) return `Season ${index + 1}`;
  return raw;
};

const getSeasonNumber = (item?: Link | EpisodeLink | null): number | undefined => {
  if (item && typeof (item as Link).season === 'number') {
    return (item as Link).season;
  }
  const raw = String(item?.title || '').trim();
  const match = raw.match(/(?:season\s*|^s)\s*(\d+)/i);
  if (!match) return undefined;
  const value = Number(match[1]);
  return Number.isFinite(value) ? value : undefined;
};

const getStreamQualityRank = (stream: Stream): number => {
  const categories = getStreamQualityCategories(stream);
  if (categories.includes('4K')) return 4000;
  if (categories.includes('2K')) return 2000;
  if (categories.includes('1080p')) return 1080;
  if (categories.includes('720p')) return 720;
  if (categories.includes('480p')) return 480;
  if (categories.includes('360p')) return 360;
  return 0;
};

const groupStreamsByAddon = (streams: Stream[]): Array<[string, Stream[]]> => {
  const groups = new Map<string, Stream[]>();
  for (const stream of streams) {
    const addonName = String(stream.server || 'Unknown add-on').trim() || 'Unknown add-on';
    const group = groups.get(addonName);
    if (group) group.push(stream);
    else groups.set(addonName, [stream]);
  }
  return Array.from(groups.entries()).sort(([a], [b]) => a.localeCompare(b));
};

const getOriginalLinkIndex = <T extends {link: string}>(
  links: T[] | undefined,
  link: string,
  fallbackIndex: number,
): number => {
  const originalIndex = links?.findIndex(item => item.link === link) ?? -1;
  return originalIndex >= 0 ? originalIndex : fallbackIndex;
};

const SeasonListContent: React.FC<SeasonListProps> = ({
  LinkList,
  poster,
  type,
  metaTitle,
  providerValue,
  refreshing,
  routeParams,
  imdbId,
  synopsis,
  refreshVersion,
  quickDownload,
}) => {
  const colors = useM3Colors();
  const primary = colors.primary;
  const isVegaEnvironment = providerValue.startsWith('vega:');
  const navigation =
    useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const {fetchStreams} = useStreamData();
  const streamFetchControllerRef = useRef<AbortController | null>(null);
  const [autoStreams, setAutoStreams] = useState<Stream[]>([]);
  const [selectedAutoStream, setSelectedAutoStream] = useState<Stream | null>(null);
  const [autoQualitySelected, setAutoQualitySelected] = useState(true);
  const [autoStreamLoading, setAutoStreamLoading] = useState(false);
  const [showMovieStreamModal, setShowMovieStreamModal] = useState(false);
  const [movieQualityFilter, setMovieQualityFilter] = useState<QualityFilter>('All');
  const [movieAddonFilter, setMovieAddonFilter] = useState<string>('All');
  const [episodeQualityFilter, setEpisodeQualityFilter] = useState<QualityFilter>('All');
  const [episodeAddonFilter, setEpisodeAddonFilter] = useState<string>('All');
  const detailsPressRef = useRef<string | null>(null);
  const episodeSortOrderKey = `episodeSortOrder:${providerValue}:${routeParams.link}`;
  const lastStreamSelectionKey = `lastStream:${providerValue}:${routeParams.link}`;

  // Memoized initial active season
  const [activeSeason, setActiveSeason] = useState<Link>(() => {
    if (!LinkList || LinkList.length === 0) {
      return {} as Link;
    }

    const cached = cacheStorage.getString(
      `ActiveSeason${metaTitle + providerValue}`,
    );

    if (cached) {
      try {
        const parsedSeason = JSON.parse(cached);
        // Verify the cached season still exists in LinkList
        const seasonExists = LinkList.find(link =>
          link.title === parsedSeason.title &&
          (link.episodesLink || '') === (parsedSeason.episodesLink || '') &&
          (link.directLinks?.[0]?.link || '') === (parsedSeason.directLinks?.[0]?.link || ''),
        );
        if (seasonExists) {
          return seasonExists;
        }
      } catch (error) {
        console.warn('Failed to parse cached season:', error);
      }
    }

    return LinkList[0];
  });

  // React Query for endpoint-backed episode lists. Some Vega plugins expose
  // the season episodes inline in metadata instead, so use those as a fallback.
  const episodeQuery = useEpisodes(
    activeSeason?.episodesLink,
    providerValue,
    Boolean(activeSeason?.episodesLink),
  );
  const fetchedEpisodeList = episodeQuery.data || [];
  const episodeList = useMemo(() => {
    if (fetchedEpisodeList.length > 0) return fetchedEpisodeList;
    return Array.isArray(activeSeason?.episodes) ? activeSeason.episodes : [];
  }, [activeSeason?.episodes, fetchedEpisodeList]);
  const episodeLoading = episodeQuery.isLoading && episodeList.length === 0;
  const episodeFetching = episodeQuery.isFetching;
  const episodeError = episodeList.length > 0 ? null : episodeQuery.error;
  const refetchEpisodes = episodeQuery.refetch;

  // If a provider refresh returns richer season objects, replace the stale
  // cached season object without resetting an inferred season that is not
  // separately represented in LinkList.
  useEffect(() => {
    if (!Array.isArray(LinkList) || LinkList.length === 0) return;
    setActiveSeason(current => {
      const currentSeason = getSeasonNumber(current);
      const matched = currentSeason !== undefined
        ? LinkList.find(item => getSeasonNumber(item) === currentSeason)
        : LinkList.find(item =>
            item.title === current.title &&
            (item.episodesLink || '') === (current.episodesLink || '') &&
            (item.directLinks?.[0]?.link || '') === (current.directLinks?.[0]?.link || ''),
          );
      if (matched) return matched;
      if (!current?.title && !current?.episodesLink && !current?.directLinks?.length) {
        return LinkList[0];
      }
      return current;
    });
  }, [LinkList]);

  // When older/cached metadata provides a single "Episodes" link, derive
  // real season choices from the Stremio episode metadata once it arrives.
  const seasonOptions = useMemo<Link[]>(() => {
    if (type !== 'series') return LinkList;

    // Vega providers differ in how they expose seasons: some return all
    // episodes with a season number, while others return one link per season.
    // Merge both sources so Season 2/3 are not hidden just because the current
    // episodes endpoint initially returned only Season 1.
    const existingBySeason = new Map<number, Link>();
    for (const link of LinkList) {
      const season = getSeasonNumber(link);
      if (season !== undefined && !existingBySeason.has(season)) {
        existingBySeason.set(season, link);
      }
    }
    const seasonNumbers = Array.from(new Set([
      ...episodeList
        .map(episode => Number(episode?.season))
        .filter(value => Number.isFinite(value) && value >= 0),
      ...existingBySeason.keys(),
    ])).sort((a, b) => a - b);

    if (seasonNumbers.length === 0) return LinkList;

    const fallbackLink = LinkList[0];
    if (!fallbackLink) return LinkList;

    return seasonNumbers.map(season => {
      const existing = existingBySeason.get(season);
      return (existing || {
        ...fallbackLink,
        title: season === 0 ? 'Specials' : `Season ${season}`,
        season,
      });
    });
  }, [LinkList, episodeList, type]);


  useEffect(() => {
    if (type !== 'series' || seasonOptions.length === 0 || episodeList.length === 0) return;
    // Only preserve a source-row selection when the rows are not season links.
    // If explicit season metadata exists, allow the selected season to track it.
    const hasExplicitSeasonLinks = LinkList.some(item => getSeasonNumber(item) !== undefined);
    if (isVegaEnvironment && LinkList.length > 1 && !hasExplicitSeasonLinks && seasonOptions.length <= 1) return;
    const activeNumber = getSeasonNumber(activeSeason);
    if (activeNumber !== undefined && seasonOptions.some(item => getSeasonNumber(item) === activeNumber)) {
      return;
    }
    const next = seasonOptions[0];
    if (!next) return;
    setActiveSeason(next);
    try {
      cacheStorage.setString(
        `ActiveSeason${metaTitle + providerValue}`,
        JSON.stringify(next),
      );
    } catch {}
  }, [activeSeason, episodeList.length, isVegaEnvironment, LinkList.length, metaTitle, providerValue, seasonOptions, type]);

  useEffect(() => {
    if (refreshing && activeSeason?.episodesLink) {
      refetchEpisodes();
    }
  }, [activeSeason?.episodesLink, refetchEpisodes, refreshVersion, refreshing]);

  // UI state
  const [vlcLoading, setVlcLoading] = useState<boolean>(false);
  const [stickyMenu, setStickyMenu] = useState<StickyMenuState>({
    active: false,
  });

  // Search and sorting state - memoized initial values
  const [searchText, setSearchText] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>(() =>
    mainStorage.getString(episodeSortOrderKey) === 'desc' ? 'desc' : 'asc',
  );

  useEffect(() => {
    setSortOrder(
      mainStorage.getString(episodeSortOrderKey) === 'desc' ? 'desc' : 'asc',
    );
  }, [episodeSortOrderKey]);

  // External player state
  const [showServerModal, setShowServerModal] = useState<boolean>(false);
  const [externalPlayerStreams, setExternalPlayerStreams] = useState<any[]>([]);
  const [isLoadingStreams, setIsLoadingStreams] = useState<boolean>(false);
  const [episodeStreamSelection, setEpisodeStreamSelection] = useState<EpisodeLink | null>(null);
  const [episodeSelectionStreams, setEpisodeSelectionStreams] = useState<Stream[]>([]);
  const [vegaSelectedEpisodeStream, setVegaSelectedEpisodeStream] = useState<Stream | null>(null);
  const [episodeSelectionLoading, setEpisodeSelectionLoading] = useState(false);
  const [episodeSelectionError, setEpisodeSelectionError] = useState<string | null>(null);
  const [isPlaybackLaunching, setIsPlaybackLaunching] = useState(false);
  const playbackLaunchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const playbackLaunchResolveRef = useRef<((shouldContinue: boolean) => void) | null>(null);
  const episodeSelectionControllerRef = useRef<AbortController | null>(null);

  const finishPlaybackLaunch = useCallback((shouldContinue: boolean) => {
    if (playbackLaunchTimerRef.current) {
      clearTimeout(playbackLaunchTimerRef.current);
      playbackLaunchTimerRef.current = null;
    }
    const resolve = playbackLaunchResolveRef.current;
    playbackLaunchResolveRef.current = null;
    setIsPlaybackLaunching(false);
    resolve?.(shouldContinue);
  }, []);

  const waitForPlaybackLaunchScreen = useCallback(() => new Promise<boolean>(resolve => {
    if (playbackLaunchTimerRef.current) {
      resolve(false);
      return;
    }
    playbackLaunchResolveRef.current = resolve;
    // Lock before mounting the launch modal so the pre-play screen itself
    // rotates to landscape, not only the player screen that follows it.
    Orientation.lockToLandscape();
    setIsPlaybackLaunching(true);
    // Give the pre-play launch screen a visible beat before transitioning into
    // the player, where stream resolution/buffering has its own live status.
    playbackLaunchTimerRef.current = setTimeout(() => {
      finishPlaybackLaunch(true);
    }, 900);
  }), [finishPlaybackLaunch]);

  const cancelPlaybackLaunch = useCallback(() => {
    finishPlaybackLaunch(false);
    Orientation.unlockAllOrientations();
  }, [finishPlaybackLaunch]);

  useEffect(() => () => {
    const launchWasPending = Boolean(
      playbackLaunchTimerRef.current || playbackLaunchResolveRef.current,
    );
    if (playbackLaunchTimerRef.current) {
      clearTimeout(playbackLaunchTimerRef.current);
      playbackLaunchTimerRef.current = null;
    }
    const resolve = playbackLaunchResolveRef.current;
    playbackLaunchResolveRef.current = null;
    // Resolve cancellation without setting React state during unmount. Keep
    // landscape locked when control is being handed directly to Player.
    resolve?.(false);
    if (launchWasPending) Orientation.unlockAllOrientations();
  }, []);
  const [episodeDetails, setEpisodeDetails] =
    useState<EpisodeDetailsState | null>(null);
  const [episodeDetailsImageFailed, setEpisodeDetailsImageFailed] =
    useState(false);

  const directLinksForActiveContent = useMemo(() => {
    if (Array.isArray(activeSeason?.directLinks) && activeSeason.directLinks.some(item => item?.link)) {
      return activeSeason.directLinks;
    }
    const flattened = (LinkList || []).flatMap(item => Array.isArray(item?.directLinks) ? item.directLinks : []);
    if (flattened.some(item => item?.link)) return flattened;
    // Some provider pages expose a playable complete-series/source URL as an
    // episodesLink but do not implement episode extraction. Once the episode
    // request has completed empty, keep that source playable/downloadable
    // rather than leaving only a dead dropdown on the details page.
    if (!episodeLoading && episodeList.length === 0 && activeSeason?.episodesLink) {
      return [{title: activeSeason.title || 'Play', link: activeSeason.episodesLink, type: type as any}];
    }
    return [];
  }, [activeSeason?.directLinks, activeSeason?.episodesLink, activeSeason?.title, episodeList.length, episodeLoading, LinkList, type]);
  const isDirectStreamPage = Boolean(directLinksForActiveContent.some(item => item?.link) && (!activeSeason?.episodesLink || episodeList.length === 0));

  const formatStreamLabel = useCallback((stream: Stream) => {
    const quality = stream.quality
      ? /p$/i.test(stream.quality)
        ? stream.quality
        : `${stream.quality}p`
      : '';
    const size = formatStreamFileSize(stream);
    const parts = [stream.server, quality, size, stream.tag].filter(Boolean);
    return parts.join(' • ') || 'Stream';
  }, []);

  // Fetch all movie/direct-link streams through the currently enabled providers.
  // A force-refresh bypasses the stream cache so the in-dialog Refresh button
  // can recover when the initial fetch returned no links.
  const fetchMovieStreams = useCallback(async (forceRefresh: boolean = false) => {
    const links = (directLinksForActiveContent || [])
      .filter(item => typeof item?.link === 'string' && item.link.trim());
    if (links.length === 0) {
      setAutoStreams([]);
      setSelectedAutoStream(null);
      setAutoStreamLoading(false);
      return;
    }

    streamFetchControllerRef.current?.abort();
    const controller = new AbortController();
    streamFetchControllerRef.current = controller;
    setAutoStreamLoading(true);

    try {
      const results = await Promise.allSettled(
        links.map(item =>
          fetchStreams(
            item.link,
            item.type || type,
            providerValue,
            controller.signal,
            forceRefresh,
          ),
        ),
      );
      if (controller.signal.aborted) return;

      const merged: Stream[] = [];
      const seen = new Set<string>();
      const excludedQualities = settingsStorage.getExcludedQualities() || [];
      for (const result of results) {
        if (result.status !== 'fulfilled') continue;
        for (const stream of result.value || []) {
          if (!isPotentiallyPlayableStream(stream)) continue;
          if (isPromotionalStream(stream)) continue;
          if (excludedQualities.some(quality => getStreamQualityCategories(stream).includes(quality))) continue;
          if (!stream?.link || seen.has(stream.link)) continue;
          seen.add(stream.link);
          merged.push(stream);
        }
      }

      setAutoStreams(merged);
      let remembered: Stream | null = null;
      try {
        const raw = cacheStorage.getString(lastStreamSelectionKey);
        if (raw) {
          const parsed = JSON.parse(raw) as Stream;
          remembered = merged.find(item => item.link === parsed?.link) || null;
        }
      } catch {}
      const best = chooseBestStream(merged);
      setSelectedAutoStream(remembered || best);
      // Vega's details-page quality selector represents the concrete selected stream.
      // Keep Stremio's existing Auto/player selection behavior unchanged.
      setAutoQualitySelected(isVegaEnvironment ? false : !remembered);
    } finally {
      // Only the currently active request may clear the loading state. An
      // aborted older request must not make a newer refresh appear complete.
      if (streamFetchControllerRef.current === controller) {
        setAutoStreamLoading(false);
        streamFetchControllerRef.current = null;
      }
    }

  }, [directLinksForActiveContent, fetchStreams, isVegaEnvironment, lastStreamSelectionKey, providerValue, type]);

  const refreshDetailsLinks = useCallback(async () => {
    if (autoStreamLoading || episodeFetching) return;
    if (isDirectStreamPage) {
      await fetchMovieStreams(true);
      return;
    }
    if (activeSeason?.episodesLink) {
      await refetchEpisodes();
    }
  }, [activeSeason?.episodesLink, autoStreamLoading, episodeFetching, fetchMovieStreams, isDirectStreamPage, refetchEpisodes]);

  // Auto-fetch movie/direct-link streams as soon as the details page opens.
  useEffect(() => {
    if (!isDirectStreamPage) {
      setAutoStreams([]);
      setSelectedAutoStream(null);
      setAutoStreamLoading(false);
      return;
    }
    void fetchMovieStreams(false);
    return () => {
      streamFetchControllerRef.current?.abort();
    };
  }, [fetchMovieStreams, isDirectStreamPage]);

  const cancelStreamFetch = useCallback(() => {
    streamFetchControllerRef.current?.abort();
    streamFetchControllerRef.current = null;
  }, []);

  useEffect(() => {
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      if (episodeDetails) {
        setEpisodeDetails(null);
        return true;
      }
      if (showServerModal) {
        setShowServerModal(false);
        return true;
      }
      if (vlcLoading || autoStreamLoading || episodeSelectionLoading) {
        cancelStreamFetch();
        episodeSelectionControllerRef.current?.abort();
        setEpisodeSelectionLoading(false);
        setEpisodeStreamSelection(null);
        setVlcLoading(false);
        setIsLoadingStreams(false);
        setAutoStreamLoading(false);
        navigation.goBack();
        return true;
      }
      return false;
    });
    return () => subscription.remove();
  }, [autoStreamLoading, cancelStreamFetch, episodeDetails, episodeSelectionLoading, navigation, showServerModal, vlcLoading]);

  useEffect(() => {
    setEpisodeDetailsImageFailed(false);
  }, [episodeDetails?.image]);

  useEffect(() => {
    const unsubscribe = navigation.addListener('beforeRemove', () => {
      episodeSelectionControllerRef.current?.abort();
      streamFetchControllerRef.current?.abort();
    });
    return unsubscribe;
  }, [navigation]);

  // VLC loading animation - using shared value so it reacts to vlcLoading state
  const vlcRotation = useSharedValue(0);

  useEffect(() => {
    if (vlcLoading) {
      vlcRotation.value = 0;
      vlcRotation.value = withRepeat(
        withTiming(360, {duration: 800}),
        -1,
        false,
      );
    } else {
      cancelAnimation(vlcRotation);
      vlcRotation.value = 0;
    }
  }, [vlcLoading]);

  const vlcLoadingAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{rotate: `${vlcRotation.value}deg`}],
  }));

  // Memoized filtering and sorting logic for episodes
  const filteredAndSortedEpisodes = useMemo(() => {
    if (!episodeList || !Array.isArray(episodeList)) {
      return [];
    }

    let episodes = episodeList.filter(
      episode => episode && episode.title && episode.link,
    );

    if (type === 'series') {
      const selectedSeason = getSeasonNumber(activeSeason);
      const availableSeasonNumbers = new Set(
        episodeList
          .map(episode => Number(episode?.season))
          .filter(value => Number.isFinite(value) && value >= 0),
      );
      if (selectedSeason !== undefined && availableSeasonNumbers.size > 0) {
        episodes = episodes.filter(episode => Number(episode.season) === selectedSeason);
      }
    }

    // Apply search filter
    if (searchText.trim()) {
      episodes = episodes.filter(episode =>
        episode?.title?.toLowerCase().includes(searchText.toLowerCase()),
      );
    }

    // Apply sorting
    if (sortOrder === 'desc') {
      episodes = [...episodes].reverse();
    }

    return episodes;
  }, [activeSeason, episodeList, searchText, sortOrder, type]);

  // Memoized direct links processing
  const filteredAndSortedDirectLinks = useMemo(() => {
    if (
      !activeSeason?.directLinks ||
      !Array.isArray(activeSeason.directLinks)
    ) {
      return [];
    }

    let links = activeSeason.directLinks.filter(
      link => link && link.title && link.link && !isPromotionalStream(link),
    );

    // Apply search filter
    if (searchText.trim()) {
      links = links.filter(link =>
        link?.title?.toLowerCase().includes(searchText.toLowerCase()),
      );
    }

    // Apply sorting
    if (sortOrder === 'desc') {
      links = [...links].reverse();
    }

    return links;
  }, [directLinksForActiveContent, searchText, sortOrder]);

  // Memoized completion checker
  const isCompleted = useCallback((link: string) => {
    const watchProgress = JSON.parse(cacheStorage.getString(link) || '{}');
    const percentage =
      (watchProgress?.position / watchProgress?.duration) * 100;
    return percentage > 85;
  }, []);

  // Memoized toggle sort order
  const toggleSortOrder = useCallback(() => {
    const newOrder = sortOrder === 'asc' ? 'desc' : 'asc';
    setSortOrder(newOrder);
    mainStorage.setString(episodeSortOrderKey, newOrder);
  }, [episodeSortOrderKey, sortOrder]);

  const formatStreamQuality = useCallback((stream: Stream) => {
    if (!stream.quality) return 'Auto';
    const raw = String(stream.quality).trim();
    if (/k$/i.test(raw)) return raw.toUpperCase();
    return /p$/i.test(raw) ? raw : `${raw}p`;
  }, []);

  const formatVegaStreamTitle = useCallback((stream: Stream) => {
    const extras = stream as Stream & {title?: string; name?: string; description?: string};
    const title = String(extras.title || extras.name || '').trim();
    if (title) return title;
    const quality = formatStreamQuality(stream);
    const size = formatStreamFileSize(stream);
    const tag = String(stream.tag || (Array.isArray(stream.tags) ? stream.tags.join(' ') : '') || '').trim();
    return [quality !== 'Auto' ? quality : '', tag, size ? `[${size}]` : ''].filter(Boolean).join(' ') || stream.server || 'Stream';
  }, [formatStreamQuality]);

  const getStreamFilterMatches = useCallback((stream: Stream, filter: QualityFilter) => {
    if (filter === 'All') return true;
    return getStreamQualityCategories(stream).includes(filter);
  }, []);

  const movieQualityFilteredStreams = useMemo(
    () => autoStreams.filter(stream => getStreamFilterMatches(stream, movieQualityFilter)),
    [autoStreams, getStreamFilterMatches, movieQualityFilter],
  );

  const movieAddonFilters = useMemo(() => {
    const counts = new Map<string, number>();
    for (const stream of movieQualityFilteredStreams) {
      const addon = getStreamAddonName(stream);
      counts.set(addon, (counts.get(addon) || 0) + 1);
    }
    return [
      ['All', movieQualityFilteredStreams.length] as const,
      ...Array.from(counts.entries()).sort(([a], [b]) => a.localeCompare(b)),
    ];
  }, [movieQualityFilteredStreams]);

  const movieFilteredStreams = useMemo(
    () => movieQualityFilteredStreams.filter(
      stream => movieAddonFilter === 'All' || getStreamAddonName(stream) === movieAddonFilter,
    ),
    [movieQualityFilteredStreams, movieAddonFilter],
  );

  const episodeQualityFilteredStreams = useMemo(
    () => episodeSelectionStreams.filter(stream => getStreamFilterMatches(stream, episodeQualityFilter)),
    [episodeSelectionStreams, episodeQualityFilter, getStreamFilterMatches],
  );

  const episodeAddonFilters = useMemo(() => {
    const counts = new Map<string, number>();
    for (const stream of episodeQualityFilteredStreams) {
      const addon = getStreamAddonName(stream);
      counts.set(addon, (counts.get(addon) || 0) + 1);
    }
    return [
      ['All', episodeQualityFilteredStreams.length] as const,
      ...Array.from(counts.entries()).sort(([a], [b]) => a.localeCompare(b)),
    ];
  }, [episodeQualityFilteredStreams]);

  const episodeFilteredStreams = useMemo(
    () => episodeQualityFilteredStreams.filter(
      stream => episodeAddonFilter === 'All' || getStreamAddonName(stream) === episodeAddonFilter,
    ),
    [episodeQualityFilteredStreams, episodeAddonFilter],
  );

  useEffect(() => {
    if (episodeAddonFilter !== 'All' && !episodeAddonFilters.some(([addon]) => addon === episodeAddonFilter)) {
      setEpisodeAddonFilter('All');
    }
  }, [episodeAddonFilter, episodeAddonFilters]);

  useEffect(() => {
    if (movieAddonFilter !== 'All' && !movieAddonFilters.some(([addon]) => addon === movieAddonFilter)) {
      setMovieAddonFilter('All');
    }
  }, [movieAddonFilter, movieAddonFilters]);

  const movieBestStream = useMemo(
    () => chooseBestStream(autoStreams),
    [autoStreams],
  );

  const episodeBestStream = useMemo(
    () => chooseBestStream(episodeSelectionStreams),
    [episodeSelectionStreams],
  );

  const openEpisodeStreamSelection = useCallback(
    async (episode: EpisodeLink, forceRefresh: boolean = false) => {
      episodeSelectionControllerRef.current?.abort();
      const controller = new AbortController();
      episodeSelectionControllerRef.current = controller;
      setEpisodeStreamSelection(episode);
      setEpisodeSelectionStreams([]);
      if (isVegaEnvironment) setVegaSelectedEpisodeStream(null);
      setEpisodeAddonFilter('All');
      setEpisodeSelectionError(null);
      setEpisodeSelectionLoading(true);

      try {
        const streams = await fetchStreams(
          episode.link,
          episode as any && (episode as any).type ? (episode as any).type : type,
          providerValue,
          controller.signal,
          forceRefresh,
        );
        if (controller.signal.aborted) return;
        const seen = new Set<string>();
        const excludedQualities = settingsStorage.getExcludedQualities() || [];
        const sorted = [...(streams || [])]
          .filter(stream => isPotentiallyPlayableStream(stream))
          .filter(stream => !isPromotionalStream(stream))
          .filter(stream => !excludedQualities.some(quality => getStreamQualityCategories(stream).includes(quality)))
          .filter(stream => stream?.link)
          .filter(stream => {
            const key = `${stream.server}|${stream.link}|${stream.quality || ''}`;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
          })
          .sort((a, b) => {
            const providerCompare = String(a.server || '').localeCompare(String(b.server || ''));
            if (providerCompare !== 0) return providerCompare;
            return getStreamQualityRank(b) - getStreamQualityRank(a);
          });
        setEpisodeSelectionStreams(sorted);
        if (isVegaEnvironment) {
          let remembered: Stream | null = null;
          try {
            const raw = cacheStorage.getString(`lastStream:${providerValue}:${episode.link}`);
            if (raw) {
              const parsed = JSON.parse(raw) as Stream;
              remembered = sorted.find(item => item.link === parsed?.link) || null;
            }
          } catch {}
          setVegaSelectedEpisodeStream(remembered || chooseBestStream(sorted) || null);
        }
        setEpisodeSelectionError(sorted.length > 0 ? null : 'No episode streams available');
      } catch (error: any) {
        if (!controller.signal.aborted) {
          const message = error?.message || 'Failed to fetch episode streams';
          setEpisodeSelectionError(message);
          ToastAndroid.show(message, ToastAndroid.SHORT);
        }
      } finally {
        if (!controller.signal.aborted) {
          setEpisodeSelectionLoading(false);
        }
        if (episodeSelectionControllerRef.current === controller) {
          episodeSelectionControllerRef.current = null;
        }
      }
    },
    [fetchStreams, isVegaEnvironment, providerValue, type],
  );

  // In Vega's details UI the first episode is prepared automatically so the
  // Start watching action is ready once details and stream extraction finish.
  // Stremio retains its existing tap-to-open stream picker behavior.
  useEffect(() => {
    if (!isVegaEnvironment || type !== 'series' || episodeLoading || episodeFetching || episodeList.length === 0) return;
    if (episodeStreamSelection && episodeList.some(item => item.link === episodeStreamSelection.link)) return;
    const seasonNumber = getSeasonNumber(activeSeason);
    const firstEpisode = episodeList.find(item => seasonNumber === undefined || Number(item.season) === seasonNumber) || episodeList[0];
    if (firstEpisode?.link) void openEpisodeStreamSelection(firstEpisode);
  }, [activeSeason, episodeFetching, episodeList, episodeLoading, episodeStreamSelection, isVegaEnvironment, openEpisodeStreamSelection, type]);

  const closeEpisodeStreamSelection = useCallback(() => {
    episodeSelectionControllerRef.current?.abort();
    episodeSelectionControllerRef.current = null;
    setEpisodeSelectionLoading(false);
    setEpisodeStreamSelection(null);
    setEpisodeSelectionStreams([]);
    if (isVegaEnvironment) setVegaSelectedEpisodeStream(null);
    setEpisodeSelectionError(null);
  }, [isVegaEnvironment]);





  // Memoized season change handler
  const handleSeasonChange = useCallback(
    (item: Link) => {
      if (isVegaEnvironment) {
        closeEpisodeStreamSelection();
      }
      setActiveSeason(item);
      setSearchText('');
      cacheStorage.setString(
        `ActiveSeason${metaTitle + providerValue}`,
        JSON.stringify(item),
      );
    },
    [closeEpisodeStreamSelection, isVegaEnvironment, metaTitle, providerValue],
  );

  // Memoized external player handler
  const handleExternalPlayer = useCallback(
    async (link: string, streamType: string) => {
      setVlcLoading(true);
      setIsLoadingStreams(true);

      try {
        cancelStreamFetch();
        const controller = new AbortController();
        streamFetchControllerRef.current = controller;
        const streams = await fetchStreams(
          link,
          streamType,
          providerValue,
          controller.signal,
        );

        if (!streams || streams.length === 0) {
          ToastAndroid.show(
            'No streams available from add-on',
            ToastAndroid.SHORT,
          );
          return;
        }

        console.log('Available Streams Count:', streams.length);
        setExternalPlayerStreams([...streams]);
        setIsLoadingStreams(false);
        setVlcLoading(false);
        setShowServerModal(true);

        ToastAndroid.show(
          `Found ${streams.length} servers`,
          ToastAndroid.SHORT,
        );
      } catch (error: any) {
        console.error('Error fetching streams:', error);
        const errorMessage = error?.message || 'Failed to load streams';
        ToastAndroid.show(errorMessage, ToastAndroid.SHORT);
      } finally {
        setVlcLoading(false);
        setIsLoadingStreams(false);
        streamFetchControllerRef.current = null;
      }
    },
    [cancelStreamFetch, fetchStreams, providerValue],
  );

  // Memoized external player opener
  const openExternalPlayer = useCallback(
    async (
      streamUrl: string,
      headers?: Record<string, string>,
      title?: string,
    ) => {
      setShowServerModal(false);
      setVlcLoading(true);

      try {
        const intentParams: any = {
          data: streamUrl,
          type: 'video/*',
          flags: 1,
        };

        const extra: Record<string, any> = {};

        if (title) {
          extra.title = title;
          extra['android.intent.extra.TITLE'] = title;
        }

        if (headers && Object.keys(headers).length > 0) {
          Object.assign(extra, headers);
          extra['android.media.intent.extra.HTTP_HEADERS'] = headers;
          extra.headers = headers;

          const headersArray = Object.entries(headers).map(
            ([key, val]) => `${key}: ${val}`,
          );
          extra.headers_array = headersArray;

          const referer = headers['Referer'] || headers['referer'];
          if (referer) {
            extra['android.intent.extra.REFERRER'] = referer;
            extra['android.intent.extra.REFERRER_NAME'] = referer;
          }
        }

        if (Object.keys(extra).length > 0) {
          intentParams.extra = extra;
        }

        await IntentLauncher.startActivityAsync(
          'android.intent.action.VIEW',
          intentParams,
        );
      } catch (error) {
        console.error('Error opening external player:', error);
        ToastAndroid.show('Failed to open external player', ToastAndroid.SHORT);
      } finally {
        setVlcLoading(false);
      }
    },
    [],
  );

  // Memoized play handler
  const playHandler = useCallback(
    async ({
      linkIndex,
      type: playbackType,
      primaryTitle,
      seasonTitle,
      episodeData,
      selectedStream: directStream,
    }: PlayHandlerProps) => {
      if (!episodeData || episodeData.length === 0 || !episodeData[linkIndex]?.link) {
        return;
      }
      if (playbackLaunchTimerRef.current) {
        return;
      }

      const link = episodeData[linkIndex].link;

      if (directStream?.link) {
        try {
          cacheStorage.setString(
            `lastStream:${providerValue}:${link}`,
            JSON.stringify(directStream),
          );
        } catch {}
      }

      const file = (
        metaTitle +
        seasonTitle +
        episodeData[linkIndex]?.title
      ).replaceAll(/[^a-zA-Z0-9]/g, '_');

      const externalPlayer = settingsStorage.getBool('useExternalPlayer');
      const dwFile = await ifExists(file);

      const downloadIndex = getOriginalLinkIndex(episodeList, link, linkIndex);
      const downloadId = createSeriesDownloadId(
        metaTitle,
        seasonTitle,
        downloadIndex,
      );
      const localDownload =
        useDownloadsStore.getState().downloads[downloadId];
      const localPath =
        (localDownload?.status === 'completed' && localDownload?.filePath) ||
        dwFile;

      if (externalPlayer) {
        if (localPath) {
          await IntentLauncher.startActivityAsync(
            'android.intent.action.VIEW',
            {
              data: localPath,
              type: 'video/*',
            },
          );
          return;
        }
        handleExternalPlayer(link, playbackType);
        return;
      }

      const continuePlayback = await waitForPlaybackLaunchScreen();
      if (!continuePlayback) return;

      navigation.navigate('Player', {
        linkIndex,
        episodeList: episodeData,
        type: playbackType,
        primaryTitle: primaryTitle,
        secondaryTitle: seasonTitle,
        poster: poster,
        providerValue: providerValue,
        infoUrl: routeParams.link,
        directStream: directStream || undefined,
      });
    },
    [
      routeParams.link,
      poster,
      providerValue,
      metaTitle,
      handleExternalPlayer,
      navigation,
      waitForPlaybackLaunchScreen,
      episodeList,
    ],
  );





  const playSelectedEpisodeStream = useCallback(
    (stream: Stream) => {
      const episode = episodeStreamSelection;
      if (!episode) return;
      try {
        cacheStorage.setString(
          `lastStream:${providerValue}:${episode.link}`,
          JSON.stringify(stream),
        );
      } catch {}
      closeEpisodeStreamSelection();
      playHandler({
        linkIndex: 0,
        type,
        primaryTitle: metaTitle,
        seasonTitle: activeSeason?.title || '',
        episodeData: [episode],
        selectedStream: stream,
      });
    },
    [activeSeason?.title, closeEpisodeStreamSelection, episodeStreamSelection, metaTitle, playHandler, providerValue, type],
  );

  const playVegaSelectedEpisode = useCallback(() => {
    const episode = episodeStreamSelection;
    const stream = vegaSelectedEpisodeStream;
    if (!episode?.link || !stream?.link || episodeSelectionLoading) return;
    try {
      cacheStorage.setString(`lastStream:${providerValue}:${episode.link}`, JSON.stringify(stream));
    } catch {}
    playHandler({
      linkIndex: 0,
      type,
      primaryTitle: metaTitle,
      seasonTitle: activeSeason?.title || '',
      episodeData: [episode],
      selectedStream: stream,
    });
  }, [activeSeason?.title, episodeSelectionLoading, episodeStreamSelection, metaTitle, playHandler, providerValue, type, vegaSelectedEpisodeStream]);

  // Memoized long press handler
  const onLongPressHandler = useCallback(
    (active: boolean, link: string, streamType?: string) => {
      if (settingsStorage.isHapticFeedbackEnabled()) {
        RNReactNativeHapticFeedback.trigger('effectTick', {
          enableVibrateFallback: true,
          ignoreAndroidSystemSettings: false,
        });
      }
      setStickyMenu({active: active, link: link, type: streamType});
    },
    [],
  );

  // Memoized mark as watched handler
  const markAsWatched = useCallback(() => {
    if (stickyMenu.link) {
      cacheStorage.setString(
        stickyMenu.link,
        JSON.stringify({
          position: 1,
          duration: 1,
        }),
      );
      const episode = [
        ...episodeList,
        ...(activeSeason.directLinks || []),
      ].find(item => item.link === stickyMenu.link);
      if (episode) {
        setSyncedEpisodeProgress({
          episode,
          title: metaTitle,
          poster: poster.poster,
          background: poster.background,
          provider: providerValue,
          infoUrl: routeParams.link,
          type,
          position: 1,
          duration: 1,
        });
      }
      setStickyMenu({active: false});
    }
  }, [
    activeSeason.directLinks,
    episodeList,
    metaTitle,
    poster.background,
    poster.poster,
    providerValue,
    routeParams.link,
    stickyMenu.link,
    type,
  ]);

  // Memoized mark as unwatched handler
  const markAsUnwatched = useCallback(() => {
    if (stickyMenu.link) {
      cacheStorage.setString(
        stickyMenu.link,
        JSON.stringify({
          position: 0,
          duration: 1,
        }),
      );
      const episode = [
        ...episodeList,
        ...(activeSeason.directLinks || []),
      ].find(item => item.link === stickyMenu.link);
      if (episode) {
        setSyncedEpisodeProgress({
          episode,
          title: metaTitle,
          poster: poster.poster,
          background: poster.background,
          provider: providerValue,
          infoUrl: routeParams.link,
          type,
          position: 0,
          duration: 1,
        });
      }
      setStickyMenu({active: false});
    }
  }, [
    activeSeason.directLinks,
    episodeList,
    metaTitle,
    poster.background,
    poster.poster,
    providerValue,
    routeParams.link,
    stickyMenu.link,
    type,
  ]);

  // Memoized sticky menu external player handler
  const handleStickyMenuExternalPlayer = useCallback(() => {
    setStickyMenu({active: false});
    if (stickyMenu.link && stickyMenu.type) {
      handleExternalPlayer(stickyMenu.link, stickyMenu.type);
    }
  }, [stickyMenu.link, stickyMenu.type, handleExternalPlayer]);

  // Memoized episode render item
  const renderEpisodeItem = useCallback(
    ({item, index}: {item: EpisodeLink; index: number}) => {
      if (!item || !item.link || !item.title) {
        console.warn('Invalid episode item at index', index, item);
        return null; // Skip rendering if item is invalid
      }

      const downloadIndex = getOriginalLinkIndex(episodeList, item.link, index);
      const downloadId = createSeriesDownloadId(
        metaTitle,
        activeSeason.title,
        downloadIndex,
      );
      const handleEpisodePress = () => {
        const episode = filteredAndSortedEpisodes[index];
        if (!episode) return;
        void openEpisodeStreamSelection(episode);
      };
      if (isVegaEnvironment) {
        const isSelectedEpisode = episodeStreamSelection?.link === item.link;
        const selectedStream = isSelectedEpisode ? vegaSelectedEpisodeStream : null;
        const quality = selectedStream ? formatStreamQuality(selectedStream) : '';
        const fileSize = selectedStream ? formatStreamFileSize(selectedStream) : undefined;
        const titleHasQuality = /(?:360|480|720|1080|1440|2160)\s*p|4k/i.test(item.title);
        const cardTitle = selectedStream && !titleHasQuality
          ? `${item.title} — ${quality}${fileSize ? ` [${fileSize}]` : ''}`
          : item.title;
        const imageUri = getValidImageUri(item.image);
        return (
          <View key={`vega-episode-${item.link}-${index}`} style={{marginBottom: 7}}>
            <View style={{alignItems: 'center', backgroundColor: colors.surfaceContainerHigh, borderColor: isSelectedEpisode ? colors.primary : colors.outlineVariant, borderRadius: 20, borderWidth: isSelectedEpisode ? 2 : 1, flexDirection: 'row', minHeight: 58, padding: 5}}>
              <TouchableOpacity
                activeOpacity={0.78}
                onPress={handleEpisodePress}
                onLongPress={() => onLongPressHandler(true, item.link, 'series')}
                style={{alignItems: 'center', flex: 1, flexDirection: 'row', minWidth: 0}}>
                {imageUri ? (
                  <Image source={{uri: imageUri}} resizeMode="cover" style={{width: 62, height: 44, borderRadius: 8, backgroundColor: colors.surfaceContainerHighest, marginRight: 8}} />
                ) : (
                  <View style={{width: 62, height: 44, borderRadius: 8, backgroundColor: colors.surfaceContainerHighest, alignItems: 'center', justifyContent: 'center', marginRight: 8}}>
                    <MaterialCommunityIcons name="movie-open-outline" size={24} color={colors.onSurfaceVariant} />
                  </View>
                )}
                <View style={{flex: 1, minWidth: 0, justifyContent: 'center'}}>
                  <Text numberOfLines={2} style={{color: colors.onSurface, fontSize: 14, fontWeight: '800', lineHeight: 19}}>{cardTitle}</Text>
                  {item.description ? <Text numberOfLines={2} style={{color: colors.onSurfaceVariant, fontSize: 12, lineHeight: 17, marginTop: 4}}>{item.description}</Text> : null}
                  {isSelectedEpisode && episodeSelectionLoading ? (
                    <View style={{alignItems: 'center', flexDirection: 'row', marginTop: 5}}><ActivityIndicator size="small" color={colors.primary} /><Text style={{color: colors.primary, fontSize: 11, marginLeft: 6}}>Loading streams…</Text></View>
                  ) : null}
                  {isSelectedEpisode && selectedStream?.server ? <Text numberOfLines={1} style={{color: colors.onSurfaceVariant, fontSize: 10, marginTop: 3}}>{selectedStream.server}</Text> : null}
                </View>
              </TouchableOpacity>
              {isVegaEnvironment ? (
                <TouchableOpacity
                  accessibilityRole="button"
                  accessibilityLabel={`Play ${item.title}`}
                  activeOpacity={0.75}
                  onPress={() => {
                    // Open the episode directly in the app player. The player
                    // resolves streams for this episode through the active
                    // provider, so users are not forced to find a separate
                    // Play action in the download-only card UI.
                    const seasonEpisodes = episodeList.length ? episodeList : [item];
                    const selectedIndex = seasonEpisodes.findIndex((episode: any) =>
                      (item?.id && episode?.id === item.id) ||
                      (item?.link && episode?.link === item.link) ||
                      (item?.sourceLink && episode?.sourceLink === item.sourceLink),
                    );
                    void playHandler({
                      linkIndex: selectedIndex >= 0 ? selectedIndex : 0,
                      type: (item as any)?.type || type,
                      primaryTitle: metaTitle,
                      seasonTitle: activeSeason?.title || '',
                      episodeData: seasonEpisodes,
                    });
                  }}
                  style={{
                    minWidth: 70,
                    height: 34,
                    marginLeft: 4,
                    paddingHorizontal: 10,
                    borderRadius: 18,
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: colors.primaryContainer,
                  }}>
                  <MaterialCommunityIcons
                    name="play"
                    size={17}
                    color={colors.onPrimaryContainer}
                  />
                  <Text style={{color: colors.onPrimaryContainer, fontSize: 12, fontWeight: '700', marginLeft: 3}}>Play</Text>
                </TouchableOpacity>
              ) : null}
              <View style={{marginLeft: 8, paddingLeft: 4, justifyContent: 'center'}}>
                <Downloader
                  downloadId={downloadId}
                  providerValue={providerValue}
                  link={item.link}
                  type={type}
                  mediaType="series"
                  showName={metaTitle}
                  seasonTitle={activeSeason.title}
                  episodeName={item.title}
                  imdbId={imdbId}
                  poster={poster.poster}
                  background={poster.background}
                  synopsis={synopsis}
                  infoUrl={routeParams.link}
                  skip={item.skip || (item as any)?.skips}
                  streamOverride={isSelectedEpisode ? (selectedStream || undefined) : undefined}
                  quickDownload={quickDownload || activeSeason?.quickDownload || item?.quickDownload}
                  title={`${metaTitle} ${item.title}`}
                  fileName={createDesktopCompatibleFileName(`${metaTitle} ${item.title}`, 'series')}
                />
              </View>
            </View>
          </View>
        );
      }
      return (
        <View
          key={item.link + index}
          className={`w-full my-1
          ${
            isCompleted(item.link) || stickyMenu.link === item.link
              ? 'opacity-60'
              : ''
          }
        `}>
          <View
            className="min-h-[54px] flex-row w-full items-center px-3 py-1"
            style={{
              backgroundColor: LEGACY_TERTIARY_BACKGROUND,
              // borderColor: CONTROL_OUTLINE,
              borderRadius: 24,
              borderWidth: 1,
            }}>
            <TouchableOpacity
              activeOpacity={0.65}
              className="min-w-0 flex-1 items-center flex-row gap-x-3"
              onPress={() => {
                if (detailsPressRef.current === item.link) {
                  detailsPressRef.current = null;
                  return;
                }
                handleEpisodePress();
              }}
              onLongPress={() =>
                onLongPressHandler(true, item.link, 'series')
              }>
              <EpisodeRowContent
                title={item.title}
                description={item.description}
                image={item.image}
                accentColor={primary}
                textColor={CONTROL_TEXT}
                mutedTextColor={CONTROL_TEXT_MUTED}
                onShowDetailsPressIn={() => {
                  detailsPressRef.current = item.link;
                }}
                onShowDetails={
                  item.description?.trim()
                    ? () => {
                        setEpisodeDetails({
                          title: item.title,
                          description: item.description!.trim(),
                          image: item.image,
                        });
                        setTimeout(() => {
                          if (detailsPressRef.current === item.link) {
                            detailsPressRef.current = null;
                          }
                        }, 0);
                      }
                    : undefined
                }
              />
            </TouchableOpacity>
            <Downloader
              downloadId={downloadId}
              providerValue={providerValue}
              link={item.link}
              type={type}
              mediaType="series"
              showName={metaTitle}
              seasonTitle={activeSeason.title}
              episodeName={item.title}
              imdbId={imdbId}
              poster={poster.poster}
              background={poster.background}
              synopsis={synopsis}
              infoUrl={routeParams.link}
              skip={item.skip || (item as any)?.skips}
              streamOverride={isVegaEnvironment && isDirectStreamPage ? (autoQualitySelected ? (movieBestStream || undefined) : (selectedAutoStream || undefined)) : undefined}
              quickDownload={
                quickDownload ||
                activeSeason?.quickDownload ||
                item?.quickDownload
              }
              title={
                metaTitle.length > 30
                  ? metaTitle.slice(0, 30) + '... ' + item.title
                  : metaTitle + ' ' + item.title
              }
              fileName={createDesktopCompatibleFileName(
                `${metaTitle} ${item.title}`,
                'series',
              )}
            />
          </View>
        </View>
      );
    },
    [
      isCompleted,
      stickyMenu.link,
      playHandler,
      metaTitle,
      activeSeason?.title,
      episodeList,
      filteredAndSortedEpisodes,
      onLongPressHandler,
      primary,
      providerValue,
      routeParams.link,
      imdbId,
      poster.poster,
      isVegaEnvironment,
      openEpisodeStreamSelection,
      episodeStreamSelection?.link,
      vegaSelectedEpisodeStream,
      episodeSelectionLoading,
      formatStreamQuality,
    ],
  );

  // Memoized direct link render item
  const renderDirectLinkItem = useCallback(
    ({item, index}: {item: any; index: number}) => {
      if (!item || !item.link || !item.title) {
        console.warn('Invalid direct link item at index', index, item);
        return null; // Skip rendering if item is invalid
      }

      const downloadIndex = getOriginalLinkIndex(
        activeSeason.directLinks,
        item.link,
        index,
      );
      const downloadId = createDirectDownloadId(
        metaTitle,
        activeSeason.title,
        downloadIndex,
      );
      const displayTitle =
        item.title?.trim() ||
        (activeSeason?.directLinks?.length && activeSeason.directLinks.length > 1
          ? `${activeSeason?.title || 'Episode'} ${index + 1}`
          : activeSeason?.title && activeSeason.title.toLowerCase() !== 'default'
          ? activeSeason.title
          : 'Play');
      const handleEpisodePress = () => {
        playHandler({
          linkIndex: index,
          type,
          primaryTitle: metaTitle,
          seasonTitle: activeSeason?.title || '',
          episodeData: filteredAndSortedDirectLinks,
          selectedStream: autoQualitySelected ? undefined : (selectedAutoStream || undefined),
        });
      };

      return (
        <View
          key={item.link + index}
          className={`w-full my-1
          ${
            isCompleted(item.link) || stickyMenu.link === item.link
              ? 'opacity-60'
              : ''
          }
        `}>
          <View
            className="min-h-[54px] flex-row w-full items-center px-3 py-1"
            style={{
              backgroundColor: LEGACY_TERTIARY_BACKGROUND,
              // borderColor: CONTROL_OUTLINE,
              borderRadius: 24,
              borderWidth: 1,
            }}>
            <TouchableOpacity
              activeOpacity={0.65}
              className="min-w-0 flex-1 items-center flex-row gap-x-3"
              onPress={() => {
                if (detailsPressRef.current === item.link) {
                  detailsPressRef.current = null;
                  return;
                }
                handleEpisodePress();
              }}
              onLongPress={() =>
                onLongPressHandler(true, item.link, item?.type || 'series')
              }>
              <EpisodeRowContent
                title={displayTitle}
                description={item.description}
                image={item.image}
                accentColor={primary}
                textColor={CONTROL_TEXT}
                mutedTextColor={CONTROL_TEXT_MUTED}
                onShowDetailsPressIn={() => {
                  detailsPressRef.current = item.link;
                }}
                onShowDetails={
                  item.description?.trim()
                    ? () => {
                        setEpisodeDetails({
                          title: item.title,
                          description: item.description.trim(),
                          image: item.image,
                        });
                        setTimeout(() => {
                          if (detailsPressRef.current === item.link) {
                            detailsPressRef.current = null;
                          }
                        }, 0);
                      }
                    : undefined
                }
              />
            </TouchableOpacity>
            <Downloader
              downloadId={downloadId}
              providerValue={providerValue}
              link={item.link}
              type={type}
              mediaType={item?.type === 'series' ? 'series' : 'movie'}
              showName={metaTitle}
              seasonTitle={activeSeason.title}
              episodeName={item.title}
              imdbId={imdbId}
              poster={poster.poster}
              background={poster.background}
              synopsis={synopsis}
              infoUrl={routeParams.link}
              skip={item.skip || (item as any)?.skips}
              quickDownload={
                quickDownload ||
                activeSeason?.quickDownload ||
                item?.quickDownload
              }
              title={
                metaTitle.length > 30
                  ? metaTitle.slice(0, 30) + '... ' + item.title
                  : metaTitle + ' ' + item.title
              }
              fileName={
                item?.type === 'series' ||
                (activeSeason?.directLinks &&
                  activeSeason.directLinks.length > 1)
                  ? createDesktopCompatibleFileName(
                      `${metaTitle} ${item.title}`,
                      'series',
                    )
                  : createDesktopCompatibleFileName(metaTitle, 'movie')
              }
            />
          </View>
        </View>
      );
    },
    [
      isCompleted,
      stickyMenu.link,
      playHandler,
      metaTitle,
      activeSeason?.title,
      activeSeason?.directLinks,
      filteredAndSortedDirectLinks,
      onLongPressHandler,
      primary,
      providerValue,
      routeParams.link,
      imdbId,
      poster.poster,
      selectedAutoStream,
      autoQualitySelected,
    ],
  );

  // Memoized server render item
  const renderServerItem = useCallback(
    (item: any, index: number) => (
      <TouchableOpacity
        key={`server-${index}-${item.server}`}
        className="mb-2 flex-row items-center justify-between p-3"
        style={{
          backgroundColor: LEGACY_TERTIARY_BACKGROUND,
          // borderColor: CONTROL_OUTLINE,
          borderRadius: 14,
          borderWidth: 1,
        }}
        onPress={() =>
          openExternalPlayer(
            item.link,
            item.headers,
            `${metaTitle || ''} ${item.server || ''}`.trim(),
          )
        }>
        <View>
          <Text
            className="text-lg capitalize font-bold"
            style={{color: CONTROL_TEXT}}>
            {item.server || `Server ${index + 1}`}
          </Text>
          <Text className="text-xs" style={{color: CONTROL_TEXT_MUTED}}>
            {item.type ? `Format: ${item.type.toUpperCase()}` : ''}
          </Text>
        </View>
        <MaterialCommunityIcons name="vlc" size={24} color={primary} />
      </TouchableOpacity>
    ),
    [primary, openExternalPlayer, metaTitle],
  );

  // Show loading skeleton while episodes are loading
  if (episodeLoading) {
    return (
      <View>
        {seasonOptions.length > 1 && (
          <DropdownField
            options={seasonOptions}
            value={activeSeason}
            getKey={item =>
              type === 'series'
                ? `season:${getSeasonNumber(item) ?? getSeasonLabel(item, 0, type)}`
                : item.episodesLink || item.directLinks?.[0]?.link || item.title
            }
            getLabel={(item, index) => getSeasonLabel(item, index, type)}
            onChange={handleSeasonChange}
            showFullOptionLabels
          />
        )}

        <View
          style={{
            width: '100%',
            padding: 10,
            alignItems: 'flex-start',
            gap: 20,
          }}>
          {[...Array(6)].map((_, index) => (
            <SkeletonLoader key={index} show={true} height={48} width={'85%'} />
          ))}
        </View>
      </View>
    );
  }

  // Show error state
  if (episodeError) {
    return (
      <View className="p-4">
        <Text className="text-red-500 text-center">
          {episodeError.message || 'Failed to load episodes. Please try again.'}
        </Text>
        <TouchableOpacity
          className="mt-2 bg-red-600 p-2 rounded-md"
          onPress={() => refetchEpisodes()}>
          <Text className="text-white text-center">Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View>
      <Modal
        visible={isPlaybackLaunching}
        animationType="fade"
        statusBarTranslucent
        supportedOrientations={['landscape-left', 'landscape-right']}
        onRequestClose={cancelPlaybackLaunch}>
        <View style={{flex: 1, backgroundColor: '#030405', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28}}>
          {getValidImageUri(poster.background || poster.poster) ? (
            <Image
              source={{uri: getValidImageUri(poster.background || poster.poster)}}
              resizeMode="cover"
              style={{position: 'absolute', width: '100%', height: '100%', opacity: 0.18}}
            />
          ) : null}
          <View style={{position: 'absolute', top: 0, right: 0, bottom: 0, left: 0, backgroundColor: 'rgba(0,0,0,0.76)'}} />
          <View style={{width: 82, height: 82, borderRadius: 41, borderWidth: 1, borderColor: withAlpha(colors.primary, 0.45), backgroundColor: withAlpha(colors.primary, 0.13), alignItems: 'center', justifyContent: 'center', marginBottom: 24}}>
            <ActivityIndicator size="large" color={colors.primary} />
          </View>
          <Text style={{color: '#FFFFFF', fontSize: 25, fontWeight: '800', textAlign: 'center'}} numberOfLines={2}>
            {metaTitle || 'StreamX'}
          </Text>
          <Text style={{color: colors.primary, fontSize: 16, fontWeight: '700', marginTop: 13, textAlign: 'center'}}>
            Preparing playback
          </Text>
          <Text style={{color: 'rgba(255,255,255,0.70)', fontSize: 13, lineHeight: 19, marginTop: 8, maxWidth: 320, textAlign: 'center'}}>
            Getting your player ready…
          </Text>
        </View>
      </Modal>

      {/* Stream selector for movie/direct-link details pages. The first stream
          is selected automatically; choosing another one updates the Play row
          so the exact fetched stream is used without a second provider lookup. */}
      {isDirectStreamPage ? (
        <View style={{alignItems: 'center', backgroundColor: colors.surfaceContainerHigh, borderColor: colors.outlineVariant, borderRadius: 24, borderWidth: 1, flexDirection: 'row', marginBottom: 7, minHeight: 48, paddingLeft: 12, paddingRight: 5, overflow: isVegaEnvironment ? 'visible' : undefined}}>
          <TouchableOpacity
            activeOpacity={0.78}
            disabled={autoStreamLoading || autoStreams.length === 0}
            onPress={() => { setMovieQualityFilter('All'); setMovieAddonFilter('All'); setShowMovieStreamModal(true); }}
            style={{alignItems: 'center', flex: 1, flexDirection: 'row', justifyContent: 'space-between', minHeight: 44, paddingRight: 8}}>
            <View style={{flex: 1, minWidth: 0, paddingRight: 8}}>
              <Text numberOfLines={1} style={{color: colors.onSurface, fontSize: 15, fontWeight: '800', textAlign: 'center', alignSelf: 'stretch'}}>
                {autoStreamLoading ? 'Fetching streams…' : autoStreams.length > 0 ? (autoQualitySelected ? 'Select Stream' : (isVegaEnvironment ? formatVegaStreamTitle(selectedAutoStream || movieBestStream || autoStreams[0]) : formatStreamLabel(selectedAutoStream || movieBestStream || autoStreams[0]))) : 'No streams available'}
              </Text>
              <Text numberOfLines={1} style={{color: colors.onSurfaceVariant, fontSize: 11, marginTop: 2, textAlign: 'center', alignSelf: 'stretch'}}>
                {autoStreamLoading ? 'Waiting for providers…' : `${autoStreams.length} available ${autoStreams.length === 1 ? 'link' : 'links'}`}
              </Text>
            </View>
            <MaterialCommunityIcons name={isVegaEnvironment ? "chevron-down" : "playlist-play"} size={21} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity accessibilityRole="button" accessibilityLabel="Refresh stream links" disabled={autoStreamLoading} onPress={() => { void refreshDetailsLinks(); }} style={{width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: isVegaEnvironment ? 21 : 20, opacity: autoStreamLoading ? 0.55 : 1}}>
            {autoStreamLoading ? <ActivityIndicator size="small" color={colors.primary} /> : <MaterialCommunityIcons name="refresh" size={22} color={colors.primary} />}
          </TouchableOpacity>
        </View>
      ) : isVegaEnvironment ? (
        <View style={{gap: 8, marginBottom: 8}}>
          <View style={{alignItems: 'center', flexDirection: 'row', gap: 8}}>
            <View style={{flex: 1, minWidth: 0}}>
              <DropdownField
                options={type === 'series' && seasonOptions.length > 1 ? seasonOptions : LinkList}
                value={activeSeason}
                getKey={item => type === 'series' && seasonOptions.length > 1 ? `season:${getSeasonNumber(item) ?? getSeasonLabel(item, 0, type)}` : `${item.title}|${item.episodesLink || item.directLinks?.[0]?.link || ''}`}
                getLabel={(item, index) => type === 'series' && seasonOptions.length > 1 ? getSeasonLabel(item, index, type) : (item.title || getSeasonLabel(item, index || 0, type))}
                onChange={handleSeasonChange}
                showFullOptionLabels
                style={{marginBottom: 0, minHeight: 48}}
              />
            </View>
            <TouchableOpacity accessibilityRole="button" accessibilityLabel="Refresh episode links" disabled={episodeFetching || autoStreamLoading || episodeSelectionLoading} onPress={() => { if (type === 'series' && episodeStreamSelection) void openEpisodeStreamSelection(episodeStreamSelection, true); else void refreshDetailsLinks(); }} style={{width: 44, height: 44, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.surfaceContainerHigh, borderColor: colors.outlineVariant, borderWidth: 1, borderRadius: 22, opacity: episodeFetching || episodeSelectionLoading ? 0.55 : 1}}>
              {episodeFetching || episodeSelectionLoading ? <ActivityIndicator size="small" color={colors.primary} /> : <MaterialCommunityIcons name="refresh" size={22} color={colors.primary} />}
            </TouchableOpacity>
          </View>
        </View>
      ) : (
        <View style={{alignItems: 'center', flexDirection: 'row', gap: 6, marginBottom: 8}}>
          <View style={{flex: 1, minWidth: 0}}>
            <DropdownField
              options={seasonOptions}
              value={activeSeason}
              getKey={item => type === 'series' ? `season:${getSeasonNumber(item) ?? getSeasonLabel(item, 0, type)}` : item.episodesLink || item.directLinks?.[0]?.link || item.title}
              getLabel={(item, index) => getSeasonLabel(item, index, type)}
              onChange={handleSeasonChange}
              showFullOptionLabels
              style={{marginBottom: 0}}
            />
          </View>
          <TouchableOpacity accessibilityRole="button" accessibilityLabel="Refresh episode links" disabled={episodeFetching || autoStreamLoading} onPress={() => { void refreshDetailsLinks(); }} style={{width: 44, height: 44, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.surfaceContainerHigh, borderColor: colors.outlineVariant, borderWidth: 1, borderRadius: 22, opacity: episodeFetching ? 0.55 : 1}}>
            {episodeFetching ? <ActivityIndicator size="small" color={colors.primary} /> : <MaterialCommunityIcons name="refresh" size={22} color={colors.primary} />}
          </TouchableOpacity>
        </View>
      )}



      {/* Search and Sort Controls */}
      {(episodeList.length > 2 ||
        (activeSeason?.directLinks && activeSeason.directLinks?.length > 2) ||
        searchText) && (
        <View className="flex-row items-center mt-2">
          <View
            style={{
              backgroundColor: colors.surfaceContainerHigh,
              borderColor: colors.outlineVariant,
              borderRadius: 24,
              borderWidth: 1,
              flex: 1,
              flexDirection: 'row',
              height: 38,
              marginRight: 8,
              overflow: 'hidden',
            }}>
            <View
              style={{
                alignItems: 'center',
                justifyContent: 'center',
                paddingLeft: 14,
              }}>
              <MaterialCommunityIcons
                name="magnify"
                size={22}
                color={colors.primary}
              />
            </View>
            <TextInput
              accessibilityLabel="Find episode"
              placeholder="Find episode"
              placeholderTextColor={colors.onSurfaceVariant}
              selectionColor={colors.primary}
              returnKeyType="search"
              style={{
                color: colors.onSurface,
                flex: 1,
                fontSize: 16,
                paddingHorizontal: 10,
                paddingVertical: 0,
              }}
              value={searchText}
              onChangeText={setSearchText}
            />
          </View>
          <TouchableOpacity
            accessibilityLabel={
              sortOrder === 'asc'
                ? 'Sort episodes descending'
                : 'Sort episodes ascending'
            }
            className="h-11 w-11 flex-row items-center justify-center"
            style={{
              backgroundColor: colors.secondaryContainer,
              borderRadius: 22,
            }}
            onPress={toggleSortOrder}>
            <MaterialCommunityIcons
              name={sortOrder === 'asc' ? 'sort-ascending' : 'sort-descending'}
              size={24}
              color={colors.onSecondaryContainer}
            />
          </TouchableOpacity>
        </View>
      )}

      {/* Episode/Direct Links List */}
      <View className="w-full mt-2">
        {/* Episodes List */}
        {filteredAndSortedEpisodes.length > 0 && (
          <FlatList
            data={filteredAndSortedEpisodes}
            keyExtractor={(item, index) => `episode-${item.link}-${index}`}
            renderItem={renderEpisodeItem}
            maxToRenderPerBatch={10}
            windowSize={10}
            removeClippedSubviews={true}
          />
        )}

        {/* Direct Links List */}
        {filteredAndSortedDirectLinks.length > 0 && (
          <View className="w-full mt-1">
            <FlatList
              data={filteredAndSortedDirectLinks}
              keyExtractor={(item, index) => `direct-${item.link}-${index}`}
              renderItem={renderDirectLinkItem}
              maxToRenderPerBatch={10}
              windowSize={10}
              removeClippedSubviews={true}
            />
          </View>
        )}

        {/* No Content Available */}
        {filteredAndSortedEpisodes.length === 0 &&
          filteredAndSortedDirectLinks.length === 0 &&
          LinkList?.length === 0 && (
            <Text
              className="min-h-20 text-lg font-semibold"
              style={{color: colors.onSurfaceVariant}}>
              No stream found
            </Text>
          )}
      </View>

      {/* VLC Loading Indicator */}
      {vlcLoading && (
        <View
          pointerEvents="none"
          className="absolute top-0 left-0 w-full h-full bg-black/60 bg-opacity-50 justify-center items-center">
          <Animated.View style={[vlcLoadingAnimatedStyle]}>
            <MaterialCommunityIcons name="vlc" size={70} color={primary} />
          </Animated.View>
          <Text
            className="mt-2 text-lg font-semibold"
            style={{color: colors.onSurface}}>
            Loading available servers...
          </Text>
        </View>
      )}

      <MaterialDialogSurface
        visible={episodeDetails !== null}
        onDismiss={() => setEpisodeDetails(null)}
        style={{padding: 0}}>
        {episodeDetails ? (
          <>
            {getValidImageUri(episodeDetails.image) &&
            !episodeDetailsImageFailed ? (
              <Image
                source={{uri: getValidImageUri(episodeDetails.image)}}
                resizeMode="cover"
                onError={() => setEpisodeDetailsImageFailed(true)}
                style={{aspectRatio: 16 / 9, width: '100%'}}
              />
            ) : (
              <View
                style={{
                  alignItems: 'center',
                  aspectRatio: 16 / 9,
                  backgroundColor: colors.surfaceContainerHighest,
                  justifyContent: 'center',
                  width: '100%',
                }}>
                <MaterialCommunityIcons
                  name="image-off-outline"
                  size={44}
                  color={colors.onSurfaceVariant}
                />
              </View>
            )}
            <View style={{padding: 20}}>
              <Text
                role="titleLarge"
                style={{color: colors.onSurface, fontWeight: '700'}}>
                {episodeDetails.title}
              </Text>
              <ScrollView style={{maxHeight: 230}}>
                <Text
                  role="bodyMedium"
                  style={{
                    color: colors.onSurfaceVariant,
                    lineHeight: 22,
                    marginTop: 10,
                  }}>
                  {episodeDetails.description}
                </Text>
              </ScrollView>
            </View>
          </>
        ) : null}
      </MaterialDialogSurface>

      <Modal
        visible={Boolean(episodeStreamSelection) && !isVegaEnvironment}
        transparent
        animationType="fade"
        onRequestClose={closeEpisodeStreamSelection}>
        <View
          style={{
            backgroundColor: 'rgba(0,0,0,0.50)',
            flex: 1,
            justifyContent: 'flex-end',
            padding: 12,
          }}>
          <View
            style={{
              backgroundColor: colors.surfaceContainerHigh,
              borderColor: colors.outlineVariant,
              borderRadius: 24,
              borderWidth: 1,
              maxHeight: '68%',
              padding: 8,
            }}>
            <Text
              className="text-center text-lg font-bold"
              style={{color: colors.onSurface}}>
              Select Episode Stream
            </Text>
            <Text
              className="mb-2 mt-0.5 text-center text-xs"
              style={{color: colors.onSurfaceVariant}}>
              {episodeStreamSelection?.title || 'Episode'}
            </Text>

            <View
              style={{
                backgroundColor: colors.surfaceContainerLow,
                borderColor: colors.outlineVariant,
                borderRadius: 18,
                borderWidth: 1,
                marginBottom: 6,
                padding: 5,
              }}>
              <View style={{alignItems: 'center', flexDirection: 'row', marginBottom: 4}}>
                <MaterialCommunityIcons name="tune-variant" size={16} color={colors.primary} />
                <Text style={{color: colors.onSurface, fontSize: 11, fontWeight: '900', marginLeft: 5}}>Quality</Text>
                <Text style={{color: colors.onSurfaceVariant, fontSize: 10, marginLeft: 5}}>Filter streams</Text>
              </View>
              <View style={{flexDirection: 'row', flexWrap: 'wrap', gap: 4}}>
                {QUALITY_FILTERS.map(filter => {
                  const active = episodeQualityFilter === filter;
                  return (
                    <TouchableOpacity
                      key={`episode-quality-${filter}`}
                      activeOpacity={0.72}
                      onPress={() => setEpisodeQualityFilter(filter)}
                      style={{
                        alignItems: 'center',
                        backgroundColor: active ? colors.primary : colors.surfaceContainerHighest,
                        borderColor: active ? colors.primary : colors.outlineVariant,
                        borderRadius: 13,
                        borderWidth: 1,
                        flexGrow: 1,
                        minWidth: '22%',
                        paddingHorizontal: 6,
                        paddingVertical: 2,
                      }}>
                      <Text style={{color: active ? colors.onPrimary : colors.onSurfaceVariant, fontSize: 11, fontWeight: '900', lineHeight: 14, textAlign: 'center'}}>
                        {filter}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <View style={{alignItems: 'center', flexDirection: 'row', marginTop: 7, marginBottom: 4}}>
                <MaterialCommunityIcons name="puzzle-outline" size={16} color={colors.primary} />
                <Text style={{color: colors.onSurface, fontSize: 11, fontWeight: '900', marginLeft: 5}}>Add-ons</Text>
                <Text style={{color: colors.onSurfaceVariant, fontSize: 10, marginLeft: 5}}>Filter by source</Text>
              </View>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{gap: 4, paddingRight: 2}}>
                {episodeAddonFilters.map(([addon, count]) => {
                  const active = episodeAddonFilter === addon;
                  return (
                    <TouchableOpacity
                      key={`episode-addon-${addon}`}
                      activeOpacity={0.72}
                      onPress={() => setEpisodeAddonFilter(addon)}
                      style={{
                        alignItems: 'center',
                        backgroundColor: active ? colors.primary : colors.surfaceContainerHighest,
                        borderColor: active ? colors.primary : colors.outlineVariant,
                        borderRadius: 13,
                        borderWidth: 1,
                        paddingHorizontal: 10,
                        paddingVertical: 3,
                      }}>
                      <Text numberOfLines={1} style={{color: active ? colors.onPrimary : colors.onSurfaceVariant, fontSize: 11, fontWeight: '900'}}>
                        {addon} • {count}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>

            {episodeSelectionLoading ? (
              <View style={{alignItems: 'center', paddingVertical: 28}}>
                <LoadingIndicator size={36} color={primary} />
                <Text style={{color: colors.onSurfaceVariant, marginTop: 10}}>
                  Fetching streams...
                </Text>
              </View>
            ) : (
              <ScrollView
                showsVerticalScrollIndicator={false}
                contentContainerStyle={{gap: 8, paddingBottom: 2}}>
                {episodeFilteredStreams.length > 0 ? (
                  <TouchableOpacity
                    onPress={() => {
                      const episode = episodeStreamSelection;
                      if (!episode) return;
                      // Auto is not a quality. Leave stream selection to the
                      // player so its Server/Quality menu receives every valid
                      // stream returned by the installed addons.
                      closeEpisodeStreamSelection();
                      playHandler({
                        linkIndex: 0,
                        type,
                        primaryTitle: metaTitle,
                        seasonTitle: activeSeason?.title || '',
                        episodeData: [episode],
                      });
                    }}
                    style={{
                      alignItems: 'center',
                      backgroundColor: colors.secondaryContainer,
                      borderColor: colors.primary,
                      borderRadius: 18,
                      borderWidth: 1,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      minHeight: 46,
                      paddingHorizontal: 12,
                    }}>
                    <View style={{flex: 1, minWidth: 0}}>
                      <Text style={{color: colors.onSecondaryContainer, fontWeight: '800'}}>
                        Auto
                      </Text>
                      <Text numberOfLines={1} style={{color: colors.onSecondaryContainer, fontSize: 11, marginTop: 1}}>
                        Load all available links in player
                      </Text>
                    </View>
                    <MaterialCommunityIcons name="play-circle" size={22} color={colors.onSecondaryContainer} />
                  </TouchableOpacity>
                ) : null}
                {Object.entries(
                  episodeFilteredStreams.reduce((groups, stream) => {
                    const key = getStreamAddonName(stream);
                    (groups[key] ||= []).push(stream);
                    return groups;
                  }, {} as Record<string, Stream[]>),
                ).map(([providerName, streams]) => (
                  <View key={providerName} style={{gap: 5}}>
                    <Text style={{color: colors.primary, fontSize: 14, fontWeight: '800'}}>
                      {providerName}
                    </Text>
                    {streams.map((stream, streamIndex) => (
                      <TouchableOpacity
                        key={`${providerName}-${stream.link}-${streamIndex}`}
                        onPress={() => playSelectedEpisodeStream(stream)}
                        style={{
                          alignItems: 'center',
                          backgroundColor: colors.surfaceContainerHighest,
                          borderColor: colors.outlineVariant,
                          borderRadius: 18,
                          borderWidth: 1,
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          minHeight: 46,
                          paddingHorizontal: 11,
                        }}>
                        <View style={{flex: 1, minWidth: 0}}>
                          <View style={{alignItems: 'center', flexDirection: 'row', gap: 7}}>
                            <Text
                              numberOfLines={1}
                              style={{color: colors.onSurface, fontWeight: '700'}}>
                              {formatStreamQuality(stream)}
                            </Text>
                            {episodeBestStream?.link === stream.link ? (
                              <View
                                style={{
                                  backgroundColor: colors.primaryContainer,
                                  borderRadius: 7,
                                  paddingHorizontal: 6,
                                  paddingVertical: 2,
                                }}>
                                <Text
                                  numberOfLines={1}
                                  style={{color: colors.onPrimaryContainer, fontSize: 9, fontWeight: '900'}}>
                                  BEST
                                </Text>
                              </View>
                            ) : null}
                          </View>
                          {([
                            stream.tag,
                            formatStreamFileSize(stream),
                            getStreamQualityCategories(stream).includes('HDR') ? 'HDR' : undefined,
                          ].filter(Boolean).join(' • ')) ? (
                            <Text
                              numberOfLines={1}
                              ellipsizeMode="tail"
                              style={{color: colors.onSurfaceVariant, fontSize: 11, marginTop: 1}}>
                              {[stream.tag, formatStreamFileSize(stream), getStreamQualityCategories(stream).includes('HDR') ? 'HDR' : undefined]
                                .filter(Boolean)
                                .join(' • ')}
                            </Text>
                          ) : null}
                        </View>
                        {isVegaEnvironment && episodeStreamSelection ? (
                          <View style={{width: 42, height: 42, alignItems: 'center', justifyContent: 'center'}}>
                            <Downloader
                              downloadId={createSeriesDownloadId(metaTitle, activeSeason?.title || '', getOriginalLinkIndex(episodeList, episodeStreamSelection.link, 0))}
                              providerValue={providerValue}
                              link={episodeStreamSelection.link}
                              type={type}
                              mediaType="series"
                              showName={metaTitle}
                              seasonTitle={activeSeason?.title || ''}
                              episodeName={episodeStreamSelection.title}
                              imdbId={imdbId}
                              poster={poster.poster}
                              background={poster.background}
                              synopsis={synopsis}
                              infoUrl={routeParams.link}
                              title={`${metaTitle} ${episodeStreamSelection.title}`}
                              fileName={createDesktopCompatibleFileName(`${metaTitle} ${episodeStreamSelection.title}`, 'series')}
                              streamOverride={stream}
                            />
                          </View>
                        ) : <MaterialCommunityIcons name="vlc" size={22} color={primary} />}
                      </TouchableOpacity>
                    ))}
                  </View>
                ))}
                {episodeFilteredStreams.length === 0 ? (
                  <View style={{alignItems: 'center', paddingVertical: 18}}>
                    <MaterialCommunityIcons
                      name={episodeSelectionError ? 'alert-circle-outline' : 'video-off-outline'}
                      size={30}
                      color={colors.onSurfaceVariant}
                    />
                    <Text
                      style={{
                        color: colors.onSurfaceVariant,
                        paddingTop: 10,
                        textAlign: 'center',
                      }}>
                      {episodeSelectionError || 'No episode streams available'}
                    </Text>
                    <TouchableOpacity
                      disabled={episodeSelectionLoading}
                      onPress={() => {
                        const episode = episodeStreamSelection;
                        if (episode) {
                          openEpisodeStreamSelection(episode, true);
                        }
                      }}
                      style={{
                        alignItems: 'center',
                        backgroundColor: colors.secondaryContainer,
                        borderColor: colors.outlineVariant,
                        borderRadius: 16,
                        borderWidth: 1,
                        flexDirection: 'row',
                        justifyContent: 'center',
                        marginTop: 14,
                        minWidth: 150,
                        paddingHorizontal: 20,
                        paddingVertical: 11,
                      }}>
                      <MaterialCommunityIcons
                        name="refresh"
                        size={20}
                        color={colors.onSecondaryContainer}
                      />
                      <Text
                        style={{
                          color: colors.onSecondaryContainer,
                          fontWeight: '800',
                          marginLeft: 8,
                        }}>
                        Retry
                      </Text>
                    </TouchableOpacity>
                  </View>
                ) : null}
              </ScrollView>
            )}

            {episodeStreamSelection ? (() => {
              const allEpisodes = [...episodeList]
                .filter(item => item?.link)
                .sort((a, b) => {
                  const seasonA = Number.isFinite(Number(a.season)) ? Number(a.season) : 0;
                  const seasonB = Number.isFinite(Number(b.season)) ? Number(b.season) : 0;
                  if (seasonA !== seasonB) return seasonA - seasonB;
                  const episodeA = Number.isFinite(Number(a.episode)) ? Number(a.episode) : 0;
                  const episodeB = Number.isFinite(Number(b.episode)) ? Number(b.episode) : 0;
                  return episodeA - episodeB;
                });
              const currentIndex = allEpisodes.findIndex(item => item.link === episodeStreamSelection.link);
              const nextEpisode = currentIndex >= 0 ? allEpisodes[currentIndex + 1] : undefined;
              if (!nextEpisode) return null;
              return (
                <TouchableOpacity
                  activeOpacity={0.78}
                  onPress={() => openEpisodeStreamSelection(nextEpisode)}
                  style={{
                    alignItems: 'center',
                    backgroundColor: colors.tertiaryContainer,
                    borderColor: colors.outlineVariant,
                    borderRadius: 24,
                    borderWidth: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: 3,
                    minHeight: 46,
                    paddingHorizontal: 12,
                    paddingVertical: 4,
                  }}>
                  <View style={{flex: 1, minWidth: 0, paddingRight: 6}}>
                    <Text style={{color: colors.onTertiaryContainer, fontSize: 9, fontWeight: '900'}}>NEXT EPISODE</Text>
                    <Text numberOfLines={1} style={{color: colors.onTertiaryContainer, fontSize: 12, fontWeight: '800', marginTop: 1}}>
                      {nextEpisode.title}
                    </Text>
                  </View>
                  <MaterialCommunityIcons name="arrow-right" size={18} color={colors.onTertiaryContainer} />
                </TouchableOpacity>
              );
            })() : null}

            <TouchableOpacity
              onPress={closeEpisodeStreamSelection}
              style={{
                backgroundColor: colors.secondaryContainer,
                borderRadius: 22,
                marginTop: 8,
                minHeight: 44,
                justifyContent: 'center',
                paddingVertical: 9,
              }}>
              <Text
                className="text-center font-bold"
                style={{color: colors.onSecondaryContainer}}>
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showMovieStreamModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowMovieStreamModal(false)}>
        <View
          style={{
            backgroundColor: 'rgba(0,0,0,0.50)',
            flex: 1,
            justifyContent: 'flex-end',
            padding: 12,
          }}>
          <View
            style={{
              backgroundColor: 'rgba(38, 43, 46, 0.97)',
              borderColor: colors.outlineVariant,
              borderRadius: 22,
              borderWidth: 1,
              maxHeight: '78%',
              padding: 8,
            }}>
            {isVegaEnvironment ? (
              <>
                <Text style={{color: colors.onSurface, fontSize: 19, fontWeight: '900', paddingHorizontal: 8, paddingVertical: 7}}>Select link</Text>
                {autoStreamLoading ? (
                  <View style={{alignItems: 'center', paddingVertical: 26}}><ActivityIndicator size="large" color={colors.primary} /><Text style={{color: colors.onSurfaceVariant, marginTop: 12}}>Fetching available links…</Text></View>
                ) : (
                  <ScrollView showsVerticalScrollIndicator={false} style={{maxHeight: '76%'}} contentContainerStyle={{paddingBottom: 6}}>
                    {autoStreams.map((stream, index) => {
                      const selected = selectedAutoStream?.link === stream.link;
                      const extra = stream as Stream & {description?: string; title?: string; name?: string};
                      const description = String(extra.description || '').trim();
                      return (
                        <TouchableOpacity
                          key={`vega-movie-choice-${stream.link}-${index}`}
                          activeOpacity={0.78}
                          onPress={() => {
                            setSelectedAutoStream(stream);
                            setAutoQualitySelected(false);
                            try { cacheStorage.setString(lastStreamSelectionKey, JSON.stringify(stream)); } catch {}
                            setShowMovieStreamModal(false);
                          }}
                          style={{backgroundColor: selected ? colors.primaryContainer : colors.surfaceContainerHighest, borderColor: selected ? colors.primary : colors.outlineVariant, borderWidth: 1, borderRadius: 15, paddingHorizontal: 14, paddingVertical: 8, marginBottom: 6, minHeight: 50, justifyContent: 'center'}}>
                          <Text numberOfLines={1} ellipsizeMode="tail" style={{color: colors.onSurface, fontSize: 14, fontWeight: selected ? '900' : '700', lineHeight: 19, textAlign: 'center', alignSelf: 'stretch'}}>{formatVegaStreamTitle(stream)}</Text>
                          <Text numberOfLines={1} ellipsizeMode="tail" style={{color: selected ? colors.onSurface : colors.onSurface, fontSize: 11, fontWeight: '600', lineHeight: 15, marginTop: 2, textAlign: 'center', alignSelf: 'stretch'}}>{[stream.server, formatStreamQuality(stream) !== 'Auto' ? formatStreamQuality(stream) : undefined, formatStreamFileSize(stream)].filter(Boolean).join(' · ') || description || 'Stream link'}</Text>
                        </TouchableOpacity>
                      );
                    })}
                    {autoStreams.length === 0 ? <Text style={{color: colors.onSurfaceVariant, padding: 18, textAlign: 'center'}}>No playable links available. Close and use refresh to try again.</Text> : null}
                  </ScrollView>
                )}
              </>
            ) : (
              <>
            <Text className="text-center text-xl font-bold" style={{color: colors.onSurface}}>
              Select Stream
            </Text>
            <View
              style={{
                backgroundColor: colors.surfaceContainerLow,
                borderColor: colors.outlineVariant,
                borderRadius: 20,
                borderWidth: 1,
                marginBottom: 6,
                padding: 5,
              }}>
              <View style={{alignItems: 'center', flexDirection: 'row', marginBottom: 4}}>
                <MaterialCommunityIcons name="tune-variant" size={16} color={colors.primary} />
                <Text style={{color: colors.onSurface, fontSize: 11, fontWeight: '900', marginLeft: 5}}>Quality</Text>
                <Text style={{color: colors.onSurfaceVariant, fontSize: 10, marginLeft: 5}}>Filter streams</Text>
              </View>
              <View style={{flexDirection: 'row', flexWrap: 'wrap', gap: 4}}>
                {QUALITY_FILTERS.map(filter => {
                  const active = movieQualityFilter === filter;
                  return (
                    <TouchableOpacity
                      key={`movie-quality-${filter}`}
                      activeOpacity={0.72}
                      onPress={() => setMovieQualityFilter(filter)}
                      style={{
                        alignItems: 'center',
                        backgroundColor: active ? colors.primary : colors.surfaceContainerHighest,
                        borderColor: active ? colors.primary : colors.outlineVariant,
                        borderRadius: 14,
                        borderWidth: 1,
                        flexGrow: 1,
                        minWidth: '22%',
                        paddingHorizontal: 7,
                        paddingVertical: 2,
                      }}>
                      <Text
                        style={{
                          color: active ? colors.onPrimary : colors.onSurfaceVariant,
                          fontSize: 11,
                          fontWeight: '900',
                          lineHeight: 14,
                          textAlign: 'center',
                        }}>
                        {filter}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <View style={{alignItems: 'center', flexDirection: 'row', marginTop: 7, marginBottom: 4}}>
                <MaterialCommunityIcons name="puzzle-outline" size={16} color={colors.primary} />
                <Text style={{color: colors.onSurface, fontSize: 11, fontWeight: '900', marginLeft: 5}}>Add-ons</Text>
                <Text style={{color: colors.onSurfaceVariant, fontSize: 10, marginLeft: 5}}>Filter by source</Text>
              </View>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{gap: 4, paddingRight: 2}}>
                {movieAddonFilters.map(([addon, count]) => {
                  const active = movieAddonFilter === addon;
                  return (
                    <TouchableOpacity
                      key={`movie-addon-filter-${addon}`}
                      activeOpacity={0.72}
                      onPress={() => setMovieAddonFilter(addon)}
                      style={{
                        alignItems: 'center',
                        backgroundColor: active ? colors.primary : colors.surfaceContainerHighest,
                        borderColor: active ? colors.primary : colors.outlineVariant,
                        borderRadius: 13,
                        borderWidth: 1,
                        paddingHorizontal: 10,
                        paddingVertical: 3,
                      }}>
                      <Text numberOfLines={1} style={{color: active ? colors.onPrimary : colors.onSurfaceVariant, fontSize: 11, fontWeight: '900'}}>
                        {addon} • {count}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>

            {autoStreamLoading ? (
              <View style={{alignItems: 'center', paddingVertical: 28}}>
                <LoadingIndicator size={36} color={primary} />
                <Text style={{color: colors.onSurfaceVariant, marginTop: 10}}>
                  Fetching streams from installed addons…
                </Text>
              </View>
            ) : (
              <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{gap: 10, paddingBottom: 4}}>
                <TouchableOpacity
                  activeOpacity={0.78}
                  onPress={() => {
                    setSelectedAutoStream(null);
                    setAutoQualitySelected(true);
                    setShowMovieStreamModal(false);
                  }}
                  style={{
                    alignItems: 'center',
                    backgroundColor: autoQualitySelected ? colors.primaryContainer : colors.surfaceContainerHighest,
                    borderColor: autoQualitySelected ? colors.primary : colors.outlineVariant,
                    borderRadius: 16,
                    borderWidth: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    minHeight: 50,
                    paddingHorizontal: 12,
                  }}>
                  <View style={{flex: 1, minWidth: 0, paddingRight: 10, alignItems: 'center'}}>
                    <Text style={{color: autoQualitySelected ? colors.onPrimaryContainer : colors.onSurface, fontWeight: '900', textAlign: 'center'}}>Auto</Text>
                    <Text numberOfLines={1} style={{color: autoQualitySelected ? colors.onPrimaryContainer : colors.onSurfaceVariant, fontSize: 11, marginTop: 1, textAlign: 'center', alignSelf: 'stretch'}}>
                      Load all available links in player
                    </Text>
                  </View>
                  <MaterialCommunityIcons name="play-circle-outline" size={24} color={autoQualitySelected ? colors.onPrimaryContainer : primary} />
                </TouchableOpacity>

                {groupStreamsByAddon(movieFilteredStreams).map(([addonName, streams]) => (
                  <View key={`movie-addon-${addonName}`} style={{gap: 5}}>
                    <Text style={{color: colors.primary, fontSize: 13, fontWeight: '800', marginLeft: 2}}>
                      {addonName}
                    </Text>
                    {streams.map((stream, streamIndex) => (
                      <TouchableOpacity
                        key={`movie-stream-${addonName}-${stream.link}-${streamIndex}`}
                        activeOpacity={0.78}
                        onPress={() => {
                          setSelectedAutoStream(stream);
                          setAutoQualitySelected(false);
                          try { cacheStorage.setString(lastStreamSelectionKey, JSON.stringify(stream)); } catch {}
                          setShowMovieStreamModal(false);
                        }}
                        style={{
                          alignItems: 'center',
                          backgroundColor: !autoQualitySelected && selectedAutoStream?.link === stream.link ? colors.primaryContainer : colors.surfaceContainerHighest,
                          borderColor: !autoQualitySelected && selectedAutoStream?.link === stream.link ? colors.primary : colors.outlineVariant,
                          borderRadius: 18,
                          borderWidth: 1,
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          minHeight: 46,
                          paddingHorizontal: 11,
                        }}>
                        <View style={{flex: 1, minWidth: 0, paddingRight: 10, alignItems: 'center'}}>
                          <View style={{alignItems: 'center', flexDirection: 'row', gap: 7, justifyContent: 'center', alignSelf: 'stretch'}}>
                            <Text numberOfLines={1} style={{color: colors.onSurface, fontWeight: '800', fontSize: 13}}>
                              {formatStreamQuality(stream)}
                            </Text>
                            {movieBestStream?.link === stream.link ? (
                              <View style={{backgroundColor: colors.primaryContainer, borderRadius: 7, paddingHorizontal: 5, paddingVertical: 1}}>
                                <Text style={{color: colors.onPrimaryContainer, fontSize: 9, fontWeight: '900'}}>BEST</Text>
                              </View>
                            ) : null}
                          </View>
                          <Text numberOfLines={1} ellipsizeMode="tail" style={{color: colors.onSurfaceVariant, fontSize: 10, marginTop: 1, textAlign: 'center', alignSelf: 'stretch'}}>
                            {[stream.tag, formatStreamFileSize(stream), getStreamQualityCategories(stream).includes('HDR') ? 'HDR' : undefined]
                              .filter(Boolean)
                              .join(' • ')}
                          </Text>
                        </View>
                        <MaterialCommunityIcons name="check-circle-outline" size={19} color={!autoQualitySelected && selectedAutoStream?.link === stream.link ? primary : colors.onSurfaceVariant} />
                      </TouchableOpacity>
                    ))}
                  </View>
                ))}

                {movieFilteredStreams.length === 0 ? (
                  <View style={{alignItems: 'center', paddingVertical: 18}}>
                    <MaterialCommunityIcons
                      name="video-off-outline"
                      size={30}
                      color={colors.onSurfaceVariant}
                    />
                    <Text style={{color: colors.onSurfaceVariant, marginTop: 8, textAlign: 'center'}}>
                      {autoStreams.length === 0
                        ? 'No links were fetched.'
                        : 'No links match the selected quality.'}
                    </Text>
                  </View>
                ) : null}
              </ScrollView>
            )}
              </>
            )}

            <TouchableOpacity
              onPress={() => setShowMovieStreamModal(false)}
              style={{backgroundColor: colors.secondaryContainer, borderRadius: 18, marginTop: 12, paddingVertical: 12}}>
              <Text className="text-center font-bold" style={{color: colors.onSecondaryContainer}}>
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <MaterialDialogSurface
        visible={showServerModal}
        onDismiss={() => setShowServerModal(false)}>
        <Text
          className="mb-2 text-center text-xl font-bold"
          style={{color: colors.onSurface}}>
          Select External Player Server
        </Text>
        <Text
          className="mb-4 text-center text-sm"
          style={{color: colors.onSurfaceVariant}}>
          {externalPlayerStreams.length} servers available
        </Text>

        {isLoadingStreams ? (
          <LoadingIndicator size={40} color={primary} />
        ) : (
          <>
            <ScrollView style={{maxHeight: 300}}>
              {externalPlayerStreams.map((item, index) =>
                renderServerItem(item, index),
              )}
              {externalPlayerStreams.length === 0 && (
                <Text
                  className="p-4 text-center"
                  style={{color: colors.onSurfaceVariant}}>
                  No servers available
                </Text>
              )}
            </ScrollView>

            <TouchableOpacity
              className="mt-4 py-3"
              style={{
                backgroundColor: colors.secondaryContainer,
                borderRadius: 18,
              }}
              onPress={() => setShowServerModal(false)}>
              <Text
                className="text-center font-bold"
                style={{color: colors.onSecondaryContainer}}>
                Cancel
              </Text>
            </TouchableOpacity>
          </>
        )}
      </MaterialDialogSurface>

      <MaterialDialogSurface
        visible={stickyMenu.active}
        onDismiss={() => setStickyMenu({active: false})}>
        <Text
          className="mb-4 text-xl font-bold"
          style={{color: colors.onSurface}}>
          Episode actions
        </Text>
        <View style={{gap: 10}}>
          {isCompleted(stickyMenu.link || '') ? (
            <TouchableOpacity
              className="h-12 flex-row items-center gap-3 px-4"
              style={{
                backgroundColor: colors.surfaceContainerHighest,
                borderRadius: 18,
              }}
              onPress={markAsUnwatched}>
              <Ionicons name="checkmark-done" size={30} color={primary} />
              <Text style={{color: colors.onSurface}}>Mark as unwatched</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              className="h-12 flex-row items-center gap-3 px-4"
              style={{
                backgroundColor: colors.surfaceContainerHighest,
                borderRadius: 18,
              }}
              onPress={markAsWatched}>
              <Ionicons name="checkmark" size={25} color={primary} />
              <Text style={{color: colors.onSurface}}>Mark as watched</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            className="h-12 flex-row items-center gap-3 px-4"
            style={{
              backgroundColor: colors.surfaceContainerHighest,
              borderRadius: 18,
            }}
            onPress={handleStickyMenuExternalPlayer}>
            <Feather name="external-link" size={20} color={primary} />
            <Text style={{color: colors.onSurface}}>External player</Text>
          </TouchableOpacity>
        </View>
      </MaterialDialogSurface>
    </View>
  );
};


// Keep the empty state outside the hook-using content component so hooks are
// never conditionally skipped when streams arrive after a refresh.
const SeasonList: React.FC<SeasonListProps> = props => {
  if (!props.LinkList || props.LinkList.length === 0) {
    return (
      <View className="p-4">
        <Text className="text-white text-center">No Streams Available</Text>
      </View>
    );
  }
  return <SeasonListContent {...props} />;
};

export default SeasonList;

import React, {Dispatch, SetStateAction, useMemo, useState} from 'react';
import {
  ActivityIndicator,
  View,
  GestureResponderHandlers,
  Image,
  Text,
} from 'react-native';
import {styles} from './styles';
import {formatTime} from '../../utils';
import type {SkipInterval} from '../../../../lib/providers/types';
import {withAlpha} from '../../../../theme/glass';

interface SeekbarProps {
  seekerFillWidth: number;
  seekerPosition: number;
  seekColor: string;
  cachedPosition: number;
  seekerPanHandlers: GestureResponderHandlers;
  setSeekerWidth: Dispatch<SetStateAction<number>>;
  time?: number;
  duration: number;
  showDuration: boolean;
  showHours: boolean;
  seeking: boolean;
  previewTime: number;
  thumbnailUri: string | null;
  thumbnailLoading: boolean;
  snapPosition: number | null;
  skips?: SkipInterval[];
}

const PREVIEW_WIDTH = 160;

export const Seekbar = ({
  seekColor,
  seekerFillWidth,
  seekerPosition,
  cachedPosition,
  seekerPanHandlers,
  setSeekerWidth,
  showDuration,
  showHours,
  time,
  duration,
  seeking,
  previewTime,
  thumbnailUri,
  thumbnailLoading,
  snapPosition,
  skips,
}: SeekbarProps) => {
  const [trackWidth, setTrackWidth] = useState(0);
  const safeDuration = Number.isFinite(duration) && duration > 0 ? duration : 0;
  const safeTime = Number.isFinite(time) ? Math.max(0, Math.min(safeDuration, time ?? 0)) : 0;
  const safePosition = Number.isFinite(seekerPosition) ? Math.max(0, Math.min(trackWidth, seekerPosition)) : 0;
  const safeFillWidth = Number.isFinite(seekerFillWidth) ? Math.max(0, Math.min(trackWidth, seekerFillWidth)) : 0;
  const safeCachedPosition = Number.isFinite(cachedPosition) ? Math.max(0, Math.min(trackWidth, cachedPosition)) : 0;
  const previewLeft = useMemo(
    () =>
      Math.max(
        0,
        Math.min(
          Math.max(0, trackWidth - PREVIEW_WIDTH),
          safePosition - PREVIEW_WIDTH / 2,
        ),
      ),
    [safePosition, trackWidth],
  );
  const timestampStyle = {
    color: 'hsl(0, 0%, 76%)',
    fontSize: 11,
    fontWeight: '400' as const,
    letterSpacing: 0.1,
    fontVariant: ['tabular-nums'] as const,
  };

  return (
    <View
      style={{
        marginBottom: 0,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <View style={{minWidth: 38, alignItems: 'flex-start'}} pointerEvents="none">
        <Text style={timestampStyle}>
          {formatTime({
            duration: safeDuration,
            time: safeTime,
            showDuration: false,
            showHours,
            showTimeRemaining: false,
          })}
        </Text>
      </View>
      <View
        style={[styles.container, {flex: 1, minWidth: 0, height: 44, marginHorizontal: 7}]}
        collapsable={false}
        hitSlop={{top: 4, bottom: 4}}
        {...seekerPanHandlers}>
        {seeking && trackWidth > 0 ? (
          <View style={[styles.preview, {left: previewLeft}]} pointerEvents="none">
            {thumbnailUri ? (
              <Image
                key={thumbnailUri}
                source={{uri: thumbnailUri}}
                style={styles.previewImage}
                resizeMode="cover"
              />
            ) : (
              <View style={styles.previewPlaceholder} />
            )}
            {thumbnailLoading ? (
              <View style={styles.previewLoading}>
                <ActivityIndicator size="small" color="#fff" />
              </View>
            ) : null}
            <View style={styles.previewTimestampContainer}>
              <Text style={styles.previewTimestamp}>
                {formatTime({
                  duration,
                  time: previewTime,
                  showDuration,
                  showHours,
                  showTimeRemaining: false,
                })}
              </Text>
            </View>
          </View>
        ) : null}
        <View
          style={[
            styles.track,
            {
              top: 16,
              height: 4,
              borderRadius: 2,
              backgroundColor: withAlpha(seekColor || '#FFFFFF', 0.24),
            },
          ]}
          onLayout={event => {
            const width = event.nativeEvent.layout.width;
            if (width > 0 && Math.abs(width - trackWidth) > 1) {
              setTrackWidth(width);
              setSeekerWidth(width);
            }
          }}
          pointerEvents="none">
          <View
            style={{
              width: safeCachedPosition,
              backgroundColor: withAlpha(seekColor || '#FFFFFF', 0.52),
              height: 4,
              position: 'absolute',
              top: 0,
              borderRadius: 2,
            }}
            pointerEvents="none"
          />
          <View
            style={[
              styles.fill,
              {
                width: safeFillWidth,
                backgroundColor: seekColor || '#FFF',
              },
            ]}
            pointerEvents="none"
          />
          {duration > 0 && trackWidth > 0 && skips && skips.length > 0
            ? skips.map((skip, idx) => {
                const gaps = [];
                if (skip.from > 0 && skip.from < duration) {
                  const leftPos = (skip.from / duration) * trackWidth;
                  gaps.push(
                    <View
                      key={`skip-from-${idx}-${skip.from}`}
                      style={{
                        position: 'absolute',
                        left: Math.max(0, leftPos - 1.5),
                        top: 0,
                        width: 3,
                        height: 4,
                        backgroundColor: '#000000',
                        zIndex: 3,
                      }}
                      pointerEvents="none"
                    />,
                  );
                }
                if (skip.to > 0 && skip.to < duration) {
                  const leftPos = (skip.to / duration) * trackWidth;
                  gaps.push(
                    <View
                      key={`skip-to-${idx}-${skip.to}`}
                      style={{
                        position: 'absolute',
                        left: Math.max(0, leftPos - 1.5),
                        top: 0,
                        width: 3,
                        height: 4,
                        backgroundColor: '#000000',
                        zIndex: 3,
                      }}
                      pointerEvents="none"
                    />,
                  );
                }
                return gaps;
              })
            : null}
        </View>
        {seeking && snapPosition !== null ? (
          <View
            style={[
              styles.snapMarker,
              {
                left: snapPosition - 1,
                top: 12,
                backgroundColor: withAlpha(seekColor || '#FFFFFF', 0.88),
              },
            ]}
            pointerEvents="none"
          />
        ) : null}
        <View
          style={[styles.handle, {left: safePosition, top: 6}]}
          pointerEvents="none">
          <View
            style={[
              styles.circle,
              {
                backgroundColor: seekColor || '#FFF',
                width: 10,
                height: 10,
                borderRadius: 5,
              },
            ]}
            pointerEvents="none"
          />
        </View>
      </View>
      <View style={{minWidth: 42, alignItems: 'flex-end'}} pointerEvents="none">
        <Text style={timestampStyle}>
          {formatTime({
            duration: safeDuration,
            time: safeDuration,
            showDuration: false,
            showHours,
            showTimeRemaining: false,
          })}
        </Text>
      </View>
    </View>
  );
};

import {Catalog, EpisodeLink, Info, Post, Stream, SettingsField} from '../providers/types';
import stremioProviderManager from './StremioProviderManager';
import vegaPluginManager from './VegaPluginManager';

/**
 * Unified content facade used by Home/Search/Info/Player.
 *
 * Stremio add-ons and Vega plugins use separate namespaces and managers.
 * Vega plugin links always use the `vega:` namespace and never enter the
 * Stremio add-on manager.
 */
export class ProviderManager {
  private isVega(providerValue: string) {
    return providerValue.startsWith('vega:');
  }

  private vegaValue(providerValue: string) {
    return providerValue.slice('vega:'.length);
  }

  private assertStremio(providerValue: string) {
    if (!stremioProviderManager.isStremioProvider(providerValue)) {
      throw new Error('This Stremio add-on is not installed or enabled.');
    }
  }

  getCatalog = async ({providerValue}: {providerValue: string}): Promise<Catalog[]> => {
    if (this.isVega(providerValue)) return vegaPluginManager.getCatalog(this.vegaValue(providerValue));
    this.assertStremio(providerValue);
    return stremioProviderManager.getCatalog(providerValue);
  };

  getGenres = async ({providerValue}: {providerValue: string}): Promise<Catalog[]> => {
    if (this.isVega(providerValue)) return vegaPluginManager.getGenres(this.vegaValue(providerValue));
    this.assertStremio(providerValue);
    return [];
  };

  getPosts = async ({
    filter,
    page,
    providerValue,
    signal,
  }: {
    filter: string;
    page: number;
    providerValue: string;
    signal: AbortSignal;
  }): Promise<Post[]> => {
    if (this.isVega(providerValue)) return vegaPluginManager.getPosts(this.vegaValue(providerValue), filter, page, signal);
    this.assertStremio(providerValue);
    return stremioProviderManager.getPosts({filter, page, providerValue, signal});
  };

  getSearchPosts = async ({
    searchQuery,
    page,
    providerValue,
    signal,
    allowGlobalFallback = true,
  }: {
    searchQuery: string;
    page: number;
    providerValue: string;
    signal: AbortSignal;
    allowGlobalFallback?: boolean;
  }): Promise<Post[]> => {
    if (this.isVega(providerValue)) return vegaPluginManager.getSearchPosts(this.vegaValue(providerValue), searchQuery, page, signal);
    this.assertStremio(providerValue);
    return stremioProviderManager.getSearchPosts({
      searchQuery,
      page,
      providerValue,
      signal,
      allowGlobalFallback,
    });
  };

  getMetaData = async ({
    link,
    provider,
    signal,
  }: {
    link: string;
    provider: string;
    signal?: AbortSignal;
  }): Promise<Info> => {
    if (this.isVega(provider)) return vegaPluginManager.getMetaData(this.vegaValue(provider), link, signal);
    this.assertStremio(provider);
    return stremioProviderManager.getMetaData({link, provider, signal});
  };

  getStream = async ({
    link,
    type,
    signal,
    providerValue,
    isDownload,
    forceRefresh = false,
  }: {
    link: string;
    type: string;
    signal?: AbortSignal;
    providerValue: string;
    isDownload?: boolean;
    forceRefresh?: boolean;
  }): Promise<Stream[]> => {
    if (typeof link !== 'string' || !link.trim()) return Promise.resolve([]);
    if (this.isVega(providerValue)) {
      const selectedValue = this.vegaValue(providerValue);
      const plugins = vegaPluginManager.getInstalledSources();
      const ordered = [
        ...plugins.filter(plugin => plugin.value === selectedValue),
        ...plugins.filter(plugin => plugin.value !== selectedValue),
      ];
      const candidates = ordered.length ? ordered : [{value: selectedValue} as any];
      return Promise.allSettled(candidates.map(plugin =>
        vegaPluginManager.getStream(plugin.value, link.trim(), type, signal, isDownload, forceRefresh),
      )).then(results => {
        if (signal?.aborted) { const error = new Error('Aborted'); error.name = 'AbortError'; throw error; }
        const output: Stream[] = [];
        const seen = new Set<string>();
        for (const result of results) {
          if (result.status !== 'fulfilled') continue;
          for (const stream of result.value || []) {
            const key = `${stream.server}|${stream.link}|${stream.quality || ''}`;
            if (!stream.link || seen.has(key)) continue;
            seen.add(key);
            output.push(stream);
          }
        }
        return output;
      });
    }
    this.assertStremio(providerValue);
    return stremioProviderManager.getStream({
      link: link.trim(),
      type,
      signal,
      providerValue,
      isDownload,
      forceRefresh,
    });
  };

  getEpisodes = async ({
    url,
    providerValue,
    signal,
  }: {
    url: string;
    providerValue: string;
    signal?: AbortSignal;
  }): Promise<EpisodeLink[]> => {
    if (this.isVega(providerValue)) {
      try { return await vegaPluginManager.getEpisodes(this.vegaValue(providerValue), url, signal); }
      catch (error) {
        if (error instanceof Error && /does not provide episodes|does not export getEpisodes/.test(error.message)) return [];
        throw error;
      }
    }
    this.assertStremio(providerValue);
    return stremioProviderManager.getEpisodes({url, providerValue, signal});
  };

  getSettingsSchema = async ({
    providerValue,
  }: {
    providerValue: string;
    sourceAuthor?: string;
  }): Promise<SettingsField[]> => {
    if (this.isVega(providerValue)) return vegaPluginManager.getSettingsSchema(this.vegaValue(providerValue));
    return [];
  };

  clearProviderStorage = async (providerValue: string): Promise<void> => {
    if (this.isVega(providerValue)) {
      vegaPluginManager.clearProviderStorage(this.vegaValue(providerValue));
    }
  };
}

export const providerManager = new ProviderManager();

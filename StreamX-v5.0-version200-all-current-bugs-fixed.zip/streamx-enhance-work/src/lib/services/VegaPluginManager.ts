import axios from 'axios';
import {MMKVLoader} from 'react-native-mmkv-storage';
import {mainStorage} from '../storage';
import {providerContext} from '../providers/providerContext';
import type {Catalog, EpisodeLink, Info, Link, Post, SettingsField, Stream} from '../providers/types';
import {isPotentiallyPlayableStream} from '../streamUtils';

export interface VegaPluginSource {
  author: string;
  url: string;
}

export interface VegaPluginManifest {
  display_name: string;
  value: string;
  version: string;
  icon?: string;
  type?: string;
  disabled?: boolean;
  source: VegaPluginSource;
  installed?: boolean;
}

export interface VegaPluginModule {
  value: string;
  sourceAuthor: string;
  version: string;
  modules: Record<string, string | undefined>;
  cachedAt: number;
}

const SOURCE_KEY = 'vegaPlugins.source';
const INSTALLED_KEY = 'vegaPlugins.installed';
const MODULE_KEY = 'vegaPlugins.modules';
const ENABLED_KEY = 'vegaPlugins.enabled';
const settingsStorageKey = (value: string) => `vegaPlugins.settings.${value}`;


const asText = (...values: unknown[]): string => {
  for (const value of values) {
    if (typeof value === 'string' && value.trim()) return value.trim();
    if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  }
  return '';
};

const asRows = (value: unknown): any[] => {
  if (Array.isArray(value)) return value;
  if (value && typeof value === 'object') return Object.values(value as Record<string, unknown>);
  return [];
};

const numericField = (...values: unknown[]): number | undefined => {
  for (const value of values) {
    if (value === undefined || value === null || value === '') continue;
    const parsed = Number(value);
    if (Number.isFinite(parsed) && parsed >= 0) return parsed;
  }
  return undefined;
};

const normalizeVegaEpisodeRows = (
  rows: unknown,
  fallbackSeason?: number,
): EpisodeLink[] => {
  const seen = new Set<string>();
  const episodes: EpisodeLink[] = [];
  for (const raw of asRows(rows)) {
    if (!raw || typeof raw !== 'object') continue;
    const link = asText(raw.link, raw.url, raw.streamUrl, raw.stream_url, raw.externalUrl, raw.episodeUrl, raw.episode_url, raw.href);
    if (!link) continue;
    const season = numericField(raw.season, raw.seasonNumber, raw.season_number, raw.seasonNo, fallbackSeason);
    const episode = numericField(raw.episode, raw.episodeNumber, raw.episode_number, raw.episodeNo, raw.ep);
    const title = asText(raw.title, raw.name, raw.episodeTitle, raw.episode_title, raw.label) ||
      (episode !== undefined ? `Episode ${episode}` : `Episode ${episodes.length + 1}`);
    const item: EpisodeLink = {
      id: raw.id === undefined ? undefined : String(raw.id),
      title,
      link,
      sourceLink: asText(raw.sourceLink, raw.source_url) || undefined,
      description: asText(raw.description, raw.synopsis, raw.overview) || undefined,
      image: asText(raw.image, raw.thumbnail, raw.poster, raw.still) || undefined,
      season,
      episode,
      quickDownload: Boolean(raw.quickDownload ?? raw.quick_download),
      skip: Array.isArray(raw.skip) ? raw.skip : undefined,
    };
    const key = `${item.season ?? ''}|${item.episode ?? ''}|${item.link}`;
    if (seen.has(key)) continue;
    seen.add(key);
    episodes.push(item);
  }
  // Keep provider order for unnumbered items, but put numbered episodes in
  // natural season/episode order so season lists don't jump around.
  return episodes.some(item => item.episode !== undefined)
    ? episodes.sort((a, b) =>
        (a.season ?? fallbackSeason ?? 0) - (b.season ?? fallbackSeason ?? 0) ||
        (a.episode ?? Number.MAX_SAFE_INTEGER) - (b.episode ?? Number.MAX_SAFE_INTEGER),
      )
    : episodes;
};

const normalizeVegaContentType = (value: unknown, hasEpisodeData = false): string => {
  const type = asText(value).toLowerCase().replace(/[\s_-]+/g, ' ');
  if (['channel', 'live', 'live tv', 'livetv'].includes(type)) return 'channel';
  if (['series', 'show', 'shows', 'tv', 'tvshow', 'anime', 'episode'].includes(type) || type.includes('series') || type.includes('tv show')) return 'series';
  return !type && hasEpisodeData ? 'series' : 'movie';
};

export interface VegaPluginTestResult {
  passed: boolean;
  stages: Array<{name: string; passed: boolean; detail: string}>;
}

const normalizeSource = (input: string): VegaPluginSource => {
  let value = input.trim().replace(/\/+$/, '');
  if (!value) throw new Error('Enter a Vega provider username or repository URL.');

  // Vega's official shorthand sources. These are usernames in the Vega UI,
  // but they resolve to the canonical vega-providers repository.
  const shorthand = value.toLowerCase();
  if (shorthand === 'zenda-cross') {
    return {
      author: 'Zenda-Cross',
      url: 'https://raw.githubusercontent.com/Zenda-Cross/vega-providers/main',
    };
  }
  if (shorthand === 'vega-org') {
    return {
      author: 'vega-org',
      url: 'https://raw.githubusercontent.com/Zenda-Cross/vega-providers/main',
    };
  }

  // For any other provider source, Vega supports entering only the GitHub
  // username when the repository is named `vega-providers`.
  if (/^[A-Za-z0-9-]+$/.test(value)) {
    return {
      author: value,
      url: `https://raw.githubusercontent.com/${value}/vega-providers/main`,
    };
  }

  if (/^https?:\/\//i.test(value) && /\/manifest\.json$/i.test(value)) {
    value = value.slice(0, -'/manifest.json'.length);
  }
  if (/^github\.com\//i.test(value)) value = `https://${value}`;

  const parsed = new URL(value);
  if (parsed.hostname.toLowerCase() === 'github.com') {
    const parts = parsed.pathname.split('/').filter(Boolean);
    if (parts.length >= 2) {
      const owner = parts[0];
      const repo = parts[1];
      // GitHub currently redirects the historical vega-org/vega-providers
      // repository to Zenda-Cross/vega-providers. Resolve it explicitly so
      // raw.githubusercontent.com does not depend on redirect handling.
      if (owner.toLowerCase() === 'vega-org' && repo.toLowerCase() === 'vega-providers') {
        return {
          author: 'vega-org',
          url: 'https://raw.githubusercontent.com/Zenda-Cross/vega-providers/main',
        };
      }
      return {
        author: owner,
        url: `https://raw.githubusercontent.com/${owner}/${repo}/main`,
      };
    }
  }
  return {author: parsed.hostname + parsed.pathname, url: value};
};

const getManifestUrl = (source: VegaPluginSource) => `${source.url.replace(/\/+$/, '')}/manifest.json`;


class VegaPluginManager {
  private installed: VegaPluginManifest[] = mainStorage.getArray<VegaPluginManifest>(INSTALLED_KEY) || [];
  private modules: Record<string, VegaPluginModule> = mainStorage.getObject<Record<string, VegaPluginModule>>(MODULE_KEY) || {};
  private enabled: Record<string, boolean> = mainStorage.getObject<Record<string, boolean>>(ENABLED_KEY) || {};

  getSource(): VegaPluginSource | undefined {
    const source = mainStorage.getObject<VegaPluginSource>(SOURCE_KEY);
    return source?.url ? source : undefined;
  }

  setSource(input: string): VegaPluginSource {
    const source = normalizeSource(input);
    mainStorage.setObject(SOURCE_KEY, source);
    return source;
  }

  listInstalled(): VegaPluginManifest[] {
    return this.installed.map(item => ({...item, installed: true, disabled: !this.isEnabled(item.value)}));
  }

  isEnabled(value: string): boolean {
    return this.enabled[value] !== false;
  }

  setEnabled(value: string, enabled: boolean): void {
    this.enabled[value] = enabled;
    mainStorage.setObject(ENABLED_KEY, this.enabled);
  }

  async fetchAvailable(sourceInput?: string, force = true): Promise<VegaPluginManifest[]> {
    const source = sourceInput ? this.setSource(sourceInput) : this.getSource();
    if (!source) throw new Error('Configure a Vega provider repository first.');
    const response = await axios.get(getManifestUrl(source), {timeout: 15000});
    if (!Array.isArray(response.data)) throw new Error('Invalid Vega provider manifest.');
    return response.data
      .filter((item: any) => item && item.value && item.display_name && !item.disabled)
      .map((item: any) => ({
        display_name: String(item.display_name),
        value: String(item.value),
        version: String(item.version || '1.0.0'),
        icon: item.icon ? String(item.icon) : '',
        type: item.type || 'global',
        disabled: Boolean(item.disabled),
        source,
        installed: this.installed.some(p => p.value === item.value && p.source.author === source.author),
      }));
  }

  async install(plugin: VegaPluginManifest): Promise<void> {
    await this.downloadModules(plugin);
    this.installed = [
      ...this.installed.filter(p => !(p.value === plugin.value && p.source.author === plugin.source.author)),
      {...plugin, installed: true, disabled: false},
    ];
    this.enabled[plugin.value] = true;
    this.persist();
  }

  async refresh(plugin: VegaPluginManifest): Promise<void> {
    await this.downloadModules(plugin);
    this.installed = this.installed.map(item =>
      item.value === plugin.value && item.source.author === plugin.source.author
        ? {...plugin, installed: true, disabled: !this.isEnabled(plugin.value)}
        : item,
    );
    this.persist();
  }

  remove(value: string, author?: string): void {
    mainStorage.delete(settingsStorageKey(value));
    this.clearProviderStorage(value);
    this.installed = this.installed.filter(item => !(item.value === value && (!author || item.source.author === author)));
    delete this.modules[this.moduleKey(value, author)];
    delete this.enabled[value];
    this.persist();
  }

  getInstalledSources(): VegaPluginManifest[] {
    return this.listInstalled().filter(item => this.isEnabled(item.value));
  }

  getPlugin(value: string): VegaPluginManifest | undefined {
    return this.installed.find(item => item.value === value);
  }

  private moduleKey(value: string, author?: string) {
    return `${author || this.getPlugin(value)?.source.author || 'unknown'}:${value}`;
  }

  private async downloadModules(plugin: VegaPluginManifest): Promise<void> {
    const base = `${plugin.source.url.replace(/\/+$/, '')}/dist/${encodeURIComponent(plugin.value)}`;
    const names = ['posts', 'meta', 'stream', 'catalog', 'episodes', 'settings'];
    const modules: Record<string, string | undefined> = {};
    await Promise.all(names.map(async name => {
      try {
        const response = await axios.get(`${base}/${name}.js`, {timeout: 20000, responseType: 'text'});
        if (typeof response.data === 'string' && response.data.trim()) modules[name] = response.data;
      } catch (error) {
        if (['posts', 'meta', 'stream', 'catalog'].includes(name)) throw new Error(`Failed to download ${name}.js for ${plugin.display_name}.`);
      }
    }));
    for (const required of ['posts', 'meta', 'stream', 'catalog']) {
      if (!modules[required]) throw new Error(`Vega plugin ${plugin.display_name} is missing ${required}.js.`);
    }
    this.modules[this.moduleKey(plugin.value, plugin.source.author)] = {
      value: plugin.value,
      sourceAuthor: plugin.source.author,
      version: plugin.version,
      modules,
      cachedAt: Date.now(),
    };
    this.persist();
  }

  private getModule(value: string): VegaPluginModule {
    const plugin = this.getPlugin(value);
    if (!plugin) throw new Error(`Vega plugin not installed: ${value}`);
    const module = this.modules[this.moduleKey(value, plugin.source.author)];
    if (!module) throw new Error(`Vega plugin modules are not installed: ${value}`);
    return module;
  }

  private execute(code: string, args: Record<string, unknown> = {}): any {
    const module = {exports: {}} as any;
    const exports = module.exports;
    const require = (name: string) => {
      const normalized = String(name || '').toLowerCase();
      if (normalized === 'axios' || normalized.endsWith('/axios')) return {default: axios, ...axios};
      if (normalized.includes('cheerio')) return {default: providerContext.cheerio, ...providerContext.cheerio};
      if (normalized.includes('providercontext') || normalized.includes('provider-context')) return {providerContext, default: providerContext, ...providerContext};
      if (normalized.includes('crypto')) return {default: providerContext.Crypto, ...providerContext.Crypto};
      return {};
    };
    const fn = new Function('exports', 'module', 'require', 'console', 'Promise', 'Object', `${code}\n//# sourceURL=streamx-vega-plugin.js`);
    fn(exports, module, require, console, Promise, Object);
    return module.exports;
  }

  getSettings(value: string): Record<string, unknown> {
    return mainStorage.getObject<Record<string, unknown>>(settingsStorageKey(value)) || {};
  }

  saveSettings(value: string, settings: Record<string, unknown>): void {
    mainStorage.setObject(settingsStorageKey(value), settings);
  }

  async testProvider(value: string): Promise<VegaPluginTestResult> {
    const stages: VegaPluginTestResult['stages'] = [];
    let catalogs: Catalog[] = [];
    let posts: Post[] = [];
    try {
      catalogs = await this.getCatalog(value);
      stages.push({name: 'Catalog', passed: catalogs.length > 0, detail: `${catalogs.length} catalog(s) found`});
    } catch (error) {
      stages.push({name: 'Catalog', passed: false, detail: error instanceof Error ? error.message : 'Catalog request failed'});
    }
    if (catalogs.length > 0) {
      try {
        posts = await this.getPosts(value, catalogs[0].filter, 1, new AbortController().signal);
        stages.push({name: 'Posts', passed: posts.length > 0, detail: `${posts.length} item(s) returned`});
      } catch (error) {
        stages.push({name: 'Posts', passed: false, detail: error instanceof Error ? error.message : 'Posts request failed'});
      }
    } else {
      stages.push({name: 'Posts', passed: false, detail: 'Skipped because no catalog was available'});
    }
    if (posts[0]?.link) {
      try {
        const info = await this.getMetaData(value, posts[0].link);
        stages.push({name: 'Metadata', passed: Boolean(info.title || info.synopsis || info.linkList?.length), detail: info.title ? `Loaded “${info.title}”` : 'Metadata response received'});
        const sourceLink = (info.linkList || []).flatMap(item => item.directLinks || []).find(item => item?.link)?.link
          || (info.linkList || []).find(item => item?.episodesLink)?.episodesLink;
        if (sourceLink) {
          try {
            const streams = await this.getStream(value, sourceLink, info.type || 'movie');
            stages.push({name: 'Streams', passed: streams.length > 0, detail: `${streams.length} playable stream(s) returned`});
          } catch (error) {
            stages.push({name: 'Streams', passed: false, detail: error instanceof Error ? error.message : 'Stream request failed'});
          }
        } else {
          stages.push({name: 'Streams', passed: false, detail: 'No stream/episode URL was exposed by metadata'});
        }
      } catch (error) {
        stages.push({name: 'Metadata', passed: false, detail: error instanceof Error ? error.message : 'Metadata request failed'});
      }
    } else {
      stages.push({name: 'Metadata', passed: false, detail: 'Skipped because no catalog item was returned'});
      stages.push({name: 'Streams', passed: false, detail: 'Skipped because no catalog item was returned'});
    }
    return {passed: stages.length > 0 && stages.every(stage => stage.passed), stages};
  }

  private async call(value: string, file: string, fnName: string, args: Record<string, unknown>): Promise<any> {
    const module = this.getModule(value);
    const code = module.modules[file];
    if (!code) throw new Error(`Vega plugin ${value} does not provide ${file}.js.`);
    const provider = this.getPlugin(value)!;
    const context = {
      ...providerContext,
      kvStore: this.createKvStore(value),
      settings: this.getSettings(value),
    };
    const moduleExports = this.execute(code, args);
    const fn = moduleExports[fnName];
    if (typeof fn !== 'function') throw new Error(`Vega plugin ${value} does not export ${fnName}.`);
    const signal = args.signal as AbortSignal | undefined;
    if (signal?.aborted) { const error = new Error('Aborted'); error.name = 'AbortError'; throw error; }
    let timeoutId: ReturnType<typeof setTimeout> | undefined;
    const timeoutMs = file === 'stream' ? 18000 : 12000;
    const timeoutPromise = new Promise<never>((_, reject) => {
      timeoutId = setTimeout(() => reject(new Error(`Vega plugin ${value} ${file} request timed out.`)), timeoutMs);
    });
    let abortListener: (() => void) | undefined;
    const pluginCall = Promise.resolve().then(() =>
      fn({...args, settings: this.getSettings(value), providerContext: context, providerValue: value}),
    );
    try {
      if (!signal) {
        return await Promise.race([pluginCall, timeoutPromise]);
      }
      const abortPromise = new Promise<never>((_, reject) => {
        abortListener = () => {
          const error = new Error('Aborted');
          error.name = 'AbortError';
          reject(error);
        };
        signal.addEventListener('abort', abortListener, {once: true});
        if (signal.aborted) abortListener();
      });
      return await Promise.race([pluginCall, timeoutPromise, abortPromise]);
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
      if (signal && abortListener) signal.removeEventListener('abort', abortListener);
    }
  }

  private createKvStore(value: string) {
    const instance = `vega-plugin-${value.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    const kv = new MMKVLoader().withInstanceID(instance).initialize();
    const keysKey = '__streamx_keys__';
    const readKeys = (): string[] => {
      try { return JSON.parse(kv.getString(keysKey) || '[]'); } catch { return []; }
    };
    const writeKey = (key: string) => {
      const keys = readKeys();
      if (!keys.includes(key)) kv.setString(keysKey, JSON.stringify([...keys, key]));
    };
    return {
      get: async <T = unknown>(key: string) => {
        const raw = kv.getString(key);
        if (raw == null) return undefined as T | undefined;
        try { return JSON.parse(raw) as T; } catch { return raw as T; }
      },
      set: async (key: string, val: unknown) => { writeKey(key); kv.setString(key, JSON.stringify(val)); },
      delete: async (key: string) => { const existed = kv.getString(key) != null; kv.removeItem(key); return existed; },
      keys: async () => readKeys().filter(key => key !== keysKey),
      clear: async () => kv.clearStore(),
    };
  }

  async getCatalog(value: string): Promise<Catalog[]> {
    const mod = this.getModule(value);
    const code = mod.modules.catalog;
    if (!code) return [];
    const exports = this.execute(code);
    return Array.isArray(exports.catalog) ? exports.catalog : [];
  }

  async getGenres(value: string): Promise<Catalog[]> {
    const mod = this.getModule(value);
    const code = mod.modules.catalog;
    if (!code) return [];
    const exports = this.execute(code);
    return Array.isArray(exports.genres) ? exports.genres : [];
  }

  getPosts(value: string, filter: string, page: number, signal: AbortSignal): Promise<Post[]> {
    return this.call(value, 'posts', 'getPosts', {filter, page, signal});
  }

  getSearchPosts(value: string, searchQuery: string, page: number, signal: AbortSignal): Promise<Post[]> {
    return this.call(value, 'posts', 'getSearchPosts', {searchQuery, page, signal});
  }

  async getMetaData(value: string, link: string, signal?: AbortSignal): Promise<Info> {
    const response = await this.call(value, 'meta', 'getMeta', {link, signal});
    if (!response || typeof response !== 'object') {
      throw new Error('Vega plugin returned invalid metadata.');
    }
    const raw = response.meta && typeof response.meta === 'object'
      ? {...response, ...response.meta}
      : response;
    const hasEpisodeData = [raw.seasons, raw.episodes, raw.episodeList, raw.episode_list].some(candidate => asRows(candidate).length > 0);
    const sourceType = normalizeVegaContentType(raw.type || raw.contentType || raw.content_type || raw.mediaType, hasEpisodeData);
    const episodeCandidates = [raw.episodes, raw.episodeList, raw.episode_list, raw.items];
    const topLevelEpisodes = normalizeVegaEpisodeRows(
      episodeCandidates.find(candidate => asRows(candidate).length > 0),
    );
    const linkCandidates = [raw.linkList, raw.links, raw.sources, raw.sourceList];
    const rawLinks = linkCandidates.map(asRows).find(rows => rows.length > 0) || [];
    const explicitSeasonRows = asRows(raw.seasons);
    const knownSeasonNumbers = new Set<number>(rawLinks.flatMap((item: any) => {
      if (!item || typeof item !== 'object') return [];
      const direct = numericField(item.season, item.seasonNumber, item.season_number, item.seasonNo);
      const title = asText(item.title, item.name, item.label).match(/(?:season\s*|^s)\s*(\d+)/i);
      const parsed = direct ?? (title ? Number(title[1]) : undefined);
      return parsed !== undefined && Number.isFinite(parsed) ? [parsed] : [];
    }));
    for (const seasonRow of explicitSeasonRows) {
      if (!seasonRow || typeof seasonRow !== 'object') {
        rawLinks.push({title: String(seasonRow), season: numericField(seasonRow)});
        continue;
      }
      const seasonNumber = numericField(seasonRow.season, seasonRow.seasonNumber, seasonRow.season_number, seasonRow.seasonNo);
      const titleMatch = asText(seasonRow.title, seasonRow.name, seasonRow.label).match(/(?:season\s*|^s)\s*(\d+)/i);
      const season = seasonNumber ?? (titleMatch ? Number(titleMatch[1]) : undefined);
      if (season === undefined || !knownSeasonNumbers.has(season)) {
        rawLinks.push(seasonRow);
        if (season !== undefined) knownSeasonNumbers.add(season);
      }
    }
    const normalizedLinks: Link[] = rawLinks.flatMap((item: any, index: number) => {
      if (!item || typeof item !== 'object') return [];
      const season = numericField(item.season, item.seasonNumber, item.season_number, item.seasonNo);
      const title = asText(item.title, item.name, item.label) ||
        (sourceType === 'series' ? `Season ${season ?? index + 1}` : 'Play');
      const inlineRows = item.episodes || item.episodeList || item.episode_list || item.items || item.episodeItems;
      const normalizedInlineEpisodes = normalizeVegaEpisodeRows(inlineRows, season);
      const seasonTitleNumber = title.match(/(?:season\s*|^s)\s*(\d+)/i);
      const normalizedSeason = season ?? (seasonTitleNumber ? Number(seasonTitleNumber[1]) : undefined);
      const directRows = asRows(item.directLinks || item.direct_links || item.streams || item.streamLinks || item.stream_links);
      const directLinks = directRows.flatMap((entry: any) => {
        if (!entry || typeof entry !== 'object') return [];
        const directLink = asText(entry.link, entry.url, entry.externalUrl, entry.external_url, entry.fileUrl, entry.file_url, entry.href);
        if (!directLink) return [];
        return [{
          ...entry,
          title: asText(entry.title, entry.name, entry.label) || title,
          link: directLink,
          type: entry.type || item.type || sourceType,
        }];
      });
      const explicitUrl = asText(item.link, item.url, item.externalUrl, item.external_url, item.href);
      // A season object with inline episodes describes a season, not a direct video URL.
      const isSeasonWithEpisodes = sourceType === 'series' && normalizedInlineEpisodes.length > 0;
      const normalizedDirectLinks = directLinks.length
        ? directLinks
        : explicitUrl && !isSeasonWithEpisodes
          ? [{title, link: explicitUrl, type: item.type || sourceType}]
          : [];
      const episodesLink = asText(item.episodesLink, item.episodesUrl, item.episodeUrl, item.episodes_url, item.episode_url);
      const matchedEpisodes = normalizedSeason === undefined
        ? []
        : topLevelEpisodes.filter(episode => episode.season === normalizedSeason);
      const episodes = normalizedInlineEpisodes.length > 0 ? normalizedInlineEpisodes : matchedEpisodes;
      const normalized: Link = {
        ...item,
        title,
        season: normalizedSeason,
        directLinks: normalizedDirectLinks.length > 0 ? normalizedDirectLinks : undefined,
        episodesLink: episodesLink || undefined,
        episodes: episodes.length > 0 ? episodes : undefined,
        quickDownload: Boolean(item.quickDownload ?? item.quick_download),
      };
      // Don't show empty placeholders that cannot expose an episode endpoint or play link.
      if (!normalized.directLinks?.length && !normalized.episodesLink && !normalized.episodes?.length && sourceType !== 'series') return [];
      return [normalized];
    });

    if (sourceType === 'series' && topLevelEpisodes.length > 0) {
      const grouped = new Map<number, EpisodeLink[]>();
      for (const episode of topLevelEpisodes) {
        const season = episode.season ?? 1;
        const group = grouped.get(season) || [];
        group.push({...episode, season});
        grouped.set(season, group);
      }
      for (const [season, episodes] of grouped) {
        const exists = normalizedLinks.find(item => item.season === season);
        if (exists) {
          if (!exists.episodes?.length) exists.episodes = episodes;
        } else {
          normalizedLinks.push({title: season === 0 ? 'Specials' : `Season ${season}`, season, episodes});
        }
      }
    }

    if (normalizedLinks.length === 0) {
      const directUrl = asText(raw.playUrl, raw.play_url, raw.videoUrl, raw.video_url, raw.externalUrl, raw.external_url, raw.fileUrl, raw.file_url);
      if (directUrl) {
        normalizedLinks.push({
          title: 'Play',
          directLinks: [{title: 'Play', link: directUrl, type: sourceType}],
        });
      }
    }

    const genreRows = Array.isArray(raw.genres) ? raw.genres : asText(raw.genres).split(/[,|/]/);
    const genres = genreRows.map((genre: any) =>
      typeof genre === 'string' ? genre.trim() : asText(genre?.name, genre?.title, genre?.value),
    ).filter(Boolean);
    const image = asText(raw.image, raw.background, raw.backdrop, raw.poster, raw.thumbnail);
    const poster = asText(raw.poster, raw.image, raw.thumbnail);
    const background = asText(raw.background, raw.backdrop, raw.image, raw.poster);
    return {
      ...raw,
      title: asText(raw.title, raw.name, raw.label) || 'Unknown title',
      synopsis: asText(raw.synopsis, raw.description, raw.overview, raw.plot),
      image,
      poster,
      background,
      logo: asText(raw.logo, raw.logoUrl, raw.logo_url) || undefined,
      type: sourceType,
      imdbId: asText(raw.imdbId, raw.imdb_id, raw.imdb, /^tt\d+$/.test(asText(raw.id)) ? raw.id : '') || undefined,
      tmdbId: asText(raw.tmdbId, raw.tmdb_id) || undefined,
      rating: asText(raw.rating, raw.imdbRating, raw.imdb_rating, raw.vote_average) || undefined,
      imdbRating: raw.imdbRating ?? raw.imdb_rating ?? raw.rating ?? undefined,
      year: raw.year ?? raw.releaseYear ?? raw.release_year ?? undefined,
      runtime: asText(raw.runtime, raw.duration, raw.durationText) || undefined,
      genres,
      certification: asText(raw.certification, raw.contentRating, raw.content_rating, raw.rated) || undefined,
      tags: Array.isArray(raw.tags) ? raw.tags : undefined,
      trailerUrl: asText(raw.trailerUrl, raw.trailer_url, raw.trailer) || undefined,
      linkList: normalizedLinks,
    } as Info;
  }

  async getStream(value: string, link: string, type: string, signal?: AbortSignal, isDownload?: boolean, _forceRefresh = false): Promise<Stream[]> {
    if (signal?.aborted) { const error = new Error('Aborted'); error.name = 'AbortError'; throw error; }
    if (typeof link !== 'string' || !link.trim()) return [];
    const result = await this.call(value, 'stream', 'getStream', {link: link.trim(), type, signal, isDownload, forceRefresh: _forceRefresh});
    if (signal?.aborted) { const error = new Error('Aborted'); error.name = 'AbortError'; throw error; }
    const candidates = Array.isArray(result) ? result : Array.isArray(result?.streams) ? result.streams : Array.isArray(result?.results) ? result.results : Array.isArray(result?.links) ? result.links : Array.isArray(result?.sources) ? result.sources : Array.isArray(result?.data?.streams) ? result.data.streams : (result && typeof result === 'object' ? [result] : []);
    const plugin = this.getPlugin(value);
    const output: Stream[] = [];
    const seen = new Set<string>();
    for (const candidate of candidates) {
      if (!candidate || typeof candidate !== 'object') continue;
      const streamLink = String(candidate.link || candidate.url || candidate.streamUrl || candidate.stream_url || candidate.externalUrl || candidate.external_url || candidate.fileUrl || candidate.file_url || candidate.href || '').trim();
      const normalized = {
        ...candidate,
        server: String(candidate.server || candidate.provider || plugin?.display_name || value),
        link: streamLink,
        type: String(candidate.type || candidate.mimeType || 'video/mp4'),
      } as Stream;
      if (!isPotentiallyPlayableStream(normalized)) continue;
      const key = `${normalized.server}|${normalized.link}|${normalized.quality || ''}`;
      if (seen.has(key)) continue;
      seen.add(key);
      output.push(normalized);
    }
    return output;
  }

  async getEpisodes(value: string, url: string, signal?: AbortSignal): Promise<EpisodeLink[]> {
    const result = await this.call(value, 'episodes', 'getEpisodes', {url, signal});
    if (signal?.aborted) {
      const error = new Error('Aborted');
      error.name = 'AbortError';
      throw error;
    }
    const rows = Array.isArray(result)
      ? result
      : Array.isArray(result?.episodes) ? result.episodes
      : Array.isArray(result?.episodeList) ? result.episodeList
      : Array.isArray(result?.episode_list) ? result.episode_list
      : Array.isArray(result?.items) ? result.items
      : Array.isArray(result?.results) ? result.results
      : Array.isArray(result?.data?.episodes) ? result.data.episodes
      : Array.isArray(result?.data) ? result.data
      : [];
    return normalizeVegaEpisodeRows(rows);
  }

  async getSettingsSchema(value: string): Promise<SettingsField[]> {
    const module = this.getModule(value);
    if (!module.modules.settings) return [];
    return this.call(value, 'settings', 'getSettingsSchema', {});
  }

  clearProviderStorage(value: string): void {
    mainStorage.delete(settingsStorageKey(value));
    const instance = `vega-plugin-${value.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    try { new MMKVLoader().withInstanceID(instance).initialize().clearStore(); } catch {}
  }

  private persist() {
    mainStorage.setArray(INSTALLED_KEY, this.installed);
    mainStorage.setObject(MODULE_KEY, this.modules);
    mainStorage.setObject(ENABLED_KEY, this.enabled);
  }
}

export const vegaPluginManager = new VegaPluginManager();
export default vegaPluginManager;

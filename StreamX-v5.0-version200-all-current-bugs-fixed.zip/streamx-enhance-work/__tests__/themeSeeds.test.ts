import {M3_SEEDS, readableOnColor} from '../src/theme/seeds';

describe('StreamX appearance seeds', () => {
  it('offers ten distinct accent colors', () => {
    expect(M3_SEEDS).toHaveLength(10);
    expect(new Set(M3_SEEDS.map(seed => seed.color.toLowerCase())).size).toBe(10);
  });

  it('chooses dark text on light accents and white text on dark accents', () => {
    expect(readableOnColor('#FFFFFF')).toBe('#000000');
    expect(readableOnColor('#E7E7E7')).toBe('#000000');
    expect(readableOnColor('#000000')).toBe('#FFFFFF');
    expect(readableOnColor('#303030')).toBe('#FFFFFF');
  });
});

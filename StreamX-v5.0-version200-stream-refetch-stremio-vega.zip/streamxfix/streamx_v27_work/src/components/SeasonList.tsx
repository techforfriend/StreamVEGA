import React, {
  useState,
  useMemo,
  useCallback,
  useEffect,
  useRef,
} from 'react';
import {
  View,
  TouchableOpacity,
  ToastAndroid,
  BackHandler,
  FlatList,
  ActivityIndicator,
  Image,
  ScrollView,
  TextInput,
  Modal,
} from 'react-native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {useNavigation} from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import Feather from '@expo/vector-icons/Feather';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
  cancelAnimation,
} from 'react-native-reanimated';
import * as IntentLauncher from 'expo-intent-launcher';
import RNReactNativeHapticFeedback from 'react-native-haptic-feedback';
import {EpisodeLink, Link, Stream} from '../lib/providers/types';
import {RootStackParamList} from '../App';
import Downloader from './Downloader';
import {cacheStorage, mainStorage, settingsStorage} from '../lib/storage';
import {ifExists} from '../lib/file/ifExists';
import {useEpisodes, useStreamData} from '../lib/hooks/useEpisodes';
import SkeletonLoader from './Skeleton';
import DropdownField from './ui/DropdownField';
import {
  createDesktopCompatibleFileName,
  createDirectDownloadId,
  createSeriesDownloadId,
} from '../lib/downloadId';
import useDownloadsStore from '../lib/zustand/downloadsStore';
import {useM3Colors} from '../theme/M3PaletteContext';
import MaterialDialogSurface from './ui/MaterialDialogSurface';
import LoadingIndicator from './ui/LoadingIndicator';
import {LEGACY_TERTIARY_BACKGROUND} from '../theme/seeds';
import Text from './ui/Text';
import EpisodeRowContent, {getValidImageUri} from './EpisodeRowContent';
import {setSyncedEpisodeProgress} from '../lib/sync/syncService';
import {chooseBestStream, getStreamQualityCategories, isPotentiallyPlayableStream} from '../lib/streamUtils';

const CONTROL_TEXT = '#F5F0EF';
const CONTROL_TEXT_MUTED = '#D4CBC9';
// const CONTROL_OUTLINE = '#494240';

const QUALITY_FILTERS = ['All', '4K', '2K', '1080p', '720p', '480p', 'HDR'] as const;
type QualityFilter = (typeof QUALITY_FILTERS)[number];

const getStreamAddonName = (stream: Stream): string =>
  String(stream.server || 'Unknown add-on').trim() || 'Unknown add-on';

const isPromotionalStreamText = (value: unknown): boolean => {
  const text = String(value ?? '').replace(/[._-]+/g, ' ').trim().toLowerCase();
  return /donation\s*needed|join\s+the\s+discord(?:\s+server)?|i\s+support\s+the\s+project/.test(text);
};

const isPromotionalStream = (stream: any): boolean =>
  isPromotionalStreamText(stream?.title) ||
  isPromotionalStreamText(stream?.name) ||
  isPromotionalStreamText(stream?.tag) ||
  isPromotionalStreamText(stream?.server) ||
  isPromotionalStreamText(stream?.description);

const formatStreamFileSize = (stream: Stream): string | undefined => {
  const raw =
    stream?.size ??
    stream?.fileSize ??
    (stream as any)?.filesize ??
    (stream as any)?.behaviorHints?.videoSize ??
    (stream as any)?.behaviorHints?.video_size ??
    (stream as any)?.behaviorHints?.size;
  if (raw === undefined || raw === null || raw === '') return undefined;
  if (typeof raw === 'string') {
    const trimmed = raw.trim();
    if (!trimmed) return undefined;
    if (/^\d+(?:\.\d+)?\s*(?:b|kb|mb|gb|tb)$/i.test(trimmed)) return trimmed;
    const numeric = Number(trimmed);
    if (!Number.isFinite(numeric) || numeric <= 0) return trimmed;
    return formatStreamFileSize({server: stream.server, link: stream.link, type: stream.type, size: numeric});
  }
  const bytes = Number(raw);
  if (!Number.isFinite(bytes) || bytes <= 0) return undefined;
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let value = bytes;
  let unitIndex = 0;
  while (value >= 1024 && unitIndex < units.length - 1) {
    value /= 1024;
    unitIndex += 1;
  }
  const digits = unitIndex === 0 ? 0 : value >= 10 ? 1 : 2;
  return `${value.toFixed(digits)} ${units[unitIndex]}`;
};

interface SeasonListProps {
  LinkList: Link[];
  poster: {
    logo?: string;
    poster?: string;
    background?: string;
  };
  type: string;
  metaTitle: string;
  providerValue: string;
  refreshing?: boolean;
  routeParams: Readonly<{
    link: string;
    provider?: string;
    poster?: string;
  }>;
  imdbId?: string;
  synopsis?: string;
  refreshVersion?: number;
  quickDownload?: boolean;
}

interface PlayHandlerProps {
  linkIndex: number;
  type: string;
  primaryTitle: string;
  seasonTitle: string;
  episodeData: EpisodeLink[] | Link['directLinks'];
  selectedStream?: Stream;
}

interface StickyMenuState {
  active: boolean;
  link?: string;
  type?: string;
}

interface EpisodeDetailsState {
  title: string;
  description: string;
  image?: string;
}

const getSeasonLabel = (item: Link, index: number, type: string): string => {
  const raw = String(item?.title || '').trim();
  if (type !== 'series') return raw || `Option ${index + 1}`;
  const seasonMatch = raw.match(/(?:season\s*|^s)\s*(\d+)/i);
  if (seasonMatch) return `Season ${seasonMatch[1]}`;
  if (/^(episodes|default|all)$/i.test(raw) || !raw) return `Season ${index + 1}`;
  return raw;
};

const getSeasonNumber = (item?: Link | EpisodeLink | null): number | undefined => {
  if (item && typeof (item as Link).season === 'number') {
    return (item as Link).season;
  }
  const raw = String(item?.title || '').trim();
  const match = raw.match(/(?:season\s*|^s)\s*(\d+)/i);
  if (!match) return undefined;
  const value = Number(match[1]);
  return Number.isFinite(value) ? value : undefined;
};

const getStreamQualityRank = (stream: Stream): number => {
  const categories = getStreamQualityCategories(stream);
  if (categories.includes('4K')) return 4000;
  if (categories.includes('2K')) return 2000;
  if (categories.includes('1080p')) return 1080;
  if (categories.includes('720p')) return 720;
  if (categories.includes('480p')) return 480;
  if (categories.includes('360p')) return 360;
  return 0;
};

const groupStreamsByAddon = (streams: Stream[]): Array<[string, Stream[]]> => {
  const groups = new Map<string, Stream[]>();
  for (const stream of streams) {
    const addonName = String(stream.server || 'Unknown add-on').trim() || 'Unknown add-on';
    const group = groups.get(addonName);
    if (group) group.push(stream);
    else groups.set(addonName, [stream]);
  }
  return Array.from(groups.entries()).sort(([a], [b]) => a.localeCompare(b));
};

const getOriginalLinkIndex = <T extends {link: string}>(
  links: T[] | undefined,
  link: string,
  fallbackIndex: number,
): number => {
  const originalIndex = links?.findIndex(item => item.link === link) ?? -1;
  return originalIndex >= 0 ? originalIndex : fallbackIndex;
};

const SeasonListContent: React.FC<SeasonListProps> = ({
  LinkList,
  poster,
  type,
  metaTitle,
  providerValue,
  refreshing,
  routeParams,
  imdbId,
  synopsis,
  refreshVersion,
  quickDownload,
}) => {
  const colors = useM3Colors();
  const primary = colors.primary;
  const navigation =
    useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const {fetchStreams} = useStreamData();
  const streamFetchControllerRef = useRef<AbortController | null>(null);
  const [autoStreams, setAutoStreams] = useState<Stream[]>([]);
  const [selectedAutoStream, setSelectedAutoStream] = useState<Stream | null>(null);
  const [autoQualitySelected, setAutoQualitySelected] = useState(true);
  const [autoStreamLoading, setAutoStreamLoading] = useState(false);
  const [showMovieStreamModal, setShowMovieStreamModal] = useState(false);
  const [movieQualityFilter, setMovieQualityFilter] = useState<QualityFilter>('All');
  const [movieAddonFilter, setMovieAddonFilter] = useState<string>('All');
  const [episodeQualityFilter, setEpisodeQualityFilter] = useState<QualityFilter>('All');
  const [episodeAddonFilter, setEpisodeAddonFilter] = useState<string>('All');
  const detailsPressRef = useRef<string | null>(null);
  const episodeSortOrderKey = `episodeSortOrder:${providerValue}:${routeParams.link}`;
  const lastStreamSelectionKey = `lastStream:${providerValue}:${routeParams.link}`;

  // Memoized initial active season
  const [activeSeason, setActiveSeason] = useState<Link>(() => {
    if (!LinkList || LinkList.length === 0) {
      return {} as Link;
    }

    const cached = cacheStorage.getString(
      `ActiveSeason${metaTitle + providerValue}`,
    );

    if (cached) {
      try {
        const parsedSeason = JSON.parse(cached);
        // Verify the cached season still exists in LinkList
        const seasonExists = LinkList.find(
          link => link.title === parsedSeason.title,
        );
        if (seasonExists) {
          return parsedSeason;
        }
      } catch (error) {
        console.warn('Failed to parse cached season:', error);
      }
    }

    return LinkList[0];
  });

  // React Query for episodes
  const {
    data: episodeList = [],
    isLoading: episodeLoading,
    error: episodeError,
    refetch: refetchEpisodes,
  } = useEpisodes(
    activeSeason?.episodesLink,
    providerValue,
    activeSeason?.episodesLink ? true : false,
  );

  // When older/cached metadata provides a single "Episodes" link, derive
  // real season choices from the Stremio episode metadata once it arrives.
  const seasonOptions = useMemo<Link[]>(() => {
    if (type !== 'series') return LinkList;

    const seasonNumbers = Array.from(
      new Set(
        episodeList
          .map(episode => Number(episode?.season))
          .filter(value => Number.isFinite(value) && value >= 0),
      ),
    ).sort((a, b) => Number(a) - Number(b));

    if (seasonNumbers.length === 0) return LinkList;

    const existingBySeason = new Map<number, Link>();
    for (const link of LinkList) {
      const season = getSeasonNumber(link);
      if (season !== undefined && !existingBySeason.has(season)) {
        existingBySeason.set(season, link);
      }
    }

    const fallbackLink = LinkList[0];
    if (!fallbackLink) return LinkList;

    return seasonNumbers.map(season => {
      const existing = existingBySeason.get(season);
      return (existing || {
        ...fallbackLink,
        title: season === 0 ? 'Specials' : `Season ${season}`,
        season,
      });
    });
  }, [LinkList, episodeList, type]);


  useEffect(() => {
    if (type !== 'series' || seasonOptions.length === 0 || episodeList.length === 0) return;
    const activeNumber = getSeasonNumber(activeSeason);
    if (activeNumber !== undefined && seasonOptions.some(item => getSeasonNumber(item) === activeNumber)) {
      return;
    }
    const next = seasonOptions[0];
    if (!next) return;
    setActiveSeason(next);
    try {
      cacheStorage.setString(
        `ActiveSeason${metaTitle + providerValue}`,
        JSON.stringify(next),
      );
    } catch {}
  }, [activeSeason, episodeList.length, metaTitle, providerValue, seasonOptions, type]);

  useEffect(() => {
    if (refreshing && activeSeason?.episodesLink) {
      refetchEpisodes();
    }
  }, [activeSeason?.episodesLink, refetchEpisodes, refreshVersion, refreshing]);

  // UI state
  const [vlcLoading, setVlcLoading] = useState<boolean>(false);
  const [stickyMenu, setStickyMenu] = useState<StickyMenuState>({
    active: false,
  });

  // Search and sorting state - memoized initial values
  const [searchText, setSearchText] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>(() =>
    mainStorage.getString(episodeSortOrderKey) === 'desc' ? 'desc' : 'asc',
  );

  useEffect(() => {
    setSortOrder(
      mainStorage.getString(episodeSortOrderKey) === 'desc' ? 'desc' : 'asc',
    );
  }, [episodeSortOrderKey]);

  // External player state
  const [showServerModal, setShowServerModal] = useState<boolean>(false);
  const [externalPlayerStreams, setExternalPlayerStreams] = useState<any[]>([]);
  const [isLoadingStreams, setIsLoadingStreams] = useState<boolean>(false);
  const [episodeStreamSelection, setEpisodeStreamSelection] = useState<EpisodeLink | null>(null);
  const [episodeSelectionStreams, setEpisodeSelectionStreams] = useState<Stream[]>([]);
  const [episodeSelectionLoading, setEpisodeSelectionLoading] = useState(false);
  const [episodeSelectionError, setEpisodeSelectionError] = useState<string | null>(null);
  const episodeSelectionControllerRef = useRef<AbortController | null>(null);
  const [episodeDetails, setEpisodeDetails] =
    useState<EpisodeDetailsState | null>(null);
  const [episodeDetailsImageFailed, setEpisodeDetailsImageFailed] =
    useState(false);

  const isDirectStreamPage = Boolean(
    activeSeason?.directLinks &&
      activeSeason.directLinks.length > 0 &&
      !activeSeason?.episodesLink,
  );

  const formatStreamLabel = useCallback((stream: Stream) => {
    const quality = stream.quality
      ? /p$/i.test(stream.quality)
        ? stream.quality
        : `${stream.quality}p`
      : '';
    const size = formatStreamFileSize(stream);
    const parts = [stream.server, quality, size, stream.tag].filter(Boolean);
    return parts.join(' • ') || 'Stream';
  }, []);

  // Fetch all movie/direct-link streams through the currently enabled providers.
  // A force-refresh bypasses the stream cache so the in-dialog Refresh button
  // can recover when the initial fetch returned no links.
  const fetchMovieStreams = useCallback(async (forceRefresh: boolean = false) => {
    const links = (activeSeason?.directLinks || [])
      .filter(item => item?.link);
    if (links.length === 0) {
      setAutoStreams([]);
      setSelectedAutoStream(null);
      setAutoStreamLoading(false);
      return;
    }

    streamFetchControllerRef.current?.abort();
    const controller = new AbortController();
    streamFetchControllerRef.current = controller;
    let mounted = true;
    setAutoStreamLoading(true);
    setAutoStreams([]);

    try {
      const results = await Promise.allSettled(
        links.map(item =>
          fetchStreams(
            item.link,
            item.type || type,
            providerValue,
            controller.signal,
            forceRefresh,
          ),
        ),
      );
      if (!mounted || controller.signal.aborted) return;

      const merged: Stream[] = [];
      const seen = new Set<string>();
      const excludedQualities = settingsStorage.getExcludedQualities() || [];
      for (const result of results) {
        if (result.status !== 'fulfilled') continue;
        for (const stream of result.value || []) {
          if (!isPotentiallyPlayableStream(stream)) continue;
          if (isPromotionalStream(stream)) continue;
          if (excludedQualities.some(quality => getStreamQualityCategories(stream).includes(quality))) continue;
          if (!stream?.link || seen.has(stream.link)) continue;
          seen.add(stream.link);
          merged.push(stream);
        }
      }

      setAutoStreams(merged);
      let remembered: Stream | null = null;
      try {
        const raw = cacheStorage.getString(lastStreamSelectionKey);
        if (raw) {
          const parsed = JSON.parse(raw) as Stream;
          remembered = merged.find(item => item.link === parsed?.link) || null;
        }
      } catch {}
      const best = chooseBestStream(merged);
      setSelectedAutoStream(remembered || best);
      setAutoQualitySelected(!remembered);
    } finally {
      if (mounted) setAutoStreamLoading(false);
      if (streamFetchControllerRef.current === controller) {
        streamFetchControllerRef.current = null;
      }
    }

  }, [activeSeason?.directLinks, fetchStreams, lastStreamSelectionKey, providerValue, type]);

  // Auto-fetch movie/direct-link streams as soon as the details page opens.
  useEffect(() => {
    if (!isDirectStreamPage) {
      setAutoStreams([]);
      setSelectedAutoStream(null);
      setAutoStreamLoading(false);
      return;
    }
    void fetchMovieStreams(false);
    return () => {
      streamFetchControllerRef.current?.abort();
    };
  }, [fetchMovieStreams, isDirectStreamPage]);

  const cancelStreamFetch = useCallback(() => {
    streamFetchControllerRef.current?.abort();
    streamFetchControllerRef.current = null;
  }, []);

  useEffect(() => {
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      if (episodeDetails) {
        setEpisodeDetails(null);
        return true;
      }
      if (showServerModal) {
        setShowServerModal(false);
        return true;
      }
      if (vlcLoading || autoStreamLoading || episodeSelectionLoading) {
        cancelStreamFetch();
        episodeSelectionControllerRef.current?.abort();
        setEpisodeSelectionLoading(false);
        setEpisodeStreamSelection(null);
        setVlcLoading(false);
        setIsLoadingStreams(false);
        setAutoStreamLoading(false);
        navigation.goBack();
        return true;
      }
      return false;
    });
    return () => subscription.remove();
  }, [autoStreamLoading, cancelStreamFetch, episodeDetails, episodeSelectionLoading, navigation, showServerModal, vlcLoading]);

  useEffect(() => {
    setEpisodeDetailsImageFailed(false);
  }, [episodeDetails?.image]);

  useEffect(() => {
    const unsubscribe = navigation.addListener('beforeRemove', () => {
      episodeSelectionControllerRef.current?.abort();
      streamFetchControllerRef.current?.abort();
    });
    return unsubscribe;
  }, [navigation]);

  // VLC loading animation - using shared value so it reacts to vlcLoading state
  const vlcRotation = useSharedValue(0);

  useEffect(() => {
    if (vlcLoading) {
      vlcRotation.value = 0;
      vlcRotation.value = withRepeat(
        withTiming(360, {duration: 800}),
        -1,
        false,
      );
    } else {
      cancelAnimation(vlcRotation);
      vlcRotation.value = 0;
    }
  }, [vlcLoading]);

  const vlcLoadingAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{rotate: `${vlcRotation.value}deg`}],
  }));

  // Memoized filtering and sorting logic for episodes
  const filteredAndSortedEpisodes = useMemo(() => {
    if (!episodeList || !Array.isArray(episodeList)) {
      return [];
    }

    let episodes = episodeList.filter(
      episode => episode && episode.title && episode.link,
    );

    if (type === 'series') {
      const selectedSeason = getSeasonNumber(activeSeason);
      const availableSeasonNumbers = new Set(
        episodeList
          .map(episode => Number(episode?.season))
          .filter(value => Number.isFinite(value) && value >= 0),
      );
      if (selectedSeason !== undefined && availableSeasonNumbers.size > 0) {
        episodes = episodes.filter(episode => Number(episode.season) === selectedSeason);
      }
    }

    // Apply search filter
    if (searchText.trim()) {
      episodes = episodes.filter(episode =>
        episode?.title?.toLowerCase().includes(searchText.toLowerCase()),
      );
    }

    // Apply sorting
    if (sortOrder === 'desc') {
      episodes = [...episodes].reverse();
    }

    return episodes;
  }, [activeSeason, episodeList, searchText, sortOrder, type]);

  // Memoized direct links processing
  const filteredAndSortedDirectLinks = useMemo(() => {
    if (
      !activeSeason?.directLinks ||
      !Array.isArray(activeSeason.directLinks)
    ) {
      return [];
    }

    let links = activeSeason.directLinks.filter(
      link => link && link.title && link.link && !isPromotionalStream(link),
    );

    // Apply search filter
    if (searchText.trim()) {
      links = links.filter(link =>
        link?.title?.toLowerCase().includes(searchText.toLowerCase()),
      );
    }

    // Apply sorting
    if (sortOrder === 'desc') {
      links = [...links].reverse();
    }

    return links;
  }, [activeSeason?.directLinks, searchText, sortOrder]);

  // Memoized completion checker
  const isCompleted = useCallback((link: string) => {
    const watchProgress = JSON.parse(cacheStorage.getString(link) || '{}');
    const percentage =
      (watchProgress?.position / watchProgress?.duration) * 100;
    return percentage > 85;
  }, []);

  // Memoized toggle sort order
  const toggleSortOrder = useCallback(() => {
    const newOrder = sortOrder === 'asc' ? 'desc' : 'asc';
    setSortOrder(newOrder);
    mainStorage.setString(episodeSortOrderKey, newOrder);
  }, [episodeSortOrderKey, sortOrder]);

  const formatStreamQuality = useCallback((stream: Stream) => {
    if (!stream.quality) return 'Auto';
    const raw = String(stream.quality).trim();
    if (/k$/i.test(raw)) return raw.toUpperCase();
    return /p$/i.test(raw) ? raw : `${raw}p`;
  }, []);

  const getStreamFilterMatches = useCallback((stream: Stream, filter: QualityFilter) => {
    if (filter === 'All') return true;
    return getStreamQualityCategories(stream).includes(filter);
  }, []);

  const movieQualityFilteredStreams = useMemo(
    () => autoStreams.filter(stream => getStreamFilterMatches(stream, movieQualityFilter)),
    [autoStreams, getStreamFilterMatches, movieQualityFilter],
  );

  const movieAddonFilters = useMemo(() => {
    const counts = new Map<string, number>();
    for (const stream of movieQualityFilteredStreams) {
      const addon = getStreamAddonName(stream);
      counts.set(addon, (counts.get(addon) || 0) + 1);
    }
    return [
      ['All', movieQualityFilteredStreams.length] as const,
      ...Array.from(counts.entries()).sort(([a], [b]) => a.localeCompare(b)),
    ];
  }, [movieQualityFilteredStreams]);

  const movieFilteredStreams = useMemo(
    () => movieQualityFilteredStreams.filter(
      stream => movieAddonFilter === 'All' || getStreamAddonName(stream) === movieAddonFilter,
    ),
    [movieQualityFilteredStreams, movieAddonFilter],
  );

  const episodeQualityFilteredStreams = useMemo(
    () => episodeSelectionStreams.filter(stream => getStreamFilterMatches(stream, episodeQualityFilter)),
    [episodeSelectionStreams, episodeQualityFilter, getStreamFilterMatches],
  );

  const episodeAddonFilters = useMemo(() => {
    const counts = new Map<string, number>();
    for (const stream of episodeQualityFilteredStreams) {
      const addon = getStreamAddonName(stream);
      counts.set(addon, (counts.get(addon) || 0) + 1);
    }
    return [
      ['All', episodeQualityFilteredStreams.length] as const,
      ...Array.from(counts.entries()).sort(([a], [b]) => a.localeCompare(b)),
    ];
  }, [episodeQualityFilteredStreams]);

  const episodeFilteredStreams = useMemo(
    () => episodeQualityFilteredStreams.filter(
      stream => episodeAddonFilter === 'All' || getStreamAddonName(stream) === episodeAddonFilter,
    ),
    [episodeQualityFilteredStreams, episodeAddonFilter],
  );

  useEffect(() => {
    if (episodeAddonFilter !== 'All' && !episodeAddonFilters.some(([addon]) => addon === episodeAddonFilter)) {
      setEpisodeAddonFilter('All');
    }
  }, [episodeAddonFilter, episodeAddonFilters]);

  useEffect(() => {
    if (movieAddonFilter !== 'All' && !movieAddonFilters.some(([addon]) => addon === movieAddonFilter)) {
      setMovieAddonFilter('All');
    }
  }, [movieAddonFilter, movieAddonFilters]);

  const movieBestStream = useMemo(
    () => chooseBestStream(autoStreams),
    [autoStreams],
  );

  const episodeBestStream = useMemo(
    () => chooseBestStream(episodeSelectionStreams),
    [episodeSelectionStreams],
  );

  const openEpisodeStreamSelection = useCallback(
    async (episode: EpisodeLink, forceRefresh: boolean = false) => {
      episodeSelectionControllerRef.current?.abort();
      const controller = new AbortController();
      episodeSelectionControllerRef.current = controller;
      setEpisodeStreamSelection(episode);
      setEpisodeSelectionStreams([]);
      setEpisodeAddonFilter('All');
      setEpisodeSelectionError(null);
      setEpisodeSelectionLoading(true);

      try {
        const streams = await fetchStreams(
          episode.link,
          episode as any && (episode as any).type ? (episode as any).type : type,
          providerValue,
          controller.signal,
          forceRefresh,
        );
        if (controller.signal.aborted) return;
        const seen = new Set<string>();
        const excludedQualities = settingsStorage.getExcludedQualities() || [];
        const sorted = [...(streams || [])]
          .filter(stream => isPotentiallyPlayableStream(stream))
          .filter(stream => !isPromotionalStream(stream))
          .filter(stream => !excludedQualities.some(quality => getStreamQualityCategories(stream).includes(quality)))
          .filter(stream => stream?.link)
          .filter(stream => {
            const key = `${stream.server}|${stream.link}|${stream.quality || ''}`;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
          })
          .sort((a, b) => {
            const providerCompare = String(a.server || '').localeCompare(String(b.server || ''));
            if (providerCompare !== 0) return providerCompare;
            return getStreamQualityRank(b) - getStreamQualityRank(a);
          });
        setEpisodeSelectionStreams(sorted);
        setEpisodeSelectionError(sorted.length > 0 ? null : 'No episode streams available');
      } catch (error: any) {
        if (!controller.signal.aborted) {
          const message = error?.message || 'Failed to fetch episode streams';
          setEpisodeSelectionError(message);
          ToastAndroid.show(message, ToastAndroid.SHORT);
        }
      } finally {
        if (!controller.signal.aborted) {
          setEpisodeSelectionLoading(false);
        }
        if (episodeSelectionControllerRef.current === controller) {
          episodeSelectionControllerRef.current = null;
        }
      }
    },
    [fetchStreams, providerValue, type],
  );

  const closeEpisodeStreamSelection = useCallback(() => {
    episodeSelectionControllerRef.current?.abort();
    episodeSelectionControllerRef.current = null;
    setEpisodeSelectionLoading(false);
    setEpisodeStreamSelection(null);
    setEpisodeSelectionStreams([]);
    setEpisodeSelectionError(null);
  }, []);





  // Memoized season change handler
  const handleSeasonChange = useCallback(
    (item: Link) => {
      setActiveSeason(item);
      cacheStorage.setString(
        `ActiveSeason${metaTitle + providerValue}`,
        JSON.stringify(item),
      );
    },
    [metaTitle, providerValue],
  );

  // Memoized external player handler
  const handleExternalPlayer = useCallback(
    async (link: string, streamType: string) => {
      setVlcLoading(true);
      setIsLoadingStreams(true);

      try {
        cancelStreamFetch();
        const controller = new AbortController();
        streamFetchControllerRef.current = controller;
        const streams = await fetchStreams(
          link,
          streamType,
          providerValue,
          controller.signal,
        );

        if (!streams || streams.length === 0) {
          ToastAndroid.show(
            'No streams available from add-on',
            ToastAndroid.SHORT,
          );
          return;
        }

        console.log('Available Streams Count:', streams.length);
        setExternalPlayerStreams([...streams]);
        setIsLoadingStreams(false);
        setVlcLoading(false);
        setShowServerModal(true);

        ToastAndroid.show(
          `Found ${streams.length} servers`,
          ToastAndroid.SHORT,
        );
      } catch (error: any) {
        console.error('Error fetching streams:', error);
        const errorMessage = error?.message || 'Failed to load streams';
        ToastAndroid.show(errorMessage, ToastAndroid.SHORT);
      } finally {
        setVlcLoading(false);
        setIsLoadingStreams(false);
        streamFetchControllerRef.current = null;
      }
    },
    [cancelStreamFetch, fetchStreams, providerValue],
  );

  // Memoized external player opener
  const openExternalPlayer = useCallback(
    async (
      streamUrl: string,
      headers?: Record<string, string>,
      title?: string,
    ) => {
      setShowServerModal(false);
      setVlcLoading(true);

      try {
        const intentParams: any = {
          data: streamUrl,
          type: 'video/*',
          flags: 1,
        };

        const extra: Record<string, any> = {};

        if (title) {
          extra.title = title;
          extra['android.intent.extra.TITLE'] = title;
        }

        if (headers && Object.keys(headers).length > 0) {
          Object.assign(extra, headers);
          extra['android.media.intent.extra.HTTP_HEADERS'] = headers;
          extra.headers = headers;

          const headersArray = Object.entries(headers).map(
            ([key, val]) => `${key}: ${val}`,
          );
          extra.headers_array = headersArray;

          const referer = headers['Referer'] || headers['referer'];
          if (referer) {
            extra['android.intent.extra.REFERRER'] = referer;
            extra['android.intent.extra.REFERRER_NAME'] = referer;
          }
        }

        if (Object.keys(extra).length > 0) {
          intentParams.extra = extra;
        }

        await IntentLauncher.startActivityAsync(
          'android.intent.action.VIEW',
          intentParams,
        );
      } catch (error) {
        console.error('Error opening external player:', error);
        ToastAndroid.show('Failed to open external player', ToastAndroid.SHORT);
      } finally {
        setVlcLoading(false);
      }
    },
    [],
  );

  // Memoized play handler
  const playHandler = useCallback(
    async ({
      linkIndex,
      type: playbackType,
      primaryTitle,
      seasonTitle,
      episodeData,
      selectedStream: directStream,
    }: PlayHandlerProps) => {
      if (!episodeData || episodeData.length === 0) {
        return;
      }

      const link = episodeData[linkIndex].link;

      if (directStream?.link) {
        try {
          cacheStorage.setString(
            `lastStream:${providerValue}:${link}`,
            JSON.stringify(directStream),
          );
        } catch {}
      }

      const file = (
        metaTitle +
        seasonTitle +
        episodeData[linkIndex]?.title
      ).replaceAll(/[^a-zA-Z0-9]/g, '_');

      const externalPlayer = settingsStorage.getBool('useExternalPlayer');
      const dwFile = await ifExists(file);

      const downloadIndex = getOriginalLinkIndex(episodeList, link, linkIndex);
      const downloadId = createSeriesDownloadId(
        metaTitle,
        seasonTitle,
        downloadIndex,
      );
      const localDownload =
        useDownloadsStore.getState().downloads[downloadId];
      const localPath =
        (localDownload?.status === 'completed' && localDownload?.filePath) ||
        dwFile;

      if (externalPlayer) {
        if (localPath) {
          await IntentLauncher.startActivityAsync(
            'android.intent.action.VIEW',
            {
              data: localPath,
              type: 'video/*',
            },
          );
          return;
        }
        handleExternalPlayer(link, playbackType);
        return;
      }

      navigation.navigate('Player', {
        linkIndex,
        episodeList: episodeData,
        type: playbackType,
        primaryTitle: primaryTitle,
        secondaryTitle: seasonTitle,
        poster: poster,
        providerValue: providerValue,
        infoUrl: routeParams.link,
        directStream: directStream || undefined,
      });
    },
    [
      routeParams.link,
      poster,
      providerValue,
      metaTitle,
      handleExternalPlayer,
      navigation,
    ],
  );





  const playSelectedEpisodeStream = useCallback(
    (stream: Stream) => {
      const episode = episodeStreamSelection;
      if (!episode) return;
      try {
        cacheStorage.setString(
          `lastStream:${providerValue}:${episode.link}`,
          JSON.stringify(stream),
        );
      } catch {}
      closeEpisodeStreamSelection();
      playHandler({
        linkIndex: 0,
        type,
        primaryTitle: metaTitle,
        seasonTitle: activeSeason?.title || '',
        episodeData: [episode],
        selectedStream: stream,
      });
    },
    [activeSeason?.title, closeEpisodeStreamSelection, episodeStreamSelection, metaTitle, playHandler, type],
  );

  // Memoized long press handler
  const onLongPressHandler = useCallback(
    (active: boolean, link: string, streamType?: string) => {
      if (settingsStorage.isHapticFeedbackEnabled()) {
        RNReactNativeHapticFeedback.trigger('effectTick', {
          enableVibrateFallback: true,
          ignoreAndroidSystemSettings: false,
        });
      }
      setStickyMenu({active: active, link: link, type: streamType});
    },
    [],
  );

  // Memoized mark as watched handler
  const markAsWatched = useCallback(() => {
    if (stickyMenu.link) {
      cacheStorage.setString(
        stickyMenu.link,
        JSON.stringify({
          position: 1,
          duration: 1,
        }),
      );
      const episode = [
        ...episodeList,
        ...(activeSeason.directLinks || []),
      ].find(item => item.link === stickyMenu.link);
      if (episode) {
        setSyncedEpisodeProgress({
          episode,
          title: metaTitle,
          poster: poster.poster,
          background: poster.background,
          provider: providerValue,
          infoUrl: routeParams.link,
          type,
          position: 1,
          duration: 1,
        });
      }
      setStickyMenu({active: false});
    }
  }, [
    activeSeason.directLinks,
    episodeList,
    metaTitle,
    poster.background,
    poster.poster,
    providerValue,
    routeParams.link,
    stickyMenu.link,
    type,
  ]);

  // Memoized mark as unwatched handler
  const markAsUnwatched = useCallback(() => {
    if (stickyMenu.link) {
      cacheStorage.setString(
        stickyMenu.link,
        JSON.stringify({
          position: 0,
          duration: 1,
        }),
      );
      const episode = [
        ...episodeList,
        ...(activeSeason.directLinks || []),
      ].find(item => item.link === stickyMenu.link);
      if (episode) {
        setSyncedEpisodeProgress({
          episode,
          title: metaTitle,
          poster: poster.poster,
          background: poster.background,
          provider: providerValue,
          infoUrl: routeParams.link,
          type,
          position: 0,
          duration: 1,
        });
      }
      setStickyMenu({active: false});
    }
  }, [
    activeSeason.directLinks,
    episodeList,
    metaTitle,
    poster.background,
    poster.poster,
    providerValue,
    routeParams.link,
    stickyMenu.link,
    type,
  ]);

  // Memoized sticky menu external player handler
  const handleStickyMenuExternalPlayer = useCallback(() => {
    setStickyMenu({active: false});
    if (stickyMenu.link && stickyMenu.type) {
      handleExternalPlayer(stickyMenu.link, stickyMenu.type);
    }
  }, [stickyMenu.link, stickyMenu.type, handleExternalPlayer]);

  // Memoized episode render item
  const renderEpisodeItem = useCallback(
    ({item, index}: {item: EpisodeLink; index: number}) => {
      if (!item || !item.link || !item.title) {
        console.warn('Invalid episode item at index', index, item);
        return null; // Skip rendering if item is invalid
      }

      const downloadIndex = getOriginalLinkIndex(episodeList, item.link, index);
      const downloadId = createSeriesDownloadId(
        metaTitle,
        activeSeason.title,
        downloadIndex,
      );
      const handleEpisodePress = () => {
        const episode = filteredAndSortedEpisodes[index];
        if (!episode) return;
        openEpisodeStreamSelection(episode);
      };
      return (
        <View
          key={item.link + index}
          className={`w-full my-1
          ${
            isCompleted(item.link) || stickyMenu.link === item.link
              ? 'opacity-60'
              : ''
          }
        `}>
          <View
            className="min-h-[54px] flex-row w-full items-center px-3 py-1"
            style={{
              backgroundColor: LEGACY_TERTIARY_BACKGROUND,
              // borderColor: CONTROL_OUTLINE,
              borderRadius: 24,
              borderWidth: 1,
            }}>
            <TouchableOpacity
              activeOpacity={0.65}
              className="min-w-0 flex-1 items-center flex-row gap-x-3"
              onPress={() => {
                if (detailsPressRef.current === item.link) {
                  detailsPressRef.current = null;
                  return;
                }
                handleEpisodePress();
              }}
              onLongPress={() =>
                onLongPressHandler(true, item.link, 'series')
              }>
              <EpisodeRowContent
                title={item.title}
                description={item.description}
                image={item.image}
                accentColor={primary}
                textColor={CONTROL_TEXT}
                mutedTextColor={CONTROL_TEXT_MUTED}
                onShowDetailsPressIn={() => {
                  detailsPressRef.current = item.link;
                }}
                onShowDetails={
                  item.description?.trim()
                    ? () => {
                        setEpisodeDetails({
                          title: item.title,
                          description: item.description!.trim(),
                          image: item.image,
                        });
                        setTimeout(() => {
                          if (detailsPressRef.current === item.link) {
                            detailsPressRef.current = null;
                          }
                        }, 0);
                      }
                    : undefined
                }
              />
            </TouchableOpacity>
            <Downloader
              downloadId={downloadId}
              providerValue={providerValue}
              link={item.link}
              type={type}
              mediaType="series"
              showName={metaTitle}
              seasonTitle={activeSeason.title}
              episodeName={item.title}
              imdbId={imdbId}
              poster={poster.poster}
              background={poster.background}
              synopsis={synopsis}
              infoUrl={routeParams.link}
              skip={item.skip || (item as any)?.skips}
              quickDownload={
                quickDownload ||
                activeSeason?.quickDownload ||
                item?.quickDownload
              }
              title={
                metaTitle.length > 30
                  ? metaTitle.slice(0, 30) + '... ' + item.title
                  : metaTitle + ' ' + item.title
              }
              fileName={createDesktopCompatibleFileName(
                `${metaTitle} ${item.title}`,
                'series',
              )}
            />
          </View>
        </View>
      );
    },
    [
      isCompleted,
      stickyMenu.link,
      playHandler,
      metaTitle,
      activeSeason?.title,
      episodeList,
      filteredAndSortedEpisodes,
      onLongPressHandler,
      primary,
      providerValue,
      routeParams.link,
      imdbId,
      poster.poster,
    ],
  );

  // Memoized direct link render item
  const renderDirectLinkItem = useCallback(
    ({item, index}: {item: any; index: number}) => {
      if (!item || !item.link || !item.title) {
        console.warn('Invalid direct link item at index', index, item);
        return null; // Skip rendering if item is invalid
      }

      const downloadIndex = getOriginalLinkIndex(
        activeSeason.directLinks,
        item.link,
        index,
      );
      const downloadId = createDirectDownloadId(
        metaTitle,
        activeSeason.title,
        downloadIndex,
      );
      const displayTitle =
        item.title?.trim() ||
        (activeSeason?.directLinks?.length && activeSeason.directLinks.length > 1
          ? `${activeSeason?.title || 'Episode'} ${index + 1}`
          : activeSeason?.title && activeSeason.title.toLowerCase() !== 'default'
          ? activeSeason.title
          : 'Play');
      const handleEpisodePress = () => {
        playHandler({
          linkIndex: index,
          type,
          primaryTitle: metaTitle,
          seasonTitle: activeSeason?.title || '',
          episodeData: filteredAndSortedDirectLinks,
          selectedStream: autoQualitySelected ? undefined : (selectedAutoStream || undefined),
        });
      };

      return (
        <View
          key={item.link + index}
          className={`w-full my-1
          ${
            isCompleted(item.link) || stickyMenu.link === item.link
              ? 'opacity-60'
              : ''
          }
        `}>
          <View
            className="min-h-[54px] flex-row w-full items-center px-3 py-1"
            style={{
              backgroundColor: LEGACY_TERTIARY_BACKGROUND,
              // borderColor: CONTROL_OUTLINE,
              borderRadius: 24,
              borderWidth: 1,
            }}>
            <TouchableOpacity
              activeOpacity={0.65}
              className="min-w-0 flex-1 items-center flex-row gap-x-3"
              onPress={() => {
                if (detailsPressRef.current === item.link) {
                  detailsPressRef.current = null;
                  return;
                }
                handleEpisodePress();
              }}
              onLongPress={() =>
                onLongPressHandler(true, item.link, item?.type || 'series')
              }>
              <EpisodeRowContent
                title={displayTitle}
                description={item.description}
                image={item.image}
                accentColor={primary}
                textColor={CONTROL_TEXT}
                mutedTextColor={CONTROL_TEXT_MUTED}
                onShowDetailsPressIn={() => {
                  detailsPressRef.current = item.link;
                }}
                onShowDetails={
                  item.description?.trim()
                    ? () => {
                        setEpisodeDetails({
                          title: item.title,
                          description: item.description.trim(),
                          image: item.image,
                        });
                        setTimeout(() => {
                          if (detailsPressRef.current === item.link) {
                            detailsPressRef.current = null;
                          }
                        }, 0);
                      }
                    : undefined
                }
              />
            </TouchableOpacity>
            <Downloader
              downloadId={downloadId}
              providerValue={providerValue}
              link={item.link}
              type={type}
              mediaType={item?.type === 'series' ? 'series' : 'movie'}
              showName={metaTitle}
              seasonTitle={activeSeason.title}
              episodeName={item.title}
              imdbId={imdbId}
              poster={poster.poster}
              background={poster.background}
              synopsis={synopsis}
              infoUrl={routeParams.link}
              skip={item.skip || (item as any)?.skips}
              quickDownload={
                quickDownload ||
                activeSeason?.quickDownload ||
                item?.quickDownload
              }
              title={
                metaTitle.length > 30
                  ? metaTitle.slice(0, 30) + '... ' + item.title
                  : metaTitle + ' ' + item.title
              }
              fileName={
                item?.type === 'series' ||
                (activeSeason?.directLinks &&
                  activeSeason.directLinks.length > 1)
                  ? createDesktopCompatibleFileName(
                      `${metaTitle} ${item.title}`,
                      'series',
                    )
                  : createDesktopCompatibleFileName(metaTitle, 'movie')
              }
            />
          </View>
        </View>
      );
    },
    [
      isCompleted,
      stickyMenu.link,
      playHandler,
      metaTitle,
      activeSeason?.title,
      activeSeason?.directLinks,
      filteredAndSortedDirectLinks,
      onLongPressHandler,
      primary,
      providerValue,
      routeParams.link,
      imdbId,
      poster.poster,
      selectedAutoStream,
      autoQualitySelected,
    ],
  );

  // Memoized server render item
  const renderServerItem = useCallback(
    (item: any, index: number) => (
      <TouchableOpacity
        key={`server-${index}-${item.server}`}
        className="mb-2 flex-row items-center justify-between p-3"
        style={{
          backgroundColor: LEGACY_TERTIARY_BACKGROUND,
          // borderColor: CONTROL_OUTLINE,
          borderRadius: 14,
          borderWidth: 1,
        }}
        onPress={() =>
          openExternalPlayer(
            item.link,
            item.headers,
            `${metaTitle || ''} ${item.server || ''}`.trim(),
          )
        }>
        <View>
          <Text
            className="text-lg capitalize font-bold"
            style={{color: CONTROL_TEXT}}>
            {item.server || `Server ${index + 1}`}
          </Text>
          <Text className="text-xs" style={{color: CONTROL_TEXT_MUTED}}>
            {item.type ? `Format: ${item.type.toUpperCase()}` : ''}
          </Text>
        </View>
        <MaterialCommunityIcons name="vlc" size={24} color={primary} />
      </TouchableOpacity>
    ),
    [primary, openExternalPlayer, metaTitle],
  );

  // Show loading skeleton while episodes are loading
  if (episodeLoading) {
    return (
      <View>
        {seasonOptions.length > 1 && (
          <DropdownField
            options={seasonOptions}
            value={activeSeason}
            getKey={item =>
              type === 'series'
                ? `season:${getSeasonNumber(item) ?? getSeasonLabel(item, 0, type)}`
                : item.episodesLink || item.directLinks?.[0]?.link || item.title
            }
            getLabel={(item, index) => getSeasonLabel(item, index, type)}
            onChange={handleSeasonChange}
            showFullOptionLabels
          />
        )}

        <View
          style={{
            width: '100%',
            padding: 10,
            alignItems: 'flex-start',
            gap: 20,
          }}>
          {[...Array(6)].map((_, index) => (
            <SkeletonLoader key={index} show={true} height={48} width={'85%'} />
          ))}
        </View>
      </View>
    );
  }

  // Show error state
  if (episodeError) {
    return (
      <View className="p-4">
        <Text className="text-red-500 text-center">
          {episodeError.message || 'Failed to load episodes. Please try again.'}
        </Text>
        <TouchableOpacity
          className="mt-2 bg-red-600 p-2 rounded-md"
          onPress={() => refetchEpisodes()}>
          <Text className="text-white text-center">Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View>
      {/* Stream selector for movie/direct-link details pages. The first stream
          is selected automatically; choosing another one updates the Play row
          so the exact fetched stream is used without a second provider lookup. */}
      {isDirectStreamPage ? (
        <TouchableOpacity
          activeOpacity={0.78}
          disabled={autoStreamLoading || autoStreams.length === 0}
          onPress={() => {
            setMovieQualityFilter('All');
            setMovieAddonFilter('All');
            setShowMovieStreamModal(true);
          }}
          style={{
            alignItems: 'center',
            backgroundColor: colors.surfaceContainerHigh,
            borderColor: colors.outlineVariant,
            borderRadius: 24,
            borderWidth: 1,
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginBottom: 7,
            minHeight: 48,
            paddingHorizontal: 12,
          }}>
          <View style={{flex: 1, minWidth: 0, paddingRight: 10}}>
            <Text
              numberOfLines={1}
              style={{color: colors.onSurface, fontSize: 15, fontWeight: '800'}}>
              {autoStreamLoading
                ? 'Fetching movie streams…'
                : autoStreams.length > 0
                ? autoQualitySelected
                  ? 'Select Movie Stream'
                  : formatStreamLabel(selectedAutoStream || movieBestStream || autoStreams[0])
                : 'No streams available'}
            </Text>
            <Text
              numberOfLines={1}
              style={{color: colors.onSurfaceVariant, fontSize: 11, marginTop: 2}}>
              {autoStreamLoading
                ? 'Fetching links from installed addons'
                : `${autoStreams.length} available ${autoStreams.length === 1 ? 'link' : 'links'}`}
            </Text>
          </View>
          <MaterialCommunityIcons
            name="playlist-play"
            size={21}
            color={colors.primary}
          />
        </TouchableOpacity>
      ) : (
        <DropdownField
          options={seasonOptions}
          value={activeSeason}
          getKey={item =>
            type === 'series'
              ? `season:${getSeasonNumber(item) ?? getSeasonLabel(item, 0, type)}`
              : item.episodesLink || item.directLinks?.[0]?.link || item.title
          }
          getLabel={(item, index) => getSeasonLabel(item, index, type)}
          onChange={handleSeasonChange}
          showFullOptionLabels
          style={{marginBottom: 8}}
        />
      )}

      {/* Search and Sort Controls */}
      {(episodeList.length > 2 ||
        (activeSeason?.directLinks && activeSeason.directLinks?.length > 2) ||
        searchText) && (
        <View className="flex-row items-center mt-2">
          <View
            style={{
              backgroundColor: colors.surfaceContainerHigh,
              borderColor: colors.outlineVariant,
              borderRadius: 24,
              borderWidth: 1,
              flex: 1,
              flexDirection: 'row',
              height: 38,
              marginRight: 8,
              overflow: 'hidden',
            }}>
            <View
              style={{
                alignItems: 'center',
                justifyContent: 'center',
                paddingLeft: 14,
              }}>
              <MaterialCommunityIcons
                name="magnify"
                size={22}
                color={colors.primary}
              />
            </View>
            <TextInput
              accessibilityLabel="Find episode"
              placeholder="Find episode"
              placeholderTextColor={colors.onSurfaceVariant}
              selectionColor={colors.primary}
              returnKeyType="search"
              style={{
                color: colors.onSurface,
                flex: 1,
                fontSize: 16,
                paddingHorizontal: 10,
                paddingVertical: 0,
              }}
              value={searchText}
              onChangeText={setSearchText}
            />
          </View>
          <TouchableOpacity
            accessibilityLabel={
              sortOrder === 'asc'
                ? 'Sort episodes descending'
                : 'Sort episodes ascending'
            }
            className="h-11 w-11 flex-row items-center justify-center"
            style={{
              backgroundColor: colors.secondaryContainer,
              borderRadius: 22,
            }}
            onPress={toggleSortOrder}>
            <MaterialCommunityIcons
              name={sortOrder === 'asc' ? 'sort-ascending' : 'sort-descending'}
              size={24}
              color={colors.onSecondaryContainer}
            />
          </TouchableOpacity>
        </View>
      )}

      {/* Episode/Direct Links List */}
      <View className="w-full mt-2">
        {/* Episodes List */}
        {filteredAndSortedEpisodes.length > 0 && (
          <FlatList
            data={filteredAndSortedEpisodes}
            keyExtractor={(item, index) => `episode-${item.link}-${index}`}
            renderItem={renderEpisodeItem}
            maxToRenderPerBatch={10}
            windowSize={10}
            removeClippedSubviews={true}
          />
        )}

        {/* Direct Links List */}
        {filteredAndSortedDirectLinks.length > 0 && (
          <View className="w-full mt-1">
            <FlatList
              data={filteredAndSortedDirectLinks}
              keyExtractor={(item, index) => `direct-${item.link}-${index}`}
              renderItem={renderDirectLinkItem}
              maxToRenderPerBatch={10}
              windowSize={10}
              removeClippedSubviews={true}
            />
          </View>
        )}

        {/* No Content Available */}
        {filteredAndSortedEpisodes.length === 0 &&
          filteredAndSortedDirectLinks.length === 0 &&
          LinkList?.length === 0 && (
            <Text
              className="min-h-20 text-lg font-semibold"
              style={{color: colors.onSurfaceVariant}}>
              No stream found
            </Text>
          )}
      </View>

      {/* VLC Loading Indicator */}
      {vlcLoading && (
        <View
          pointerEvents="none"
          className="absolute top-0 left-0 w-full h-full bg-black/60 bg-opacity-50 justify-center items-center">
          <Animated.View style={[vlcLoadingAnimatedStyle]}>
            <MaterialCommunityIcons name="vlc" size={70} color={primary} />
          </Animated.View>
          <Text
            className="mt-2 text-lg font-semibold"
            style={{color: colors.onSurface}}>
            Loading available servers...
          </Text>
        </View>
      )}

      <MaterialDialogSurface
        visible={episodeDetails !== null}
        onDismiss={() => setEpisodeDetails(null)}
        style={{padding: 0}}>
        {episodeDetails ? (
          <>
            {getValidImageUri(episodeDetails.image) &&
            !episodeDetailsImageFailed ? (
              <Image
                source={{uri: getValidImageUri(episodeDetails.image)}}
                resizeMode="cover"
                onError={() => setEpisodeDetailsImageFailed(true)}
                style={{aspectRatio: 16 / 9, width: '100%'}}
              />
            ) : (
              <View
                style={{
                  alignItems: 'center',
                  aspectRatio: 16 / 9,
                  backgroundColor: colors.surfaceContainerHighest,
                  justifyContent: 'center',
                  width: '100%',
                }}>
                <MaterialCommunityIcons
                  name="image-off-outline"
                  size={44}
                  color={colors.onSurfaceVariant}
                />
              </View>
            )}
            <View style={{padding: 20}}>
              <Text
                role="titleLarge"
                style={{color: colors.onSurface, fontWeight: '700'}}>
                {episodeDetails.title}
              </Text>
              <ScrollView style={{maxHeight: 230}}>
                <Text
                  role="bodyMedium"
                  style={{
                    color: colors.onSurfaceVariant,
                    lineHeight: 22,
                    marginTop: 10,
                  }}>
                  {episodeDetails.description}
                </Text>
              </ScrollView>
            </View>
          </>
        ) : null}
      </MaterialDialogSurface>

      <Modal
        visible={Boolean(episodeStreamSelection)}
        transparent
        animationType="fade"
        onRequestClose={closeEpisodeStreamSelection}>
        <View
          style={{
            backgroundColor: 'rgba(0,0,0,0.70)',
            flex: 1,
            justifyContent: 'flex-end',
            padding: 12,
          }}>
          <View
            style={{
              backgroundColor: colors.surfaceContainerHigh,
              borderColor: colors.outlineVariant,
              borderRadius: 24,
              borderWidth: 1,
              maxHeight: '68%',
              padding: 8,
            }}>
            <Text
              className="text-center text-lg font-bold"
              style={{color: colors.onSurface}}>
              Select Episode Stream
            </Text>
            <Text
              className="mb-2 mt-0.5 text-center text-xs"
              style={{color: colors.onSurfaceVariant}}>
              {episodeStreamSelection?.title || 'Episode'}
            </Text>
            <TouchableOpacity
              activeOpacity={0.78}
              disabled={episodeSelectionLoading || !episodeStreamSelection}
              onPress={() => {
                if (episodeStreamSelection) {
                  void openEpisodeStreamSelection(episodeStreamSelection, true);
                }
              }}
              style={{
                alignSelf: 'center',
                alignItems: 'center',
                backgroundColor: colors.secondaryContainer,
                borderColor: colors.outlineVariant,
                borderRadius: 14,
                borderWidth: 1,
                flexDirection: 'row',
                justifyContent: 'center',
                marginBottom: 8,
                paddingHorizontal: 14,
                paddingVertical: 7,
                opacity: episodeSelectionLoading ? 0.6 : 1,
              }}>
              <MaterialCommunityIcons name="refresh" size={17} color={colors.onSecondaryContainer} />
              <Text style={{color: colors.onSecondaryContainer, fontSize: 12, fontWeight: '800', marginLeft: 6}}>
                {episodeSelectionLoading ? 'Fetching links…' : 'Refetch episode links'}
              </Text>
            </TouchableOpacity>

            <View
              style={{
                backgroundColor: colors.surfaceContainerLow,
                borderColor: colors.outlineVariant,
                borderRadius: 18,
                borderWidth: 1,
                marginBottom: 6,
                padding: 5,
              }}>
              <View style={{alignItems: 'center', flexDirection: 'row', marginBottom: 4}}>
                <MaterialCommunityIcons name="tune-variant" size={16} color={colors.primary} />
                <Text style={{color: colors.onSurface, fontSize: 11, fontWeight: '900', marginLeft: 5}}>Quality</Text>
                <Text style={{color: colors.onSurfaceVariant, fontSize: 10, marginLeft: 5}}>Filter streams</Text>
              </View>
              <View style={{flexDirection: 'row', flexWrap: 'wrap', gap: 4}}>
                {QUALITY_FILTERS.map(filter => {
                  const active = episodeQualityFilter === filter;
                  return (
                    <TouchableOpacity
                      key={`episode-quality-${filter}`}
                      activeOpacity={0.72}
                      onPress={() => setEpisodeQualityFilter(filter)}
                      style={{
                        alignItems: 'center',
                        backgroundColor: active ? colors.primary : colors.surfaceContainerHighest,
                        borderColor: active ? colors.primary : colors.outlineVariant,
                        borderRadius: 13,
                        borderWidth: 1,
                        flexGrow: 1,
                        minWidth: '22%',
                        paddingHorizontal: 6,
                        paddingVertical: 2,
                      }}>
                      <Text style={{color: active ? colors.onPrimary : colors.onSurfaceVariant, fontSize: 11, fontWeight: '900', lineHeight: 14, textAlign: 'center'}}>
                        {filter}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <View style={{alignItems: 'center', flexDirection: 'row', marginTop: 7, marginBottom: 4}}>
                <MaterialCommunityIcons name="puzzle-outline" size={16} color={colors.primary} />
                <Text style={{color: colors.onSurface, fontSize: 11, fontWeight: '900', marginLeft: 5}}>Add-ons</Text>
                <Text style={{color: colors.onSurfaceVariant, fontSize: 10, marginLeft: 5}}>Filter by source</Text>
              </View>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{gap: 4, paddingRight: 2}}>
                {episodeAddonFilters.map(([addon, count]) => {
                  const active = episodeAddonFilter === addon;
                  return (
                    <TouchableOpacity
                      key={`episode-addon-${addon}`}
                      activeOpacity={0.72}
                      onPress={() => setEpisodeAddonFilter(addon)}
                      style={{
                        alignItems: 'center',
                        backgroundColor: active ? colors.primary : colors.surfaceContainerHighest,
                        borderColor: active ? colors.primary : colors.outlineVariant,
                        borderRadius: 13,
                        borderWidth: 1,
                        paddingHorizontal: 10,
                        paddingVertical: 3,
                      }}>
                      <Text numberOfLines={1} style={{color: active ? colors.onPrimary : colors.onSurfaceVariant, fontSize: 11, fontWeight: '900'}}>
                        {addon} • {count}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>

            {episodeSelectionLoading ? (
              <View style={{alignItems: 'center', paddingVertical: 28}}>
                <LoadingIndicator size={36} color={primary} />
                <Text style={{color: colors.onSurfaceVariant, marginTop: 10}}>
                  Fetching streams...
                </Text>
              </View>
            ) : (
              <ScrollView
                showsVerticalScrollIndicator={false}
                contentContainerStyle={{gap: 8, paddingBottom: 2}}>
                {episodeFilteredStreams.length > 0 ? (
                  <TouchableOpacity
                    onPress={() => {
                      const episode = episodeStreamSelection;
                      if (!episode) return;
                      // Auto is not a quality. Leave stream selection to the
                      // player so its Server/Quality menu receives every valid
                      // stream returned by the installed addons.
                      closeEpisodeStreamSelection();
                      playHandler({
                        linkIndex: 0,
                        type,
                        primaryTitle: metaTitle,
                        seasonTitle: activeSeason?.title || '',
                        episodeData: [episode],
                      });
                    }}
                    style={{
                      alignItems: 'center',
                      backgroundColor: colors.secondaryContainer,
                      borderColor: colors.primary,
                      borderRadius: 18,
                      borderWidth: 1,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      minHeight: 46,
                      paddingHorizontal: 12,
                    }}>
                    <View style={{flex: 1, minWidth: 0}}>
                      <Text style={{color: colors.onSecondaryContainer, fontWeight: '800'}}>
                        Auto
                      </Text>
                      <Text numberOfLines={1} style={{color: colors.onSecondaryContainer, fontSize: 11, marginTop: 1}}>
                        Load all available links in player
                      </Text>
                    </View>
                    <MaterialCommunityIcons name="play-circle" size={22} color={colors.onSecondaryContainer} />
                  </TouchableOpacity>
                ) : null}
                {Object.entries(
                  episodeFilteredStreams.reduce((groups, stream) => {
                    const key = getStreamAddonName(stream);
                    (groups[key] ||= []).push(stream);
                    return groups;
                  }, {} as Record<string, Stream[]>),
                ).map(([providerName, streams]) => (
                  <View key={providerName} style={{gap: 5}}>
                    <Text style={{color: colors.primary, fontSize: 14, fontWeight: '800'}}>
                      {providerName}
                    </Text>
                    {streams.map((stream, streamIndex) => (
                      <TouchableOpacity
                        key={`${providerName}-${stream.link}-${streamIndex}`}
                        onPress={() => playSelectedEpisodeStream(stream)}
                        style={{
                          alignItems: 'center',
                          backgroundColor: colors.surfaceContainerHighest,
                          borderColor: colors.outlineVariant,
                          borderRadius: 18,
                          borderWidth: 1,
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          minHeight: 46,
                          paddingHorizontal: 11,
                        }}>
                        <View style={{flex: 1, minWidth: 0}}>
                          <View style={{alignItems: 'center', flexDirection: 'row', gap: 7}}>
                            <Text
                              numberOfLines={1}
                              style={{color: colors.onSurface, fontWeight: '700'}}>
                              {formatStreamQuality(stream)}
                            </Text>
                            {episodeBestStream?.link === stream.link ? (
                              <View
                                style={{
                                  backgroundColor: colors.primaryContainer,
                                  borderRadius: 7,
                                  paddingHorizontal: 6,
                                  paddingVertical: 2,
                                }}>
                                <Text
                                  numberOfLines={1}
                                  style={{color: colors.onPrimaryContainer, fontSize: 9, fontWeight: '900'}}>
                                  BEST
                                </Text>
                              </View>
                            ) : null}
                          </View>
                          {([
                            stream.tag,
                            formatStreamFileSize(stream),
                            getStreamQualityCategories(stream).includes('HDR') ? 'HDR' : undefined,
                          ].filter(Boolean).join(' • ')) ? (
                            <Text
                              numberOfLines={1}
                              ellipsizeMode="tail"
                              style={{color: colors.onSurfaceVariant, fontSize: 11, marginTop: 1}}>
                              {[stream.tag, formatStreamFileSize(stream), getStreamQualityCategories(stream).includes('HDR') ? 'HDR' : undefined]
                                .filter(Boolean)
                                .join(' • ')}
                            </Text>
                          ) : null}
                        </View>
                        <MaterialCommunityIcons name="vlc" size={22} color={primary} />
                      </TouchableOpacity>
                    ))}
                  </View>
                ))}
                {episodeFilteredStreams.length === 0 ? (
                  <View style={{alignItems: 'center', paddingVertical: 18}}>
                    <MaterialCommunityIcons
                      name={episodeSelectionError ? 'alert-circle-outline' : 'video-off-outline'}
                      size={30}
                      color={colors.onSurfaceVariant}
                    />
                    <Text
                      style={{
                        color: colors.onSurfaceVariant,
                        paddingTop: 10,
                        textAlign: 'center',
                      }}>
                      {episodeSelectionError || 'No episode streams available'}
                    </Text>
                    <TouchableOpacity
                      disabled={episodeSelectionLoading}
                      onPress={() => {
                        const episode = episodeStreamSelection;
                        if (episode) {
                          openEpisodeStreamSelection(episode, true);
                        }
                      }}
                      style={{
                        alignItems: 'center',
                        backgroundColor: colors.secondaryContainer,
                        borderColor: colors.outlineVariant,
                        borderRadius: 16,
                        borderWidth: 1,
                        flexDirection: 'row',
                        justifyContent: 'center',
                        marginTop: 14,
                        minWidth: 150,
                        paddingHorizontal: 20,
                        paddingVertical: 11,
                      }}>
                      <MaterialCommunityIcons
                        name="refresh"
                        size={20}
                        color={colors.onSecondaryContainer}
                      />
                      <Text
                        style={{
                          color: colors.onSecondaryContainer,
                          fontWeight: '800',
                          marginLeft: 8,
                        }}>
                        Retry
                      </Text>
                    </TouchableOpacity>
                  </View>
                ) : null}
              </ScrollView>
            )}

            {episodeStreamSelection ? (() => {
              const allEpisodes = [...episodeList]
                .filter(item => item?.link)
                .sort((a, b) => {
                  const seasonA = Number.isFinite(Number(a.season)) ? Number(a.season) : 0;
                  const seasonB = Number.isFinite(Number(b.season)) ? Number(b.season) : 0;
                  if (seasonA !== seasonB) return seasonA - seasonB;
                  const episodeA = Number.isFinite(Number(a.episode)) ? Number(a.episode) : 0;
                  const episodeB = Number.isFinite(Number(b.episode)) ? Number(b.episode) : 0;
                  return episodeA - episodeB;
                });
              const currentIndex = allEpisodes.findIndex(item => item.link === episodeStreamSelection.link);
              const nextEpisode = currentIndex >= 0 ? allEpisodes[currentIndex + 1] : undefined;
              if (!nextEpisode) return null;
              return (
                <TouchableOpacity
                  activeOpacity={0.78}
                  onPress={() => openEpisodeStreamSelection(nextEpisode)}
                  style={{
                    alignItems: 'center',
                    backgroundColor: colors.tertiaryContainer,
                    borderColor: colors.outlineVariant,
                    borderRadius: 24,
                    borderWidth: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: 3,
                    minHeight: 46,
                    paddingHorizontal: 12,
                    paddingVertical: 4,
                  }}>
                  <View style={{flex: 1, minWidth: 0, paddingRight: 6}}>
                    <Text style={{color: colors.onTertiaryContainer, fontSize: 9, fontWeight: '900'}}>NEXT EPISODE</Text>
                    <Text numberOfLines={1} style={{color: colors.onTertiaryContainer, fontSize: 12, fontWeight: '800', marginTop: 1}}>
                      {nextEpisode.title}
                    </Text>
                  </View>
                  <MaterialCommunityIcons name="arrow-right" size={18} color={colors.onTertiaryContainer} />
                </TouchableOpacity>
              );
            })() : null}

            <TouchableOpacity
              onPress={closeEpisodeStreamSelection}
              style={{
                backgroundColor: colors.secondaryContainer,
                borderRadius: 22,
                marginTop: 8,
                minHeight: 44,
                justifyContent: 'center',
                paddingVertical: 9,
              }}>
              <Text
                className="text-center font-bold"
                style={{color: colors.onSecondaryContainer}}>
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showMovieStreamModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowMovieStreamModal(false)}>
        <View
          style={{
            backgroundColor: 'rgba(0,0,0,0.70)',
            flex: 1,
            justifyContent: 'flex-end',
            padding: 12,
          }}>
          <View
            style={{
              backgroundColor: colors.surfaceContainerHigh,
              borderColor: colors.outlineVariant,
              borderRadius: 24,
              borderWidth: 1,
              maxHeight: '80%',
              padding: 10,
            }}>
            <Text className="text-center text-xl font-bold" style={{color: colors.onSurface}}>
              Select Movie Stream
            </Text>
            <TouchableOpacity
              activeOpacity={0.78}
              disabled={autoStreamLoading}
              onPress={() => void fetchMovieStreams(true)}
              style={{
                alignSelf: 'center',
                alignItems: 'center',
                backgroundColor: colors.secondaryContainer,
                borderColor: colors.outlineVariant,
                borderRadius: 14,
                borderWidth: 1,
                flexDirection: 'row',
                justifyContent: 'center',
                marginTop: 6,
                marginBottom: 8,
                paddingHorizontal: 14,
                paddingVertical: 7,
                opacity: autoStreamLoading ? 0.6 : 1,
              }}>
              <MaterialCommunityIcons name="refresh" size={17} color={colors.onSecondaryContainer} />
              <Text style={{color: colors.onSecondaryContainer, fontSize: 12, fontWeight: '800', marginLeft: 6}}>
                {autoStreamLoading ? 'Fetching links…' : 'Refetch links'}
              </Text>
            </TouchableOpacity>
            <View
              style={{
                backgroundColor: colors.surfaceContainerLow,
                borderColor: colors.outlineVariant,
                borderRadius: 20,
                borderWidth: 1,
                marginBottom: 6,
                padding: 5,
              }}>
              <View style={{alignItems: 'center', flexDirection: 'row', marginBottom: 4}}>
                <MaterialCommunityIcons name="tune-variant" size={16} color={colors.primary} />
                <Text style={{color: colors.onSurface, fontSize: 11, fontWeight: '900', marginLeft: 5}}>Quality</Text>
                <Text style={{color: colors.onSurfaceVariant, fontSize: 10, marginLeft: 5}}>Filter streams</Text>
              </View>
              <View style={{flexDirection: 'row', flexWrap: 'wrap', gap: 4}}>
                {QUALITY_FILTERS.map(filter => {
                  const active = movieQualityFilter === filter;
                  return (
                    <TouchableOpacity
                      key={`movie-quality-${filter}`}
                      activeOpacity={0.72}
                      onPress={() => setMovieQualityFilter(filter)}
                      style={{
                        alignItems: 'center',
                        backgroundColor: active ? colors.primary : colors.surfaceContainerHighest,
                        borderColor: active ? colors.primary : colors.outlineVariant,
                        borderRadius: 14,
                        borderWidth: 1,
                        flexGrow: 1,
                        minWidth: '22%',
                        paddingHorizontal: 7,
                        paddingVertical: 2,
                      }}>
                      <Text
                        style={{
                          color: active ? colors.onPrimary : colors.onSurfaceVariant,
                          fontSize: 11,
                          fontWeight: '900',
                          lineHeight: 14,
                          textAlign: 'center',
                        }}>
                        {filter}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <View style={{alignItems: 'center', flexDirection: 'row', marginTop: 7, marginBottom: 4}}>
                <MaterialCommunityIcons name="puzzle-outline" size={16} color={colors.primary} />
                <Text style={{color: colors.onSurface, fontSize: 11, fontWeight: '900', marginLeft: 5}}>Add-ons</Text>
                <Text style={{color: colors.onSurfaceVariant, fontSize: 10, marginLeft: 5}}>Filter by source</Text>
              </View>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{gap: 4, paddingRight: 2}}>
                {movieAddonFilters.map(([addon, count]) => {
                  const active = movieAddonFilter === addon;
                  return (
                    <TouchableOpacity
                      key={`movie-addon-filter-${addon}`}
                      activeOpacity={0.72}
                      onPress={() => setMovieAddonFilter(addon)}
                      style={{
                        alignItems: 'center',
                        backgroundColor: active ? colors.primary : colors.surfaceContainerHighest,
                        borderColor: active ? colors.primary : colors.outlineVariant,
                        borderRadius: 13,
                        borderWidth: 1,
                        paddingHorizontal: 10,
                        paddingVertical: 3,
                      }}>
                      <Text numberOfLines={1} style={{color: active ? colors.onPrimary : colors.onSurfaceVariant, fontSize: 11, fontWeight: '900'}}>
                        {addon} • {count}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>

            {autoStreamLoading ? (
              <View style={{alignItems: 'center', paddingVertical: 28}}>
                <LoadingIndicator size={36} color={primary} />
                <Text style={{color: colors.onSurfaceVariant, marginTop: 10}}>
                  Fetching streams from installed addons…
                </Text>
              </View>
            ) : (
              <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{gap: 10, paddingBottom: 4}}>
                <TouchableOpacity
                  activeOpacity={0.78}
                  onPress={() => {
                    setSelectedAutoStream(null);
                    setAutoQualitySelected(true);
                    setShowMovieStreamModal(false);
                  }}
                  style={{
                    alignItems: 'center',
                    backgroundColor: autoQualitySelected ? colors.primaryContainer : colors.surfaceContainerHighest,
                    borderColor: autoQualitySelected ? colors.primary : colors.outlineVariant,
                    borderRadius: 16,
                    borderWidth: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    minHeight: 50,
                    paddingHorizontal: 12,
                  }}>
                  <View style={{flex: 1, minWidth: 0, paddingRight: 10}}>
                    <Text style={{color: autoQualitySelected ? colors.onPrimaryContainer : colors.onSurface, fontWeight: '900'}}>Auto</Text>
                    <Text numberOfLines={1} style={{color: autoQualitySelected ? colors.onPrimaryContainer : colors.onSurfaceVariant, fontSize: 11, marginTop: 1}}>
                      Load all available links in player
                    </Text>
                  </View>
                  <MaterialCommunityIcons name="play-circle-outline" size={24} color={autoQualitySelected ? colors.onPrimaryContainer : primary} />
                </TouchableOpacity>

                {groupStreamsByAddon(movieFilteredStreams).map(([addonName, streams]) => (
                  <View key={`movie-addon-${addonName}`} style={{gap: 5}}>
                    <Text style={{color: colors.primary, fontSize: 13, fontWeight: '800', marginLeft: 2}}>
                      {addonName}
                    </Text>
                    {streams.map((stream, streamIndex) => (
                      <TouchableOpacity
                        key={`movie-stream-${addonName}-${stream.link}-${streamIndex}`}
                        activeOpacity={0.78}
                        onPress={() => {
                          setSelectedAutoStream(stream);
                          setAutoQualitySelected(false);
                          try { cacheStorage.setString(lastStreamSelectionKey, JSON.stringify(stream)); } catch {}
                          setShowMovieStreamModal(false);
                        }}
                        style={{
                          alignItems: 'center',
                          backgroundColor: !autoQualitySelected && selectedAutoStream?.link === stream.link ? colors.primaryContainer : colors.surfaceContainerHighest,
                          borderColor: !autoQualitySelected && selectedAutoStream?.link === stream.link ? colors.primary : colors.outlineVariant,
                          borderRadius: 18,
                          borderWidth: 1,
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          minHeight: 46,
                          paddingHorizontal: 11,
                        }}>
                        <View style={{flex: 1, minWidth: 0, paddingRight: 10}}>
                          <View style={{alignItems: 'center', flexDirection: 'row', gap: 7}}>
                            <Text numberOfLines={1} style={{color: colors.onSurface, fontWeight: '800', fontSize: 13}}>
                              {formatStreamQuality(stream)}
                            </Text>
                            {movieBestStream?.link === stream.link ? (
                              <View style={{backgroundColor: colors.primaryContainer, borderRadius: 7, paddingHorizontal: 5, paddingVertical: 1}}>
                                <Text style={{color: colors.onPrimaryContainer, fontSize: 9, fontWeight: '900'}}>BEST</Text>
                              </View>
                            ) : null}
                          </View>
                          <Text numberOfLines={1} ellipsizeMode="tail" style={{color: colors.onSurfaceVariant, fontSize: 10, marginTop: 1}}>
                            {[stream.tag, formatStreamFileSize(stream), getStreamQualityCategories(stream).includes('HDR') ? 'HDR' : undefined]
                              .filter(Boolean)
                              .join(' • ')}
                          </Text>
                        </View>
                        <MaterialCommunityIcons name="check-circle-outline" size={19} color={!autoQualitySelected && selectedAutoStream?.link === stream.link ? primary : colors.onSurfaceVariant} />
                      </TouchableOpacity>
                    ))}
                  </View>
                ))}

                {movieFilteredStreams.length === 0 ? (
                  <View style={{alignItems: 'center', paddingVertical: 18}}>
                    <MaterialCommunityIcons
                      name="video-off-outline"
                      size={30}
                      color={colors.onSurfaceVariant}
                    />
                    <Text style={{color: colors.onSurfaceVariant, marginTop: 8, textAlign: 'center'}}>
                      {autoStreams.length === 0
                        ? 'No links were fetched.'
                        : 'No links match the selected quality.'}
                    </Text>
                    {autoStreams.length === 0 ? (
                      <TouchableOpacity
                        activeOpacity={0.78}
                        disabled={autoStreamLoading}
                        onPress={() => void fetchMovieStreams(true)}
                        style={{
                          alignItems: 'center',
                          backgroundColor: colors.primaryContainer,
                          borderColor: colors.primary,
                          borderRadius: 16,
                          borderWidth: 1,
                          flexDirection: 'row',
                          marginTop: 12,
                          paddingHorizontal: 16,
                          paddingVertical: 9,
                        }}>
                        <MaterialCommunityIcons
                          name="refresh"
                          size={18}
                          color={colors.onPrimaryContainer}
                        />
                        <Text
                          style={{
                            color: colors.onPrimaryContainer,
                            fontWeight: '800',
                            marginLeft: 7,
                          }}>
                          Refresh links
                        </Text>
                      </TouchableOpacity>
                    ) : null}
                  </View>
                ) : null}
              </ScrollView>
            )}

            <TouchableOpacity
              onPress={() => setShowMovieStreamModal(false)}
              style={{backgroundColor: colors.secondaryContainer, borderRadius: 18, marginTop: 12, paddingVertical: 12}}>
              <Text className="text-center font-bold" style={{color: colors.onSecondaryContainer}}>
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <MaterialDialogSurface
        visible={showServerModal}
        onDismiss={() => setShowServerModal(false)}>
        <Text
          className="mb-2 text-center text-xl font-bold"
          style={{color: colors.onSurface}}>
          Select External Player Server
        </Text>
        <Text
          className="mb-4 text-center text-sm"
          style={{color: colors.onSurfaceVariant}}>
          {externalPlayerStreams.length} servers available
        </Text>

        {isLoadingStreams ? (
          <LoadingIndicator size={40} color={primary} />
        ) : (
          <>
            <ScrollView style={{maxHeight: 300}}>
              {externalPlayerStreams.map((item, index) =>
                renderServerItem(item, index),
              )}
              {externalPlayerStreams.length === 0 && (
                <Text
                  className="p-4 text-center"
                  style={{color: colors.onSurfaceVariant}}>
                  No servers available
                </Text>
              )}
            </ScrollView>

            <TouchableOpacity
              className="mt-4 py-3"
              style={{
                backgroundColor: colors.secondaryContainer,
                borderRadius: 18,
              }}
              onPress={() => setShowServerModal(false)}>
              <Text
                className="text-center font-bold"
                style={{color: colors.onSecondaryContainer}}>
                Cancel
              </Text>
            </TouchableOpacity>
          </>
        )}
      </MaterialDialogSurface>

      <MaterialDialogSurface
        visible={stickyMenu.active}
        onDismiss={() => setStickyMenu({active: false})}>
        <Text
          className="mb-4 text-xl font-bold"
          style={{color: colors.onSurface}}>
          Episode actions
        </Text>
        <View style={{gap: 10}}>
          {isCompleted(stickyMenu.link || '') ? (
            <TouchableOpacity
              className="h-12 flex-row items-center gap-3 px-4"
              style={{
                backgroundColor: colors.surfaceContainerHighest,
                borderRadius: 18,
              }}
              onPress={markAsUnwatched}>
              <Ionicons name="checkmark-done" size={30} color={primary} />
              <Text style={{color: colors.onSurface}}>Mark as unwatched</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              className="h-12 flex-row items-center gap-3 px-4"
              style={{
                backgroundColor: colors.surfaceContainerHighest,
                borderRadius: 18,
              }}
              onPress={markAsWatched}>
              <Ionicons name="checkmark" size={25} color={primary} />
              <Text style={{color: colors.onSurface}}>Mark as watched</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            className="h-12 flex-row items-center gap-3 px-4"
            style={{
              backgroundColor: colors.surfaceContainerHighest,
              borderRadius: 18,
            }}
            onPress={handleStickyMenuExternalPlayer}>
            <Feather name="external-link" size={20} color={primary} />
            <Text style={{color: colors.onSurface}}>External player</Text>
          </TouchableOpacity>
        </View>
      </MaterialDialogSurface>
    </View>
  );
};


// Keep the empty state outside the hook-using content component so hooks are
// never conditionally skipped when streams arrive after a refresh.
const SeasonList: React.FC<SeasonListProps> = props => {
  if (!props.LinkList || props.LinkList.length === 0) {
    return (
      <View className="p-4">
        <Text className="text-white text-center">No Streams Available</Text>
      </View>
    );
  }
  return <SeasonListContent {...props} />;
};

export default SeasonList;

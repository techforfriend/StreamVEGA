import axios from 'axios';
import {MMKVLoader} from 'react-native-mmkv-storage';
import {mainStorage} from '../storage';
import {providerContext} from '../providers/providerContext';
import type {Catalog, EpisodeLink, Info, Post, SettingsField, Stream} from '../providers/types';

export interface VegaPluginSource {
  author: string;
  url: string;
}

export interface VegaPluginManifest {
  display_name: string;
  value: string;
  version: string;
  icon?: string;
  type?: string;
  disabled?: boolean;
  source: VegaPluginSource;
  installed?: boolean;
}

export interface VegaPluginModule {
  value: string;
  sourceAuthor: string;
  version: string;
  modules: Record<string, string | undefined>;
  cachedAt: number;
}

const SOURCE_KEY = 'vegaPlugins.source';
const INSTALLED_KEY = 'vegaPlugins.installed';
const MODULE_KEY = 'vegaPlugins.modules';
const ENABLED_KEY = 'vegaPlugins.enabled';

const normalizeSource = (input: string): VegaPluginSource => {
  let value = input.trim().replace(/\/+$/, '');
  if (!value) throw new Error('Enter a Vega provider repository URL.');
  if (/^https?:\/\//i.test(value) && /\/manifest\.json$/i.test(value)) {
    const manifestUrl = value;
    value = manifestUrl.slice(0, -'/manifest.json'.length);
  }
  if (/^github\.com\//i.test(value)) value = `https://${value}`;
  const parsed = new URL(value);
  if (parsed.hostname === 'github.com') {
    const parts = parsed.pathname.split('/').filter(Boolean);
    if (parts.length >= 2) {
      return {author: parts[0], url: `https://raw.githubusercontent.com/${parts[0]}/${parts[1]}/main`};
    }
  }
  return {author: parsed.hostname + parsed.pathname, url: value};
};

const getManifestUrl = (source: VegaPluginSource) => `${source.url.replace(/\/+$/, '')}/manifest.json`;


class VegaPluginManager {
  private installed: VegaPluginManifest[] = mainStorage.getArray<VegaPluginManifest>(INSTALLED_KEY) || [];
  private modules: Record<string, VegaPluginModule> = mainStorage.getObject<Record<string, VegaPluginModule>>(MODULE_KEY) || {};
  private enabled: Record<string, boolean> = mainStorage.getObject<Record<string, boolean>>(ENABLED_KEY) || {};

  getSource(): VegaPluginSource | undefined {
    const source = mainStorage.getObject<VegaPluginSource>(SOURCE_KEY);
    return source?.url ? source : undefined;
  }

  setSource(input: string): VegaPluginSource {
    const source = normalizeSource(input);
    mainStorage.setObject(SOURCE_KEY, source);
    return source;
  }

  listInstalled(): VegaPluginManifest[] {
    return this.installed.map(item => ({...item, installed: true, disabled: !this.isEnabled(item.value)}));
  }

  isEnabled(value: string): boolean {
    return this.enabled[value] !== false;
  }

  setEnabled(value: string, enabled: boolean): void {
    this.enabled[value] = enabled;
    mainStorage.setObject(ENABLED_KEY, this.enabled);
  }

  async fetchAvailable(sourceInput?: string, force = true): Promise<VegaPluginManifest[]> {
    const source = sourceInput ? this.setSource(sourceInput) : this.getSource();
    if (!source) throw new Error('Configure a Vega provider repository first.');
    const response = await axios.get(getManifestUrl(source), {timeout: 15000});
    if (!Array.isArray(response.data)) throw new Error('Invalid Vega provider manifest.');
    return response.data
      .filter((item: any) => item && item.value && item.display_name && !item.disabled)
      .map((item: any) => ({
        display_name: String(item.display_name),
        value: String(item.value),
        version: String(item.version || '1.0.0'),
        icon: item.icon ? String(item.icon) : '',
        type: item.type || 'global',
        disabled: Boolean(item.disabled),
        source,
        installed: this.installed.some(p => p.value === item.value && p.source.author === source.author),
      }));
  }

  async install(plugin: VegaPluginManifest): Promise<void> {
    await this.downloadModules(plugin);
    this.installed = [
      ...this.installed.filter(p => !(p.value === plugin.value && p.source.author === plugin.source.author)),
      {...plugin, installed: true, disabled: false},
    ];
    this.enabled[plugin.value] = true;
    this.persist();
  }

  async refresh(plugin: VegaPluginManifest): Promise<void> {
    await this.downloadModules(plugin);
    this.installed = this.installed.map(item =>
      item.value === plugin.value && item.source.author === plugin.source.author
        ? {...plugin, installed: true, disabled: !this.isEnabled(plugin.value)}
        : item,
    );
    this.persist();
  }

  remove(value: string, author?: string): void {
    this.installed = this.installed.filter(item => !(item.value === value && (!author || item.source.author === author)));
    delete this.modules[this.moduleKey(value, author)];
    delete this.enabled[value];
    this.persist();
  }

  getInstalledSources(): VegaPluginManifest[] {
    return this.listInstalled().filter(item => this.isEnabled(item.value));
  }

  getPlugin(value: string): VegaPluginManifest | undefined {
    return this.installed.find(item => item.value === value);
  }

  private moduleKey(value: string, author?: string) {
    return `${author || this.getPlugin(value)?.source.author || 'unknown'}:${value}`;
  }

  private async downloadModules(plugin: VegaPluginManifest): Promise<void> {
    const base = `${plugin.source.url.replace(/\/+$/, '')}/dist/${encodeURIComponent(plugin.value)}`;
    const names = ['posts', 'meta', 'stream', 'catalog', 'episodes', 'settings'];
    const modules: Record<string, string | undefined> = {};
    await Promise.all(names.map(async name => {
      try {
        const response = await axios.get(`${base}/${name}.js`, {timeout: 20000, responseType: 'text'});
        if (typeof response.data === 'string' && response.data.trim()) modules[name] = response.data;
      } catch (error) {
        if (['posts', 'meta', 'stream', 'catalog'].includes(name)) throw new Error(`Failed to download ${name}.js for ${plugin.display_name}.`);
      }
    }));
    for (const required of ['posts', 'meta', 'stream', 'catalog']) {
      if (!modules[required]) throw new Error(`Vega plugin ${plugin.display_name} is missing ${required}.js.`);
    }
    this.modules[this.moduleKey(plugin.value, plugin.source.author)] = {
      value: plugin.value,
      sourceAuthor: plugin.source.author,
      version: plugin.version,
      modules,
      cachedAt: Date.now(),
    };
    this.persist();
  }

  private getModule(value: string): VegaPluginModule {
    const plugin = this.getPlugin(value);
    if (!plugin) throw new Error(`Vega plugin not installed: ${value}`);
    const module = this.modules[this.moduleKey(value, plugin.source.author)];
    if (!module) throw new Error(`Vega plugin modules are not installed: ${value}`);
    return module;
  }

  private execute(code: string, args: Record<string, unknown> = {}): any {
    const module = {exports: {}} as any;
    const exports = module.exports;
    const require = (_name: string) => ({});
    const fn = new Function('exports', 'module', 'require', 'console', 'Promise', 'Object', `${code}\n//# sourceURL=streamx-vega-plugin.js`);
    fn(exports, module, require, console, Promise, Object);
    return module.exports;
  }

  private async call(value: string, file: string, fnName: string, args: Record<string, unknown>): Promise<any> {
    const module = this.getModule(value);
    const code = module.modules[file];
    if (!code) throw new Error(`Vega plugin ${value} does not provide ${file}.js.`);
    const provider = this.getPlugin(value)!;
    const context = {
      ...providerContext,
      kvStore: this.createKvStore(value),
    };
    const moduleExports = this.execute(code, args);
    const fn = moduleExports[fnName];
    if (typeof fn !== 'function') throw new Error(`Vega plugin ${value} does not export ${fnName}.`);
    return await fn({...args, providerContext: context, providerValue: value});
  }

  private createKvStore(value: string) {
    const instance = `vega-plugin-${value.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    const kv = new MMKVLoader().withInstanceID(instance).initialize();
    const keysKey = '__streamx_keys__';
    const readKeys = (): string[] => {
      try { return JSON.parse(kv.getString(keysKey) || '[]'); } catch { return []; }
    };
    const writeKey = (key: string) => {
      const keys = readKeys();
      if (!keys.includes(key)) kv.setString(keysKey, JSON.stringify([...keys, key]));
    };
    return {
      get: async <T = unknown>(key: string) => {
        const raw = kv.getString(key);
        if (raw == null) return undefined as T | undefined;
        try { return JSON.parse(raw) as T; } catch { return raw as T; }
      },
      set: async (key: string, val: unknown) => { writeKey(key); kv.setString(key, JSON.stringify(val)); },
      delete: async (key: string) => { const existed = kv.getString(key) != null; kv.removeItem(key); return existed; },
      keys: async () => readKeys().filter(key => key !== keysKey),
      clear: async () => kv.clearStore(),
    };
  }

  async getCatalog(value: string): Promise<Catalog[]> {
    const mod = this.getModule(value);
    const code = mod.modules.catalog;
    if (!code) return [];
    const exports = this.execute(code);
    return Array.isArray(exports.catalog) ? exports.catalog : [];
  }

  async getGenres(value: string): Promise<Catalog[]> {
    const mod = this.getModule(value);
    const code = mod.modules.catalog;
    if (!code) return [];
    const exports = this.execute(code);
    return Array.isArray(exports.genres) ? exports.genres : [];
  }

  getPosts(value: string, filter: string, page: number, signal: AbortSignal): Promise<Post[]> {
    return this.call(value, 'posts', 'getPosts', {filter, page, signal});
  }

  getSearchPosts(value: string, searchQuery: string, page: number, signal: AbortSignal): Promise<Post[]> {
    return this.call(value, 'posts', 'getSearchPosts', {searchQuery, page, signal});
  }

  getMetaData(value: string, link: string): Promise<Info> {
    return this.call(value, 'meta', 'getMeta', {link});
  }

  getStream(value: string, link: string, type: string, signal?: AbortSignal, isDownload?: boolean): Promise<Stream[]> {
    return this.call(value, 'stream', 'getStream', {link, type, signal, isDownload});
  }

  getEpisodes(value: string, url: string): Promise<EpisodeLink[]> {
    return this.call(value, 'episodes', 'getEpisodes', {url});
  }

  async getSettingsSchema(value: string): Promise<SettingsField[]> {
    const module = this.getModule(value);
    if (!module.modules.settings) return [];
    return this.call(value, 'settings', 'getSettingsSchema', {});
  }

  clearProviderStorage(value: string): void {
    const instance = `vega-plugin-${value.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    try { new MMKVLoader().withInstanceID(instance).initialize().clearStore(); } catch {}
  }

  private persist() {
    mainStorage.setArray(INSTALLED_KEY, this.installed);
    mainStorage.setObject(MODULE_KEY, this.modules);
    mainStorage.setObject(ENABLED_KEY, this.enabled);
  }
}

export const vegaPluginManager = new VegaPluginManager();
export default vegaPluginManager;

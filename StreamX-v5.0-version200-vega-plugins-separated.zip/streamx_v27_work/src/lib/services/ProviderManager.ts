import {Catalog, EpisodeLink, Info, Post, Stream, SettingsField} from '../providers/types';
import stremioProviderManager from './StremioProviderManager';
import vegaPluginManager from './VegaPluginManager';

/**
 * Unified content facade used by Home/Search/Info/Player.
 *
 * Stremio add-ons and Vega plugins use separate namespaces and managers.
 * Vega plugin links always use the `vega:` namespace and never enter the
 * Stremio add-on manager.
 */
export class ProviderManager {
  private isVega(providerValue: string) {
    return providerValue.startsWith('vega:');
  }

  private vegaValue(providerValue: string) {
    return providerValue.slice('vega:'.length);
  }

  private assertStremio(providerValue: string) {
    if (!stremioProviderManager.isStremioProvider(providerValue)) {
      throw new Error('This Stremio add-on is not installed or enabled.');
    }
  }

  getCatalog = async ({providerValue}: {providerValue: string}): Promise<Catalog[]> => {
    if (this.isVega(providerValue)) return vegaPluginManager.getCatalog(this.vegaValue(providerValue));
    this.assertStremio(providerValue);
    return stremioProviderManager.getCatalog(providerValue);
  };

  getGenres = async ({providerValue}: {providerValue: string}): Promise<Catalog[]> => {
    if (this.isVega(providerValue)) return vegaPluginManager.getGenres(this.vegaValue(providerValue));
    this.assertStremio(providerValue);
    return [];
  };

  getPosts = async ({
    filter,
    page,
    providerValue,
    signal,
  }: {
    filter: string;
    page: number;
    providerValue: string;
    signal: AbortSignal;
  }): Promise<Post[]> => {
    if (this.isVega(providerValue)) return vegaPluginManager.getPosts(this.vegaValue(providerValue), filter, page, signal);
    this.assertStremio(providerValue);
    return stremioProviderManager.getPosts({filter, page, providerValue, signal});
  };

  getSearchPosts = async ({
    searchQuery,
    page,
    providerValue,
    signal,
    allowGlobalFallback = true,
  }: {
    searchQuery: string;
    page: number;
    providerValue: string;
    signal: AbortSignal;
    allowGlobalFallback?: boolean;
  }): Promise<Post[]> => {
    if (this.isVega(providerValue)) return vegaPluginManager.getSearchPosts(this.vegaValue(providerValue), searchQuery, page, signal);
    this.assertStremio(providerValue);
    return stremioProviderManager.getSearchPosts({
      searchQuery,
      page,
      providerValue,
      signal,
      allowGlobalFallback,
    });
  };

  getMetaData = async ({
    link,
    provider,
    signal,
  }: {
    link: string;
    provider: string;
    signal?: AbortSignal;
  }): Promise<Info> => {
    if (this.isVega(provider)) return vegaPluginManager.getMetaData(this.vegaValue(provider), link);
    this.assertStremio(provider);
    return stremioProviderManager.getMetaData({link, provider, signal});
  };

  getStream = async ({
    link,
    type,
    signal,
    providerValue,
    isDownload,
  }: {
    link: string;
    type: string;
    signal?: AbortSignal;
    providerValue: string;
    isDownload?: boolean;
  }): Promise<Stream[]> => {
    if (this.isVega(providerValue)) return vegaPluginManager.getStream(this.vegaValue(providerValue), link, type, signal, isDownload);
    this.assertStremio(providerValue);
    return stremioProviderManager.getStream({
      link,
      type,
      signal,
      providerValue,
      isDownload,
    });
  };

  getEpisodes = async ({
    url,
    providerValue,
    signal,
  }: {
    url: string;
    providerValue: string;
    signal?: AbortSignal;
  }): Promise<EpisodeLink[]> => {
    if (this.isVega(providerValue)) {
      try { return await vegaPluginManager.getEpisodes(this.vegaValue(providerValue), url); }
      catch (error) {
        if (error instanceof Error && /does not provide episodes|does not export getEpisodes/.test(error.message)) return [];
        throw error;
      }
    }
    this.assertStremio(providerValue);
    return stremioProviderManager.getEpisodes({url, providerValue, signal});
  };

  getSettingsSchema = async ({
    providerValue,
  }: {
    providerValue: string;
    sourceAuthor?: string;
  }): Promise<SettingsField[]> => {
    if (this.isVega(providerValue)) return vegaPluginManager.getSettingsSchema(this.vegaValue(providerValue));
    return [];
  };

  clearProviderStorage = async (providerValue: string): Promise<void> => {
    if (this.isVega(providerValue)) {
      vegaPluginManager.clearProviderStorage(this.vegaValue(providerValue));
    }
  };
}

export const providerManager = new ProviderManager();

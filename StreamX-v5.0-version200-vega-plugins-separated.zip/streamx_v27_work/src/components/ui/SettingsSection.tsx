import React, {ReactNode} from 'react';
import {View} from 'react-native';
import AppText from './Text';
import {useM3Colors} from '../../theme/M3PaletteContext';

interface SettingsSectionProps {
  title: string;
  children: ReactNode;
}

const SettingsSection = ({title, children}: SettingsSectionProps) => {
  const colors = useM3Colors();
  return (
    <View style={{marginBottom: 12}}>
      <AppText
        role="labelMediumEmphasized"
        style={{
          color: colors.onSurfaceVariant,
          letterSpacing: 1.25,
          marginLeft: 2,
          marginBottom: 6,
        }}>
        {title.toUpperCase()}
      </AppText>
      <View
        style={{
          backgroundColor: colors.surfaceContainer,
          borderRadius: 24,
          borderWidth: 1,
          borderColor: colors.outlineVariant,
          overflow: 'hidden',
        }}>
        {children}
      </View>
    </View>
  );
};

export default SettingsSection;

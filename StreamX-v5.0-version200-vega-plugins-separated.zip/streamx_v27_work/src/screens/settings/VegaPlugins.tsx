import React, {useCallback, useEffect, useState} from 'react';
import {Alert, FlatList, Image, RefreshControl, TextInput, View} from 'react-native';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {MaterialCommunityIcons} from '@expo/vector-icons';
import {SettingsStackParamList} from '../../App';
import AppText from '../../components/ui/Text';
import IconButton from '../../components/ui/IconButton';
import CompactSwitch from '../../components/ui/CompactSwitch';
import SettingsSection from '../../components/ui/SettingsSection';
import {useM3Colors} from '../../theme/M3PaletteContext';
import useTabBarScrollVisibility from '../../lib/hooks/useTabBarScrollVisibility';
import vegaPluginManager, {VegaPluginManifest} from '../../lib/services/VegaPluginManager';
import useContentStore from '../../lib/zustand/contentStore';

type Props = NativeStackScreenProps<SettingsStackParamList, 'VegaPlugins'>;

const VegaPlugins = ({navigation}: Props) => {
  const colors = useM3Colors();
  const tabBarScroll = useTabBarScrollVisibility();
  const syncProviders = useContentStore(state => state.syncStremioProviders);
  const [source, setSource] = useState(vegaPluginManager.getSource()?.url || '');
  const [available, setAvailable] = useState<VegaPluginManifest[]>([]);
  const [installed, setInstalled] = useState<VegaPluginManifest[]>(vegaPluginManager.listInstalled());
  const [refreshing, setRefreshing] = useState(false);

  const reloadInstalled = useCallback(() => {
    setInstalled(vegaPluginManager.listInstalled());
    syncProviders();
  }, [syncProviders]);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      const list = await vegaPluginManager.fetchAvailable(source);
      setAvailable(list);
      reloadInstalled();
    } catch (error) {
      Alert.alert('Vega Plugins', error instanceof Error ? error.message : 'Unable to load the provider manifest.');
    } finally {
      setRefreshing(false);
    }
  }, [reloadInstalled, source]);

  useEffect(() => {
    const saved = vegaPluginManager.getSource();
    if (saved) {
      void vegaPluginManager.fetchAvailable().then(setAvailable).catch(() => undefined);
    }
  }, []);

  const install = async (plugin: VegaPluginManifest) => {
    try {
      await vegaPluginManager.install(plugin);
      reloadInstalled();
      Alert.alert('Installed', `${plugin.display_name} is now available under Vega Plugins.`);
    } catch (error) {
      Alert.alert('Install failed', error instanceof Error ? error.message : 'Unable to install this Vega plugin.');
    }
  };

  const remove = (plugin: VegaPluginManifest) => {
    Alert.alert('Remove Vega plugin?', plugin.display_name, [
      {text: 'Cancel', style: 'cancel'},
      {text: 'Remove', style: 'destructive', onPress: () => { vegaPluginManager.remove(plugin.value, plugin.source.author); reloadInstalled(); }},
    ]);
  };

  const toggle = (plugin: VegaPluginManifest) => {
    vegaPluginManager.setEnabled(plugin.value, !vegaPluginManager.isEnabled(plugin.value));
    reloadInstalled();
  };

  const installedIds = new Set(installed.map(item => `${item.source.author}:${item.value}`));

  return (
    <View style={{flex: 1, backgroundColor: colors.background}}>
      <View style={{flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingTop: 18, paddingBottom: 10}}>
        <IconButton icon="arrow-left" label="Back" buttonSize={40} onPress={() => navigation.goBack()} contentColor={colors.onSurface} />
        <AppText role="headlineLargeEmphasized" style={{flex: 1, marginLeft: 10, color: colors.onBackground, fontSize: 30}}>Vega Plugins</AppText>
        <IconButton icon="refresh" label="Refresh Vega plugins" buttonSize={40} onPress={refresh} disabled={refreshing} contentColor={colors.primary} />
      </View>

      <FlatList
        data={available}
        keyExtractor={item => `${item.source.author}:${item.value}`}
        onScroll={tabBarScroll.onScroll}
        onScrollBeginDrag={tabBarScroll.onScrollBeginDrag}
        onScrollEndDrag={tabBarScroll.onScrollEndDrag}
        onMomentumScrollBegin={tabBarScroll.onMomentumScrollBegin}
        onMomentumScrollEnd={tabBarScroll.onMomentumScrollEnd}
        scrollEventThrottle={32}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} />}
        contentContainerStyle={{paddingHorizontal: 18, paddingBottom: 138}}
        ListHeaderComponent={
          <View style={{paddingBottom: 12}}>
            <SettingsSection title="Separate Vega source">
              <View style={{padding: 14}}>
                <AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginBottom: 8}}>
                  This source is completely separate from Stremio add-ons. Use a Vega provider repository containing manifest.json and dist/&lt;plugin&gt;/ modules.
                </AppText>
                <View style={{flexDirection: 'row', alignItems: 'center', gap: 8}}>
                  <TextInput
                    value={source}
                    onChangeText={setSource}
                    autoCapitalize="none"
                    autoCorrect={false}
                    placeholder="https://github.com/user/vega-providers"
                    placeholderTextColor={colors.onSurfaceVariant}
                    style={{flex: 1, minHeight: 46, borderRadius: 12, paddingHorizontal: 12, color: colors.onSurface, backgroundColor: colors.surfaceContainerHighest}}
                  />
                  <IconButton icon="download" label="Load source" buttonSize={46} onPress={refresh} contentColor={colors.primary} />
                </View>
              </View>
            </SettingsSection>

            <SettingsSection title="Installed Vega Plugins">
              {installed.length === 0 ? (
                <View style={{padding: 16}}><AppText role="bodyMedium" style={{color: colors.onSurfaceVariant}}>No Vega plugins installed.</AppText></View>
              ) : installed.map(plugin => (
                <View key={`${plugin.source.author}:${plugin.value}`} style={{flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderBottomColor: colors.outlineVariant}}>
                  {plugin.icon ? <Image source={{uri: plugin.icon}} style={{width: 42, height: 42, borderRadius: 10, marginRight: 12}} /> : <MaterialCommunityIcons name="puzzle-outline" size={34} color={colors.primary} style={{marginRight: 12}} />}
                  <View style={{flex: 1}}>
                    <AppText role="titleMediumEmphasized" style={{color: colors.onSurface}}>{plugin.display_name}</AppText>
                    <AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 2}}>{plugin.source.author} · v{plugin.version}</AppText>
                  </View>
                  <CompactSwitch accessibilityLabel={`Enable ${plugin.display_name}`} value={vegaPluginManager.isEnabled(plugin.value)} onValueChange={() => toggle(plugin)} />
                  <IconButton icon="delete-outline" label={`Remove ${plugin.display_name}`} buttonSize={40} onPress={() => remove(plugin)} contentColor={colors.error} />
                </View>
              ))}
            </SettingsSection>
          </View>
        }
        renderItem={({item}) => {
          const key = `${item.source.author}:${item.value}`;
          const isInstalled = installedIds.has(key);
          return (
            <View style={{flexDirection: 'row', alignItems: 'center', padding: 14, marginBottom: 8, borderRadius: 16, backgroundColor: colors.surfaceContainerHighest}}>
              {item.icon ? <Image source={{uri: item.icon}} style={{width: 44, height: 44, borderRadius: 10, marginRight: 12}} /> : <MaterialCommunityIcons name="puzzle-outline" size={36} color={colors.primary} style={{marginRight: 12}} />}
              <View style={{flex: 1}}>
                <AppText role="titleMediumEmphasized" style={{color: colors.onSurface}}>{item.display_name}</AppText>
                <AppText role="bodySmall" style={{color: colors.onSurfaceVariant}}>v{item.version}</AppText>
              </View>
              <IconButton icon={isInstalled ? 'check' : 'download-outline'} label={isInstalled ? 'Installed' : `Install ${item.display_name}`} buttonSize={42} onPress={() => !isInstalled && install(item)} contentColor={isInstalled ? colors.onSurfaceVariant : colors.primary} disabled={isInstalled} />
            </View>
          );
        }}
        ListEmptyComponent={<View style={{padding: 18}}><AppText role="bodyMedium" style={{color: colors.onSurfaceVariant}}>Load a Vega provider repository above to see available plugins.</AppText></View>}
      />
    </View>
  );
};

export default VegaPlugins;

import React, {useCallback, useState} from 'react';
import {Pressable, TextInput, ToastAndroid, View} from 'react-native';
import {useFocusEffect} from '@react-navigation/native';
import {MaterialCommunityIcons} from '@expo/vector-icons';
import {settingsStorage} from '../../../lib/storage';
import {DOH_PROVIDERS, DohProviderValue, syncDohSettings} from '../../../lib/services/dohService';
import {useM3Colors} from '../../../theme/M3PaletteContext';
import {withAlpha} from '../../../theme/glass';
import AppText from '../../../components/ui/Text';
import DropdownField from '../../../components/ui/DropdownField';

const isValidCustomResolver = (value: string) => {
  try {
    const url = new URL(value.trim());
    return url.protocol === 'https:' || url.protocol === 'http:';
  } catch {
    return false;
  }
};

const DnsPreference = () => {
  const colors = useM3Colors();
  const [provider, setProvider] = useState<DohProviderValue>(() => {
    const stored = settingsStorage.getDohProvider() as DohProviderValue;
    return settingsStorage.isDohEnabled() && DOH_PROVIDERS.some(item => item.value === stored)
      ? stored
      : 'off';
  });
  const [customUrl, setCustomUrl] = useState(settingsStorage.getDohCustomUrl());
  const [applying, setApplying] = useState(false);

  useFocusEffect(
    useCallback(() => {
      const stored = settingsStorage.getDohProvider() as DohProviderValue;
      setProvider(
        settingsStorage.isDohEnabled() && DOH_PROVIDERS.some(item => item.value === stored)
          ? stored
          : 'off',
      );
      setCustomUrl(settingsStorage.getDohCustomUrl());
      void syncDohSettings().catch(error =>
        console.warn('[DoH] Failed to restore provider:', error),
      );
    }, []),
  );

  const selectProvider = useCallback(async (value: DohProviderValue) => {
    const previousProvider = provider;
    if (value === 'custom') {
      setProvider('custom');
      settingsStorage.setDohProvider('custom');
      return;
    }
    setApplying(true);
    try {
      settingsStorage.setDohProvider(value);
      settingsStorage.setDohEnabled(value !== 'off');
      await syncDohSettings();
      setProvider(value);
      ToastAndroid.show(
        value === 'off' ? 'DNS over HTTPS disabled' : 'DNS over HTTPS applied',
        ToastAndroid.SHORT,
      );
    } catch (error) {
      console.warn('[DoH] Failed to apply provider:', error);
      setProvider(previousProvider);
      ToastAndroid.show('Failed to apply DNS setting', ToastAndroid.SHORT);
    } finally {
      setApplying(false);
    }
  }, [provider]);

  const saveCustomUrl = useCallback(async () => {
    const trimmed = customUrl.trim();
    if (!isValidCustomResolver(trimmed)) {
      ToastAndroid.show('Enter a valid HTTP/HTTPS DNS resolver URL', ToastAndroid.SHORT);
      return;
    }
    try {
      settingsStorage.setDohCustomUrl(trimmed);
      settingsStorage.setDohProvider('custom');
      settingsStorage.setDohEnabled(true);
      setProvider('custom');
      await syncDohSettings();
      ToastAndroid.show('Custom DNS applied', ToastAndroid.SHORT);
    } catch (error) {
      console.warn('[DoH] Failed to apply custom URL:', error);
      ToastAndroid.show('Failed to apply custom DNS', ToastAndroid.SHORT);
    }
  }, [customUrl]);

  return (
    <View style={{padding: 12}}>
      <View style={{flexDirection: 'row', alignItems: 'center', marginBottom: 10}}>
        <View
          style={{
            width: 40,
            height: 40,
            marginRight: 0,
            borderRadius: 13,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: withAlpha(colors.primary, 0.18),
          }}>
          <MaterialCommunityIcons name="dns-outline" size={21} color={colors.primary} />
        </View>
        <View style={{marginLeft: 11, flex: 1}}>
          <AppText role="bodyLargeEmphasized" style={{color: colors.onSurface}}>DNS over HTTPS</AppText>
          <AppText role="bodySmall" style={{color: colors.onSurfaceVariant, marginTop: 1}}>
            Select a resolver. The choice is saved and applied to addon/network requests.
          </AppText>
        </View>
      </View>

      <View style={{marginTop: 4}}>
        <AppText role="labelLarge" style={{color: colors.onSurfaceVariant, marginBottom: 6}}>
          DNS PROVIDER
        </AppText>
        <DropdownField
          options={DOH_PROVIDERS}
          value={DOH_PROVIDERS.find(item => item.value === provider) || DOH_PROVIDERS[0]}
          getKey={item => item.value}
          getLabel={item => item.label}
          onChange={item => void selectProvider(item.value)}
          disabled={applying}
          showFullOptionLabels
        />
      </View>

      {provider === 'custom' && (
        <View style={{marginTop: 14}}>
          <AppText role="labelLarge" style={{color: colors.onSurfaceVariant, marginBottom: 6}}>
            Custom resolver URL
          </AppText>
          <TextInput
            value={customUrl}
            onChangeText={setCustomUrl}
            onSubmitEditing={() => void saveCustomUrl()}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="url"
            placeholder="https://dns.example/dns-query"
            placeholderTextColor={colors.onSurfaceVariant}
            style={{
              borderRadius: 16,
              backgroundColor: colors.surfaceContainerHigh,
              borderWidth: 1,
              borderColor: colors.outlineVariant,
              color: colors.onSurface,
              paddingHorizontal: 14,
              paddingVertical: 12,
            }}
          />
          <Pressable
            accessibilityRole="button"
            onPress={() => void saveCustomUrl()}
            style={{alignSelf: 'flex-end', marginTop: 10, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 16, backgroundColor: colors.primaryContainer}}>
            <AppText role="labelLargeEmphasized" style={{color: colors.onPrimaryContainer}}>
              Apply custom DNS
            </AppText>
          </Pressable>
        </View>
      )}
    </View>
  );
};

export default DnsPreference;

/** Build the video ID used by Stremio stream resources for a series episode. */
export const getStremioEpisodeVideoId = (
  seriesId: string,
  seasonValue: unknown,
  episodeValue: unknown,
  sourceVideoId?: unknown,
): string => {
  const hasSeason = seasonValue !== undefined && seasonValue !== null && seasonValue !== '';
  const hasEpisode = episodeValue !== undefined && episodeValue !== null && episodeValue !== '';
  const season = Number(seasonValue);
  const episode = Number(episodeValue);
  const hasEpisodeNumber =
    hasSeason && hasEpisode &&
    Number.isFinite(season) && season >= 0 &&
    Number.isFinite(episode) && episode >= 0;

  // Stremio's conventional IMDb series video ID is `${imdbId}:${season}:${episode}`.
  // Stream-only providers such as Torrentio depend on this exact identity.
  if (hasEpisodeNumber && /^tt\d+$/i.test(seriesId)) {
    return `${seriesId.toLowerCase()}:${season}:${episode}`;
  }

  const rawId = typeof sourceVideoId === 'string' ? sourceVideoId.trim() : '';
  if (rawId) return rawId;
  if (hasEpisodeNumber) return `${seriesId}:${season}:${episode}`;
  return '';
};

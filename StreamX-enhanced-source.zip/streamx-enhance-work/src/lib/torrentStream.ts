/** Torrent-specific helpers shared by player code and regression tests. */
export const isTorrentStream = (stream?: {
  link?: string;
  type?: string;
  infoHash?: string;
  behaviorHints?: {infoHash?: string; videoHash?: string; p2p?: boolean | string};
}) =>
  String(stream?.type || '').toLowerCase() === 'torrent' ||
  Boolean(stream?.link && /^magnet:/i.test(stream.link)) ||
  Boolean(
    stream?.infoHash ||
    stream?.behaviorHints?.infoHash ||
    stream?.behaviorHints?.videoHash ||
    String(stream?.behaviorHints?.p2p || '').toLowerCase() === 'true'
  );

export interface TorrentVideoFileCandidate {
  index: number;
  name: string;
  size: number;
}

const VIDEO_EXTENSIONS = [
  '.mp4', '.mkv', '.avi', '.webm', '.mov', '.ts', '.flv', '.wmv',
  '.m4v', '.mpeg', '.mpg', '.m2ts', '.ogv', '.3gp', '.mts', '.vob',
];
const KNOWN_NON_VIDEO_EXTENSION =
  /\.(?:srt|ass|ssa|sub|idx|txt|nfo|jpg|jpeg|png|webp|gif|mp3|m4a|flac|aac|wav|zip|rar|7z|sfv|exe)$/i;

/** Prefer the provider's exact file index, otherwise pick the largest video file. */
export const selectTorrentVideoFileIndex = (
  files: TorrentVideoFileCandidate[],
  preferredFileIdx?: number,
): number => {
  if (!Array.isArray(files) || files.length === 0) {
    throw new Error('No files found in torrent');
  }

  if (Number.isFinite(preferredFileIdx)) {
    const preferred = files.find(file => file.index === preferredFileIdx);
    const preferredName = String(preferred?.name || '').split('?')[0].toLowerCase();
    if (
      preferred &&
      !KNOWN_NON_VIDEO_EXTENSION.test(preferredName) &&
      VIDEO_EXTENSIONS.some(extension => preferredName.endsWith(extension))
    ) {
      return preferred.index;
    }
  }

  let bestIndex: number | undefined;
  let bestSize = -1;
  for (const file of files) {
    const name = String(file.name || '').split('?')[0].toLowerCase();
    if (VIDEO_EXTENSIONS.some(extension => name.endsWith(extension)) && Number(file.size) > bestSize) {
      bestIndex = file.index;
      bestSize = Number(file.size) || 0;
    }
  }

  if (bestIndex === undefined) {
    throw new Error('No playable video file found in this torrent');
  }
  return bestIndex;
};

export const isDummyTorrentLink = (link: string) => {
  const normalized = String(link || '').toLowerCase();
  return (
    !normalized ||
    normalized.includes('d41d0cfbf8baa3ce04a7074b0c486243dd5fbd00') ||
    normalized.includes('d41d8cd98f00b204e9800998ecf8427e')
  );
};

export interface ResolveTorrentStreamOptions {
  addTorrent: (link: string) => Promise<{infoHash: string}>;
  findVideoFileIndex: (infoHash: string) => Promise<number>;
  prepareVideoFile: (infoHash: string, fileIndex: number) => Promise<unknown>;
  getStreamUrl: (infoHash: string, fileIndex: number) => Promise<string>;
  onAdded: (infoHash: string) => void;
  isCancelled: () => boolean;
}

/**
 * Resolves the local stream URL without waiting for the first piece. Vega's
 * stream server fetches/prioritizes pieces in response to the player's HTTP
 * range requests; awaiting prepareVideoFile first can deadlock startup because
 * the player has not yet been given a URL to request.
 */
export async function resolveTorrentStream(
  link: string,
  options: ResolveTorrentStreamOptions,
): Promise<{streamUrl: string; preparation: Promise<unknown>} | null> {
  const torrent = await options.addTorrent(link);
  if (options.isCancelled()) return null;
  options.onAdded(torrent.infoHash);

  const fileIndex = await options.findVideoFileIndex(torrent.infoHash);
  if (options.isCancelled()) return null;

  // Start priority preparation, but do not wait for the first-piece promise
  // before obtaining the URL. Attach a rejection handler immediately.
  const preparation = options.prepareVideoFile(torrent.infoHash, fileIndex);
  preparation.catch(() => {});
  const streamUrl = await options.getStreamUrl(torrent.infoHash, fileIndex);
  if (options.isCancelled()) {
    preparation.catch(() => {});
    return null;
  }
  return {streamUrl, preparation};
}

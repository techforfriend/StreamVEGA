import { useQuery } from '@tanstack/react-query';
import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ToastAndroid } from 'react-native';
import { providerManager } from '../services/ProviderManager';
import { cacheStorage, settingsStorage } from '../storage';
import {isPotentiallyPlayableStream, streamMatchesExcludedQuality} from '../streamUtils';
import { ifExists } from '../file/ifExists';
import { Stream } from '../providers/types';
import { getEpisodeIdentity } from '../utils/episodeIdentity';
import useDownloadsStore, {
  isSubtitleDownloadItem,
} from '../zustand/downloadsStore';
import { TextTrackType } from 'react-native-video';
import { downloadOutputExists } from '../downloadDestination';
import {isTorrentStream} from '../torrentStream';

const signalIsAbortError = (error: unknown): boolean => {
  if (!error || typeof error !== 'object') return false;
  const candidate = error as {name?: unknown; code?: unknown; message?: unknown};
  const name = typeof candidate.name === 'string' ? candidate.name : '';
  const code = typeof candidate.code === 'string' ? candidate.code : '';
  const message = typeof candidate.message === 'string' ? candidate.message : '';
  return (
    name === 'AbortError' ||
    name === 'CanceledError' ||
    name === 'CancelledError' ||
    code === 'ERR_CANCELED' ||
    /^(?:aborted|cancelled|canceled)$/i.test(message.trim())
  );
};

interface UseStreamOptions {
  activeEpisode: any;
  routeParams: any;
  provider: string;
  enabled?: boolean;
}

export const isLocalPath = (path?: string): boolean => {
  if (!path || typeof path !== 'string') return false;
  return (
    path.startsWith('content://') ||
    path.startsWith('file://') ||
    path.startsWith('/')
  );
};

export const findDownloadedFileForMedia = async (
  activeEpisode: any,
  routeParams: any,
): Promise<string | null> => {
  if (!activeEpisode) return null;

  // 1. Direct local file path in activeEpisode.link
  if (isLocalPath(activeEpisode.link)) {
    if (await downloadOutputExists(activeEpisode.link)) {
      return activeEpisode.link;
    }
  }

  // 2. Direct local file path in activeEpisode.filePath
  if (isLocalPath(activeEpisode.filePath)) {
    if (await downloadOutputExists(activeEpisode.filePath)) {
      return activeEpisode.filePath;
    }
  }

  // 3. directUrl passed in routeParams when activeEpisode matches initial selection or there is only one episode
  if (routeParams?.directUrl && isLocalPath(routeParams.directUrl)) {
    const isSingleEpisode =
      !routeParams.episodeList || routeParams.episodeList.length <= 1;
    const initialEpisode =
      typeof routeParams.linkIndex === 'number' &&
      routeParams.episodeList?.[routeParams.linkIndex];
    const isInitialEpisode =
      initialEpisode &&
      ((initialEpisode.id &&
        activeEpisode.id &&
        initialEpisode.id === activeEpisode.id) ||
        (initialEpisode.link &&
          activeEpisode.link &&
          initialEpisode.link === activeEpisode.link) ||
        (initialEpisode.sourceLink &&
          activeEpisode.sourceLink &&
          initialEpisode.sourceLink === activeEpisode.sourceLink) ||
        initialEpisode.title === activeEpisode.title);

    if (
      isSingleEpisode ||
      isInitialEpisode ||
      activeEpisode.link === routeParams.directUrl
    ) {
      if (await downloadOutputExists(routeParams.directUrl)) {
        return routeParams.directUrl;
      }
    }
  }

  // 4. Match against completed records in downloadsStore
  const allDownloads = Object.values(useDownloadsStore.getState().downloads);
  const completedDownloads = allDownloads.filter(
    item =>
      item.status === 'completed' &&
      Boolean(item.filePath) &&
      !item.isSubtitle &&
      !isSubtitleDownloadItem(item),
  );

  const episodeId = activeEpisode.id;
  const episodeSourceLink = activeEpisode.sourceLink || activeEpisode.link;
  const episodeTitle = activeEpisode.title || activeEpisode.episodeName;
  const primaryTitle = routeParams?.primaryTitle || routeParams?.title;
  const secondaryTitle =
    routeParams?.secondaryTitle || routeParams?.seasonTitle;
  const infoUrl = routeParams?.infoUrl || routeParams?.link;

  for (const d of completedDownloads) {
    // A) ID match
    if (episodeId && (d.id === episodeId || d.id.includes(episodeId))) {
      if (await downloadOutputExists(d.filePath)) {
        return d.filePath;
      }
    }

    // B) Source link match
    if (
      episodeSourceLink &&
      (d.sourceLink === episodeSourceLink ||
        d.url === episodeSourceLink ||
        d.filePath === episodeSourceLink)
    ) {
      if (await downloadOutputExists(d.filePath)) {
        return d.filePath;
      }
    }

    // C) Media title + Season + Episode title match
    const showMatch =
      (infoUrl && d.infoUrl === infoUrl) ||
      (primaryTitle &&
        (d.showName === primaryTitle ||
          d.title === primaryTitle ||
          d.title?.startsWith(primaryTitle)));

    if (showMatch) {
      const seasonMatch =
        !secondaryTitle ||
        !d.seasonTitle ||
        d.seasonTitle === secondaryTitle ||
        secondaryTitle.toLowerCase().includes(d.seasonTitle.toLowerCase()) ||
        d.seasonTitle.toLowerCase().includes(secondaryTitle.toLowerCase());

      const episodeMatch =
        episodeTitle &&
        (d.episodeName === episodeTitle ||
          d.title === episodeTitle ||
          d.title?.includes(episodeTitle) ||
          d.episodeName?.includes(episodeTitle) ||
          episodeTitle.includes(d.episodeName || '___never___'));

      if (seasonMatch && episodeMatch) {
        if (await downloadOutputExists(d.filePath)) {
          return d.filePath;
        }
      }
    }
  }

  // 5. Legacy sanitized local file
  if (primaryTitle) {
    const file = (
      primaryTitle +
      (secondaryTitle || '') +
      (episodeTitle || '')
    ).replaceAll(/[^a-zA-Z0-9]/g, '_');

    const exists = await ifExists(file);
    if (exists) {
      return exists;
    }
  }

  return null;
};

export const getDownloadedSubtitlesForMedia = (
  activeEpisode: any,
  routeParams: any,
) => {
  const allDownloads = Object.values(useDownloadsStore.getState().downloads);

  const downloadedSubs = allDownloads.filter(item => {
    if (item.status !== 'completed' || !item.filePath) {
      return false;
    }
    const isSub =
      item.isSubtitle ||
      isSubtitleDownloadItem(item) ||
      item.displayFileName?.endsWith('.vtt') ||
      item.displayFileName?.endsWith('.srt') ||
      item.filePath?.endsWith('.vtt') ||
      item.filePath?.endsWith('.srt');

    if (!isSub) {
      return false;
    }

    const episodeSourceLink = activeEpisode?.sourceLink || activeEpisode?.link;
    if (episodeSourceLink && item.sourceLink === episodeSourceLink) {
      return true;
    }

    const infoUrl = routeParams?.infoUrl || routeParams?.link;
    if (infoUrl && item.infoUrl === infoUrl) {
      if (
        !activeEpisode?.title ||
        item.episodeName === activeEpisode.title ||
        item.title?.includes(activeEpisode.title)
      ) {
        return true;
      }
    }

    const primaryTitle = routeParams?.primaryTitle || routeParams?.title;
    if (
      primaryTitle &&
      (item.showName === primaryTitle || item.title?.startsWith(primaryTitle))
    ) {
      if (
        !activeEpisode?.title ||
        item.episodeName === activeEpisode.title ||
        item.title?.includes(activeEpisode.title)
      ) {
        return true;
      }
    }

    if (routeParams?.directUrl) {
      const videoBase = routeParams.directUrl.substring(
        0,
        routeParams.directUrl.lastIndexOf('.'),
      );
      if (videoBase && item.filePath.startsWith(videoBase)) {
        return true;
      }
    }

    return false;
  });

  return downloadedSubs.map(sub => {
    const isVtt =
      sub.videoType === 'vtt' ||
      sub.filePath?.endsWith('.vtt') ||
      sub.displayFileName?.endsWith('.vtt');
    const uri =
      sub.filePath.startsWith('file://') ||
        sub.filePath.startsWith('content://')
        ? sub.filePath
        : `file://${sub.filePath}`;

    let title = sub.episodeName || sub.title;
    let language = 'en';
    const match =
      sub.title.match(/subtitle\s+([a-zA-Z]+)/i) ||
      sub.id.match(/_subtitle_(.+)$/);
    if (match) {
      title = match[1];
      language = match[1];
    }

    return {
      type: isVtt ? TextTrackType.VTT : TextTrackType.SUBRIP,
      language,
      title: `${title} (Downloaded)`,
      uri,
    };
  });
};

export const getCompletedDownloadPathSync = (
  episode: any,
  params: any,
): string | null => {
  if (!episode) return null;
  if (isLocalPath(episode.link)) return episode.link;
  if (isLocalPath(episode.filePath)) return episode.filePath;
  if (params?.directUrl && isLocalPath(params.directUrl)) {
    const isSingleEpisode =
      !params.episodeList || params.episodeList.length <= 1;
    const initialEpisode =
      typeof params.linkIndex === 'number' &&
      params.episodeList?.[params.linkIndex];
    const isInitialEpisode =
      initialEpisode &&
      ((initialEpisode.id &&
        episode.id &&
        initialEpisode.id === episode.id) ||
        (initialEpisode.link &&
          episode.link &&
          initialEpisode.link === episode.link) ||
        (initialEpisode.sourceLink &&
          episode.sourceLink &&
          initialEpisode.sourceLink === episode.sourceLink) ||
        initialEpisode.title === episode.title);
    if (
      isSingleEpisode ||
      isInitialEpisode ||
      episode.link === params.directUrl
    ) {
      return params.directUrl;
    }
  }
  const allDownloads = Object.values(useDownloadsStore.getState().downloads);
  const completed = allDownloads.find(
    d =>
      d.status === 'completed' &&
      Boolean(d.filePath) &&
      !d.isSubtitle &&
      !isSubtitleDownloadItem(d) &&
      ((episode.id && (d.id === episode.id || d.id.includes(episode.id))) ||
        (episode.link &&
          (d.sourceLink === episode.link ||
            d.url === episode.link ||
            d.filePath === episode.link)) ||
        (episode.sourceLink &&
          (d.sourceLink === episode.sourceLink ||
            d.url === episode.sourceLink ||
            d.filePath === episode.sourceLink))),
  );
  return completed?.filePath || null;
};

export const useStream = ({
  activeEpisode,
  routeParams,
  provider,
  enabled = true,
}: UseStreamOptions) => {
  const [selectedStream, setSelectedStreamState] = useState<Stream>({
    server: '',
    link: '',
    type: '',
  });
  const [externalSubs, setExternalSubs] = useState<any[]>([]);


  const activeEpisodeKey = getEpisodeIdentity(activeEpisode);
  const previousEpisodeKeyRef = useRef(activeEpisodeKey);
  const forceRefreshRef = useRef(false);
  const rememberedStreamKey = useMemo(() => `lastStream:${provider}:${activeEpisodeKey || routeParams?.infoUrl || routeParams?.link || ''}`, [activeEpisodeKey, provider, routeParams?.infoUrl, routeParams?.link]);
  const setSelectedStream = useCallback((next: Stream | ((current: Stream) => Stream)) => {
    setSelectedStreamState(current => {
      const resolved = typeof next === 'function' ? next(current) : next;
      if (resolved?.link && resolved.type !== 'local') {
        try { cacheStorage.setString(rememberedStreamKey, JSON.stringify(resolved)); } catch {}
      }
      return resolved;
    });
  }, [rememberedStreamKey]);

  useEffect(() => {
    if (previousEpisodeKeyRef.current === activeEpisodeKey) {
      return;
    }
    previousEpisodeKeyRef.current = activeEpisodeKey;
    setSelectedStreamState({ server: '', link: '', type: '' });
  }, [activeEpisodeKey]);

  const localPlaceholder = useMemo(() => {
    const path = getCompletedDownloadPathSync(activeEpisode, routeParams);
    return path
      ? [{ server: 'Downloaded', link: path, type: 'mp4' }]
      : undefined;
  }, [activeEpisode, routeParams]);

  const {
    data: streamData = [],
    isLoading,
    isFetching,
    error,
    refetch,
  } = useQuery<Stream[], Error>({
    queryKey: [
      'stream',
      activeEpisode?.id || activeEpisode?.link || activeEpisode?.title,
      activeEpisode?.sourceLink,
      routeParams?.infoUrl,
      routeParams?.type,
      routeParams?.providerValue,
      routeParams?.directStream?.link,
      provider,
    ],
    queryFn: async ({signal}) => {
      if (
        !activeEpisode?.link &&
        !activeEpisode?.sourceLink &&
        !activeEpisode?.id &&
        !activeEpisode?.title
      ) {
        return [];
      }

      console.log('Fetching stream for:', activeEpisode);

      // 1. Check for downloaded content first
      const downloadedPath = await findDownloadedFileForMedia(
        activeEpisode,
        routeParams,
      );
      const localStream: Stream | null = downloadedPath
        ? { server: 'Downloaded', link: downloadedPath, type: 'mp4' }
        : null;

      const directStream = routeParams?.directStream as Stream | undefined;
      if (directStream?.link && !isLocalPath(directStream.link)) {
        const excludedQualities = settingsStorage.getExcludedQualities() || [];
        const p2pAllowed = settingsStorage.isP2PStreamingEnabled();
        const directPlayable =
          (p2pAllowed || !isTorrentStream(directStream)) &&
          isPotentiallyPlayableStream(directStream) &&
          !streamMatchesExcludedQuality(directStream, excludedQualities);
        if (directPlayable) {
          return localStream ? [localStream, directStream] : [directStream];
        }
        if (localStream) return [localStream];
        // A malformed or excluded direct URL should not prevent the normal
        // provider pipeline from locating another valid stream for this item.
      }

      const remoteLinkValue =
        (!isLocalPath(activeEpisode?.link) && activeEpisode?.link) ||
        activeEpisode?.sourceLink;
      const remoteLink = typeof remoteLinkValue === 'string' ? remoteLinkValue.trim() : '';

      if (!remoteLink) {
        if (localStream) {
          return [localStream];
        }
        if (isLocalPath(activeEpisode?.link)) {
          throw new Error('Downloaded file not found on device');
        }
        return [];
      }

      // 2. Fetch streams from provider online (in background if localStream exists)
      let remoteStreams: Stream[] = [];
      try {
        const data = await providerManager.getStream({
          link: remoteLink,
          type: routeParams?.type,
          signal,
          providerValue: routeParams?.providerValue || provider,
          forceRefresh: forceRefreshRef.current,
        });

        // Filter out excluded qualities
        const excludedQualities = settingsStorage.getExcludedQualities() || [];
        const p2pAllowed = settingsStorage.isP2PStreamingEnabled();
        // Treat provider responses as untrusted: malformed/non-array payloads must not
        // crash the player, and invalid stream entries should never reach the UI/player.
        // Enforce the P2P toggle here as well as in the Stremio manager so direct
        // streams and Vega providers cannot accidentally bypass the user's setting.
        const candidates = Array.isArray(data) ? data : [];
        remoteStreams = candidates.filter(
          streamItem =>
            (p2pAllowed || !isTorrentStream(streamItem)) &&
            isPotentiallyPlayableStream(streamItem) &&
            !streamMatchesExcludedQuality(streamItem, excludedQualities),
        );
      } catch (err) {
        if (localStream) {
          console.warn(
            'Remote stream refresh failed; using local downloaded file:',
            err,
          );
          return [localStream];
        }
        throw err;
      }

      let finalStreams = remoteStreams;
      if (localStream) {
        finalStreams = [localStream, ...remoteStreams];
      }

      if (!finalStreams || finalStreams.length === 0) {
        if (localStream) {
          return [localStream];
        }
        throw new Error('No streams available');
      }

      return finalStreams;
    },
    enabled:
      enabled &&
      Boolean(
        activeEpisode?.link || activeEpisode?.sourceLink || activeEpisode?.id || activeEpisode?.title,
      ),
    placeholderData: localPlaceholder,
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 30 * 60 * 1000, // 30 minutes
    retry: (failureCount, queryError) => {
      // Do not retry cancellations/navigation-away; retry transient provider/network failures.
      if (
        signalIsAbortError(queryError) ||
        /\b4\d{2}\b/.test(queryError?.message || '') ||
        /captcha|waf/i.test(queryError?.message || '') ||
        failureCount >= 2
      ) {
        return false;
      }
      return true;
    },
    retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 10000),
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });

  // A manual retry must bypass provider-side stream caches. Keep the force
  // flag active for the full retry cycle, then reset it even on cancellation.
  const refetchStreams = useCallback(async () => {
    forceRefreshRef.current = true;
    try {
      return await refetch();
    } finally {
      forceRefreshRef.current = false;
    }
  }, [refetch]);

  const isStreamLoading =
    isLoading || (isFetching && (!streamData || streamData.length === 0));

  // Update selected stream when data changes
  useEffect(() => {
    if (streamData && streamData.length > 0) {
      setSelectedStreamState(current => {
        if (current?.type === 'local') return current;
        try {
          const raw = cacheStorage.getString(rememberedStreamKey);
          if (raw) {
            const parsed = JSON.parse(raw) as Stream;
            const matching = streamData.find(s => s.link === parsed?.link);
            if (matching) return matching;
          }
        } catch {}
        if (!current?.link) return streamData[0];
        const stillExists = streamData.find(s => s.link === current.link);
        return stillExists ? current : streamData[0];
      });
    }
  }, [rememberedStreamKey, streamData]);

  // Extract downloaded and online external subtitles
  useEffect(() => {
    const downloadedSubs = getDownloadedSubtitlesForMedia(
      activeEpisode,
      routeParams,
    );

    const onlineSubs: any[] = [];
    if (streamData && streamData.length > 0) {
      streamData.forEach(track => {
        if (track?.subtitles?.length && track.subtitles.length > 0) {
          onlineSubs.push(...track.subtitles);
        }
      });
    }

    const mergedSubs = [...downloadedSubs];
    onlineSubs.forEach(online => {
      const trimmedUri = typeof online?.uri === 'string' ? online.uri.trim() : '';
      if (
        trimmedUri &&
        (trimmedUri.startsWith('http://') ||
          trimmedUri.startsWith('https://') ||
          trimmedUri.startsWith('file://') ||
          trimmedUri.startsWith('content://')) &&
        !mergedSubs.some(existing => existing.uri === trimmedUri)
      ) {
        mergedSubs.push({
          ...online,
          uri: trimmedUri,
        });
      }
    });

    setExternalSubs(prev => {
      const prevKey = prev.map((s: any) => s.uri || '').join('|');
      const nextKey = mergedSubs.map((s: any) => s.uri || '').join('|');
      return prevKey === nextKey ? prev : mergedSubs;
    });
  }, [streamData, activeEpisodeKey]);

  // Handle errors
  useEffect(() => {
    if (error && !signalIsAbortError(error)) {
      console.error('Stream fetch error:', error);
      const errorMessage = error?.message || 'No stream found, try again later';
      ToastAndroid.show(errorMessage, ToastAndroid.SHORT);
    }
  }, [error]);

  const switchToNextStream = () => {
    if (streamData && streamData.length > 0) {
      const currentIndex = streamData.findIndex(
        stream => stream?.link === selectedStream?.link,
      );
      if (currentIndex >= 0 && currentIndex < streamData.length - 1) {
        setSelectedStream(streamData[currentIndex + 1]);
        ToastAndroid.show(
          'Video could not be played, Trying next server',
          ToastAndroid.SHORT,
        );
        return true;
      }
    }
    return false;
  };

  return {
    streamData,
    selectedStream,
    setSelectedStream,
    externalSubs,
    setExternalSubs,
    isLoading: isStreamLoading,
    error,
    refetch: refetchStreams,
    switchToNextStream,
  };
};

const audioTrackListKey = (tracks: any[]): string =>
  tracks
    .map(
      track =>
        `${track.index}-${track.title}-${track.language}-${track.selected}`,
    )
    .join('|');

const textTrackListKey = (tracks: any[]): string =>
  tracks
    .map(
      track =>
        `${track.index}-${track.title}-${track.language}-${track.uri}-${track.selected}`,
    )
    .join('|');

const videoTrackListKey = (tracks: any[]): string =>
  tracks
    .map(
      track =>
        `${track.index}-${track.trackId}-${track.width}x${track.height}-${track.bitrate}-${track.selected}`,
    )
    .join('|');

// Hook for managing video tracks and settings
export const useVideoSettings = () => {
  const [audioTracks, setAudioTracks] = useState<any[]>([]);
  const [textTracks, _setTextTracks] = useState<any[]>([]);
  const [videoTracks, setVideoTracks] = useState<any[]>([]);

  const setTextTracks = useCallback((tracksOrFn: any) => {
    _setTextTracks(previous => {
      const next =
        typeof tracksOrFn === 'function' ? tracksOrFn(previous) : tracksOrFn;
      if (!Array.isArray(next)) return next;
      return textTrackListKey(previous) === textTrackListKey(next)
        ? previous
        : next;
    });
  }, []);

  const [loadedVideoSize, setLoadedVideoSize] = useState<{
    width: number;
    height: number;
  } | null>(null);

  const [selectedAudioTrackIndex, setSelectedAudioTrackIndex] = useState(0);
  const [selectedTextTrackIndex, setSelectedTextTrackIndex] = useState(1000);
  const [selectedQualityIndex, setSelectedQualityIndex] = useState(1000);

  const processAudioTracks = useCallback((tracks: any[]) => {
    const uniqueMap = new Map();
    tracks.forEach(track => {
      const key = `${track.type}-${track.title}-${track.language}`;
      const existingTrack = uniqueMap.get(key);

      if (!existingTrack) {
        uniqueMap.set(key, track);
        return;
      }

      if (track.selected && !existingTrack.selected) {
        uniqueMap.set(key, { ...existingTrack, ...track, selected: true });
      }
    });

    const uniqueTracks = Array.from(uniqueMap.values());
    const selectedIndex = uniqueTracks.findIndex(track => track.selected);

    setAudioTracks(previous =>
      audioTrackListKey(previous) === audioTrackListKey(uniqueTracks)
        ? previous
        : uniqueTracks,
    );
    if (selectedIndex !== -1) {
      setSelectedAudioTrackIndex(selectedIndex);
    }
  }, []);

  const processVideoTracks = useCallback((tracks: any[]) => {
    if (!tracks || tracks.length === 0) {
      return;
    }
    const uniqueMap = new Map();
    const uniqueTracks = tracks.filter(track => {
      const key = `bitrate-${track.bitrate}-quality-${track.height || track.width}`;
      if (!uniqueMap.has(key)) {
        uniqueMap.set(key, true);
        return true;
      }
      return false;
    });
    uniqueTracks.sort(
      (a, b) =>
        (b.height || 0) - (a.height || 0) ||
        (b.bitrate || 0) - (a.bitrate || 0),
    );

    const activeTrack = uniqueTracks.find((t: any) => t.selected);
    if (activeTrack && activeTrack.height) {
      setLoadedVideoSize(prev =>
        prev?.height === activeTrack.height && prev?.width === activeTrack.width
          ? prev
          : { width: activeTrack.width || 0, height: activeTrack.height },
      );
    }

    setVideoTracks(previous =>
      videoTrackListKey(previous) === videoTrackListKey(uniqueTracks)
        ? previous
        : uniqueTracks,
    );
  }, []);

  const handleVideoLoad = useCallback(
    (naturalSize?: { width?: number; height?: number }) => {
      if (!naturalSize?.height) {
        return;
      }
      setLoadedVideoSize({
        width: naturalSize.width ?? 0,
        height: naturalSize.height ?? 0,
      });
    },
    [],
  );

  // Clear everything when switching to a new stream/episode.
  const resetVideoTracks = useCallback(() => {
    setVideoTracks([]);
    setLoadedVideoSize(null);
  }, []);

  return {
    audioTracks,
    textTracks,
    videoTracks,
    loadedVideoSize,
    selectedAudioTrackIndex,
    selectedTextTrackIndex,
    selectedQualityIndex,
    setAudioTracks,
    setTextTracks,
    setVideoTracks,
    setSelectedAudioTrackIndex,
    setSelectedTextTrackIndex,
    setSelectedQualityIndex,
    processAudioTracks,
    processVideoTracks,
    handleVideoLoad,
    resetVideoTracks,
  };
};

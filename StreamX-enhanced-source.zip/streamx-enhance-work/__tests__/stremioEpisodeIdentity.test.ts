import {getStremioEpisodeVideoId} from '../src/lib/stremioEpisodeIdentity';

describe('Stremio episode video IDs', () => {
  it('uses canonical IMDb season/episode IDs for stream-only add-ons such as Torrentio', () => {
    expect(getStremioEpisodeVideoId('tt1234567', 2, 4, '2:4')).toBe('tt1234567:2:4');
    expect(getStremioEpisodeVideoId('TT1234567', '1', '3', 'custom-id')).toBe('tt1234567:1:3');
  });

  it('preserves non-IMDb video IDs supplied by metadata sources', () => {
    expect(getStremioEpisodeVideoId('my-addon:series:7', 1, 2, 'custom-video-id')).toBe('custom-video-id');
  });

  it('uses a stable generated ID when the source omits a video ID', () => {
    expect(getStremioEpisodeVideoId('my-series', 0, 1)).toBe('my-series:0:1');
    expect(getStremioEpisodeVideoId('my-series', undefined, undefined)).toBe('');
  });
});

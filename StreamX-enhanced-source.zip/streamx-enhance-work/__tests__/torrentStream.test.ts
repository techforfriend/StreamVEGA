import {isDummyTorrentLink, isTorrentStream, resolveTorrentStream, selectTorrentVideoFileIndex} from '../src/lib/torrentStream';

describe('torrent stream lifecycle', () => {
  it('recognizes torrent sources and rejects dummy hashes', () => {
    expect(isTorrentStream({type: 'torrent', link: 'https://example.test/a.torrent'})).toBe(true);
    expect(isTorrentStream({link: 'magnet:?xt=urn:btih:abc'})).toBe(true);
    expect(isTorrentStream({infoHash: '0123456789012345678901234567890123456789'})).toBe(true);
    expect(isTorrentStream({type: 'http', link: 'https://example.test/video.mp4'})).toBe(false);
    expect(isDummyTorrentLink('')).toBe(true);
    expect(isDummyTorrentLink('magnet:?xt=urn:btih:d41d8cd98f00b204e9800998ecf8427e')).toBe(true);
    expect(isDummyTorrentLink('magnet:?xt=urn:btih:0123456789012345678901234567890123456789')).toBe(false);
  });


  it('prefers the requested video file index in a multi-file torrent', () => {
    const files = [
      {index: 0, name: 'Show.S02E04.srt', size: 1200},
      {index: 1, name: 'Show.S02E04.mkv', size: 900_000_000},
      {index: 2, name: 'Show.S02E05.mkv', size: 1_200_000_000},
    ];
    expect(selectTorrentVideoFileIndex(files, 1)).toBe(1);
    expect(selectTorrentVideoFileIndex(files)).toBe(2);
  });

  it('rejects torrents with no playable video file instead of selecting file zero', () => {
    expect(() => selectTorrentVideoFileIndex([
      {index: 0, name: 'subtitle.srt', size: 1200},
      {index: 1, name: 'readme.txt', size: 400},
    ])).toThrow('No playable video file found in this torrent');
  });

  it('returns the stream URL without waiting for first-piece preparation', async () => {
    let resolvePreparation!: (value: unknown) => void;
    const preparation = new Promise<unknown>(resolve => { resolvePreparation = resolve; });
    const options = {
      addTorrent: jest.fn().mockResolvedValue({infoHash: 'a'.repeat(40)}),
      findVideoFileIndex: jest.fn().mockResolvedValue(2),
      prepareVideoFile: jest.fn().mockReturnValue(preparation),
      getStreamUrl: jest.fn().mockResolvedValue('http://127.0.0.1:8090/stream/hash/2'),
      onAdded: jest.fn(),
      isCancelled: jest.fn().mockReturnValue(false),
    };

    const result = await Promise.race([
      resolveTorrentStream('magnet:?xt=urn:btih:test', options),
      new Promise<never>((_, reject) => setTimeout(() => reject(new Error('URL resolution blocked on piece preparation')), 100)),
    ]);

    expect(result?.streamUrl).toBe('http://127.0.0.1:8090/stream/hash/2');
    expect(options.prepareVideoFile).toHaveBeenCalledWith('a'.repeat(40), 2);
    expect(options.getStreamUrl).toHaveBeenCalledWith('a'.repeat(40), 2);
    resolvePreparation(true);
  });

  it('does not expose a URL if the player is cancelled while resolving it', async () => {
    let cancelled = false;
    const options = {
      addTorrent: jest.fn().mockResolvedValue({infoHash: 'b'.repeat(40)}),
      findVideoFileIndex: jest.fn().mockResolvedValue(0),
      prepareVideoFile: jest.fn().mockResolvedValue(true),
      getStreamUrl: jest.fn().mockImplementation(async () => {
        cancelled = true;
        return 'http://127.0.0.1:8090/stream/hash/0';
      }),
      onAdded: jest.fn(),
      isCancelled: () => cancelled,
    };

    await expect(resolveTorrentStream('magnet:?xt=urn:btih:test', options)).resolves.toBeNull();
  });
});

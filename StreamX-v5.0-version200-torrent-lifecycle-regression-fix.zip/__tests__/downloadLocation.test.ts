import {beforeEach, describe, expect, it, jest} from '@jest/globals';

jest.mock('@dr.pogodin/react-native-fs', () => ({
  pickFile: jest.fn(),
  readDir: jest.fn(),
  exists: jest.fn(),
  mkdir: jest.fn(),
}));

jest.mock('expo-file-system/legacy', () => ({
  StorageAccessFramework: {
    readDirectoryAsync: jest.fn(async () => []),
    requestDirectoryPermissionsAsync: jest.fn(async () => ({
      granted: true,
      directoryUri: 'content://downloads/tree/primary%3AMovies',
    })),
  },
}));

jest.mock('react-native', () => ({
  NativeModules: {},
  Platform: {OS: 'android'},
}));

import {
  ensureDownloadLocationAccess,
  getDownloadLocationDisplayValue,
  parseDownloadLocation,
  resolveSafTreeDisplayName,
  serializeDownloadLocation,
} from '../src/lib/downloadLocation';
import * as FileSystem from 'expo-file-system/legacy';
import {NativeModules} from 'react-native';

const mockReadDirectory = FileSystem.StorageAccessFramework
  .readDirectoryAsync as jest.Mock;
const mockRequestDirectory = FileSystem.StorageAccessFramework
  .requestDirectoryPermissionsAsync as jest.Mock;

describe('Android SAF download location', () => {
  beforeEach(() => {
    mockReadDirectory.mockClear();
    mockRequestDirectory.mockClear();
    delete (NativeModules as any).HttpDownloadModule;
  });

  it('does not activate a legacy raw path', () => {
    expect(
      parseDownloadLocation('/storage/emulated/0/Download/vega'),
    ).toBeNull();
  });

  it('restores a persisted SAF tree', () => {
    const location = {
      type: 'saf' as const,
      uri: 'content://downloads/tree',
      label: 'Downloads',
    };
    expect(parseDownloadLocation(serializeDownloadLocation(location))).toEqual(
      location,
    );
  });

  it('opens SAF when no valid location exists', async () => {
    await expect(ensureDownloadLocationAccess(null)).resolves.toEqual({
      type: 'saf',
      uri: 'content://downloads/tree/primary%3AMovies',
      label: 'Movies',
    });
    expect(mockRequestDirectory).toHaveBeenCalledTimes(1);
  });

  it('does not expose a stored SAF provider ID as the folder label', () => {
    expect(
      getDownloadLocationDisplayValue({
        type: 'saf',
        uri: 'content://com.android.externalstorage.documents/tree/msd%2F1000393198',
        label: 'msd/1000393198',
      }),
    ).toBe('Selected folder');
  });

  it('uses Android provider display name instead of an opaque document ID', async () => {
    (NativeModules as any).HttpDownloadModule = {
      getTreeDisplayName: jest.fn(async () => 'Movies'),
    };
    await expect(
      resolveSafTreeDisplayName(
        'content://com.android.externalstorage.documents/tree/msd%2F1000393198',
      ),
    ).resolves.toBe('Movies');
    expect((NativeModules as any).HttpDownloadModule.getTreeDisplayName)
      .toHaveBeenCalledWith(
        'content://com.android.externalstorage.documents/tree/msd%2F1000393198',
      );
  });

  it('never displays an opaque provider identifier as a folder name', async () => {
    delete (NativeModules as any).HttpDownloadModule;
    await expect(
      resolveSafTreeDisplayName(
        'content://com.android.externalstorage.documents/tree/msd%2F1000393198',
      ),
    ).resolves.toBe('Selected folder');
  });

  it('uses native DocumentsContract validation when Expo directory listing fails', async () => {
    mockReadDirectory.mockRejectedValueOnce(new Error('Provider listing unsupported'));
    (NativeModules as any).HttpDownloadModule = {
      validateTreeUri: jest.fn(async () => ({valid: true, persisted: true})),
    };

    await expect(
      ensureDownloadLocationAccess({
        type: 'saf',
        uri: 'content://downloads/tree/primary%3AMovies',
        label: 'Internal storage/Movies',
      }),
    ).resolves.toEqual({
      type: 'saf',
      uri: 'content://downloads/tree/primary%3AMovies',
      label: 'Internal storage/Movies',
    });
    expect((NativeModules as any).HttpDownloadModule.validateTreeUri)
      .toHaveBeenCalledWith('content://downloads/tree/primary%3AMovies');
    expect(mockReadDirectory).not.toHaveBeenCalled();
  });
});

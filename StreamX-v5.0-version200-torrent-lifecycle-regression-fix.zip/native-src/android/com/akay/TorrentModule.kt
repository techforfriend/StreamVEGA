package com.akay

import android.util.Log
import com.facebook.react.bridge.*
import org.libtorrent4j.*
import org.libtorrent4j.alerts.*
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import java.net.HttpURLConnection
import java.net.URL
import java.io.FileOutputStream

class TorrentModule(reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {

    companion object {
        private const val TAG = "TorrentModule"
        private const val STREAM_STARTUP_BYTES = 8L * 1024L * 1024L
        private var sessionManager: SessionManager? = null
        private var streamServer: TorrentStreamServer? = null
        private val lifecycleLock = Any()
        private val torrentHandles = ConcurrentHashMap<String, TorrentHandle>()
        private val torrentSavePaths = ConcurrentHashMap<String, String>()
        private val torrentOutputPaths = ConcurrentHashMap<String, String>()
        private val streamingTorrentHashes = ConcurrentHashMap.newKeySet<String>()
        // Includes handles that have been added but are still waiting for metadata.
        private val pendingStreamingHashes = ConcurrentHashMap.newKeySet<String>()
        private val pendingStreamingGenerationByHash = ConcurrentHashMap<String, Long>()
        // Invalidates in-flight metadata requests when the player exits or changes streams.
        private val streamingGeneration = AtomicLong(0L)
    }

    override fun getName(): String = "TorrentModule"

    private fun ensureSession(): SessionManager = synchronized(lifecycleLock) {
        sessionManager?.let { if (it.isRunning) return@synchronized it }

        val sm = SessionManager(false)
        val sp = SettingsPack()
        sp.setEnableDht(true)
        sp.setEnableLsd(true)
        sp.listenInterfaces("0.0.0.0:6881,0.0.0.0:6891")
        sp.setDhtBootstrapNodes("router.bittorrent.com:6881,dht.transmissionbt.com:6881,router.utorrent.com:6881,dht.aelitis.com:6881")

        sm.start(SessionParams(sp))
        sessionManager = sm
        Log.d(TAG, "SessionManager started, running=${sm.isRunning}")
        sm
    }

    private fun ensureServer(): TorrentStreamServer = synchronized(lifecycleLock) {
        streamServer?.let { return@synchronized it }
        val server = TorrentStreamServer()
        server.sessionManager = ensureSession()
        server.start()
        streamServer = server
        Log.d(TAG, "Stream server started on port ${server.listeningPort}")
        server
    }

    @ReactMethod
    fun initEngine(promise: Promise) {
        try {
            val sm = ensureSession()
            val server = ensureServer()
            val result = WritableNativeMap().apply {
                putBoolean("running", sm.isRunning)
                putInt("streamPort", server.listeningPort)
            }
            promise.resolve(result)
        } catch (e: Exception) {
            Log.e(TAG, "initEngine failed", e)
            promise.reject("INIT_ERROR", e.message, e)
        }
    }

    @ReactMethod
    fun addTorrent(magnetOrUrl: String, outputFolder: String?, fileName: String?, streaming: Boolean, promise: Promise) {
        val requestGeneration = if (streaming) streamingGeneration.get() else -1L
        Thread {
            var requestListener: AlertListener? = null
            var listenerSession: SessionManager? = null
            var requestSessionForCleanup: SessionManager? = null
            var requestHashForCleanup: String? = null
            var requestWasSubmitted = false
            try {
                val input = magnetOrUrl.trim()
                val isMagnet = input.startsWith("magnet:", ignoreCase = true)
                val isHttpUrl = input.startsWith("http://", ignoreCase = true) ||
                    input.startsWith("https://", ignoreCase = true)
                val initialExpectedHash = extractInfoHash(input)

                val downloadDir = outputFolder
                    ?: (reactApplicationContext.filesDir.absolutePath + "/torrents")
                val downloadDirectory = File(downloadDir)
                downloadDirectory.mkdirs()

                // HTTP(S) torrent links must be downloaded and parsed as .torrent files.
                // Passing an HTTP URL to SessionManager.download(String, ...) makes
                // libtorrent parse it as a magnet URI and fails with an invalid URI.
                val torrentInfo: TorrentInfo? = when {
                    isMagnet -> null
                    isHttpUrl -> {
                        val torrentFile = downloadTorrentFile(input, downloadDirectory)
                        try { TorrentInfo(torrentFile) } finally { torrentFile.delete() }
                    }
                    File(input).isFile -> TorrentInfo(File(input))
                    else -> null
                }
                val expectedHash = initialExpectedHash ?: try {
                    torrentInfo?.infoHash()?.toHex()?.lowercase()
                } catch (_: Exception) { null }
                val actualHashRef = AtomicReference<String?>(expectedHash)
                requestHashForCleanup = expectedHash
                if (streaming && requestGeneration != streamingGeneration.get()) {
                    promise.reject("STREAM_CANCELLED", "Torrent request cancelled because the player was closed")
                    return@Thread
                }

                var sm = ensureSession()
                var server = ensureServer()
                requestSessionForCleanup = sm

                // Check both our Map and the actual C++ session manager
                var existing = if (expectedHash != null) torrentHandles[expectedHash] else null
                if (existing == null && expectedHash != null) {
                    existing = sm.find(Sha1Hash.parseHex(expectedHash))
                    if (existing != null && existing.isValid) {
                        torrentHandles[expectedHash] = existing
                        torrentSavePaths[expectedHash] = downloadDir
                    }
                }

                if (existing != null && existing.isValid) {
                    try {
                        if (existing.status().hasMetadata()) {
                            server.registerTorrent(expectedHash!!, File(downloadDir))
                            if (streaming) {
                                try {
                                    val pieceCount = existing.torrentFile()?.numPieces() ?: 0
                                    for (pieceIndex in 0 until pieceCount) {
                                        if (!existing.havePiece(pieceIndex)) existing.piecePriority(pieceIndex, Priority.IGNORE)
                                    }
                                    streamingTorrentHashes.add(expectedHash)
                                    pendingStreamingHashes.remove(expectedHash)
                                    pendingStreamingGenerationByHash.remove(expectedHash)
                                } catch (priorityError: Exception) {
                                    Log.w(TAG, "Failed to limit existing streaming torrent", priorityError)
                                }
                            }
                            promise.resolve(buildTorrentInfo(existing))
                            return@Thread
                        }
                    } catch (e: Exception) {
                        torrentHandles.remove(expectedHash!!)
                        torrentSavePaths.remove(expectedHash)
                    }
                }

                var addError: String? = null
                val metadataLatch = CountDownLatch(1)

                if (!isMagnet && !isHttpUrl && torrentInfo == null && !Regex("^[a-fA-F0-9]{40}$").matches(input)) {
                    throw IllegalArgumentException("Unsupported torrent link. Use a magnet URI, 40-character info hash, or .torrent URL/file.")
                }

                val listener = object : AlertListener {
                    override fun types(): IntArray? = null
                    override fun alert(alert: Alert<*>) {
                        when (alert) {
                            is AddTorrentAlert -> {
                                if (alert.error().isError) {
                                    addError = alert.error().toString()
                                    metadataLatch.countDown()
                                    return
                                }
                                val th = alert.handle()
                                val alertHash = try { th.infoHash().toHex().lowercase() } catch(_: Exception) { return }
                                if (expectedHash != null && alertHash != expectedHash) return
                                actualHashRef.compareAndSet(null, alertHash)
                                requestHashForCleanup = actualHashRef.get()
                                Log.d(TAG, "Alert: AddTorrentAlert for $alertHash")

                                try {
                                    torrentHandles[alertHash] = th
                                    torrentSavePaths[alertHash] = downloadDir
                                    if (streaming && requestGeneration == streamingGeneration.get()) {
                                        pendingStreamingHashes.add(alertHash)
                                        pendingStreamingGenerationByHash[alertHash] = requestGeneration
                                    }
                                    if (th.status().hasMetadata()) {
                                        metadataLatch.countDown()
                                    }
                                } catch(_: Exception) {}
                            }
                            is MetadataReceivedAlert -> {
                                val alertHash = try { alert.handle().infoHash().toHex().lowercase() } catch(_: Exception) { return }
                                if (expectedHash != null && alertHash != expectedHash) return
                                actualHashRef.compareAndSet(null, alertHash)
                                requestHashForCleanup = actualHashRef.get()
                                if (streaming && requestGeneration == streamingGeneration.get()) {
                                    pendingStreamingHashes.add(alertHash)
                                    pendingStreamingGenerationByHash[alertHash] = requestGeneration
                                }
                                Log.d(TAG, "Alert: MetadataReceivedAlert for $alertHash")
                                metadataLatch.countDown()
                            }
                            is MetadataFailedAlert -> {
                                val alertHash = try { alert.handle().infoHash().toHex().lowercase() } catch(_: Exception) { return }
                                if (expectedHash != null && alertHash != expectedHash) return
                                actualHashRef.compareAndSet(null, alertHash)
                                requestHashForCleanup = actualHashRef.get()
                                Log.d(TAG, "Alert: MetadataFailedAlert for $alertHash")
                                addError = "Failed to fetch torrent metadata"
                                metadataLatch.countDown()
                            }
                            is TorrentErrorAlert -> {
                                val alertHash = try { alert.handle().infoHash().toHex() } catch(_: Exception) { return }
                                if (expectedHash != null && alertHash == expectedHash) {
                                    Log.e(TAG, "Alert: TorrentErrorAlert for $alertHash - ${alert.error().message}")
                                }
                            }
                            is TorrentRemovedAlert -> {
                                val alertHash = try { alert.handle().infoHash().toHex() } catch(_: Exception) { return }
                                if (expectedHash != null && alertHash == expectedHash) {
                                    Log.d(TAG, "Alert: TorrentRemovedAlert for $alertHash")
                                }
                            }
                        }
                    }
                }

                synchronized(lifecycleLock) {
                    // A player cleanup may have stopped the manager after the local
                    // reference was obtained. Reacquire a live session before adding.
                    if (sessionManager !== sm || !sm.isRunning) {
                        sm = ensureSession()
                        server = ensureServer()
                        requestSessionForCleanup = sm
                    }
                    if (streaming && requestGeneration != streamingGeneration.get()) {
                        throw IllegalStateException("STREAM_CANCELLED: player closed before torrent startup")
                    }
                    if (streaming && expectedHash != null) {
                        pendingStreamingHashes.add(expectedHash)
                        pendingStreamingGenerationByHash[expectedHash] = requestGeneration
                    }
                    listenerSession = sm
                    requestListener = listener
                    sm.addListener(listener)
                    requestWasSubmitted = true

                    // Re-check after attaching the listener. A previous request may
                    // have inserted the same torrent while its metadata was pending.
                    // SessionManager.download(magnet) silently returns for a duplicate,
                    // so submitting it again can leave this latch waiting forever.
                    val knownHash = expectedHash
                    val attachedExisting = if (knownHash != null) {
                        try { sm.find(Sha1Hash.parseHex(knownHash)) } catch (_: Exception) { null }
                    } else null
                    if (attachedExisting != null && attachedExisting.isValid) {
                        if (knownHash != null) {
                            torrentHandles[knownHash] = attachedExisting
                            torrentSavePaths[knownHash] = downloadDir
                            actualHashRef.set(knownHash)
                            requestHashForCleanup = knownHash
                        }
                        if (attachedExisting.status().hasMetadata()) {
                            metadataLatch.countDown()
                        } else {
                            try { attachedExisting.resume() } catch (_: Exception) {}
                        }
                        Log.d(TAG, "Reusing existing torrent handle: $knownHash, hasMetadata=${try { attachedExisting.status().hasMetadata() } catch (_: Exception) { false }}")
                    } else {
                        Log.d(TAG, "Starting download: $magnetOrUrl -> $downloadDir")
                        when {
                            isMagnet -> sm.download(input, downloadDirectory, TorrentFlags.AUTO_MANAGED)
                            isHttpUrl || torrentInfo != null -> {
                                val ti = torrentInfo ?: throw IllegalArgumentException("Torrent file could not be parsed")
                                sm.download(ti, downloadDirectory)
                            }
                            Regex("^[a-fA-F0-9]{40}$").matches(input) ->
                                sm.download("magnet:?xt=urn:btih:${input.lowercase()}", downloadDirectory, TorrentFlags.AUTO_MANAGED)
                            else -> throw IllegalArgumentException("Unsupported torrent link. Use a magnet URI, 40-character info hash, or .torrent URL/file.")
                        }
                    }
                }

                Log.d(TAG, "Waiting for metadata (30s timeout)...")
                var gotMetadata = metadataLatch.await(250, TimeUnit.MILLISECONDS)
                var waitedMs = 250
                while (!gotMetadata && waitedMs < 30000 &&
                    !(streaming && requestGeneration != streamingGeneration.get())) {
                    gotMetadata = metadataLatch.await(250, TimeUnit.MILLISECONDS)
                    waitedMs += 250
                }
                Log.d(TAG, "Metadata wait done: gotMetadata=$gotMetadata, waitedMs=$waitedMs, addError=$addError")
                sm.removeListener(listener)
                requestListener = null
                listenerSession = null

                // If the player has exited while metadata was being fetched, do not
                // allow this stale request to resurrect a torrent in the background.
                val finalKnownHash = actualHashRef.get()?.lowercase() ?: expectedHash
                if (streaming && requestGeneration != streamingGeneration.get()) {
                    // Remove only this request's torrent. A newer playback may already
                    // be using the same hash, so never remove a currently active hash.
                    synchronized(lifecycleLock) {
                        if (finalKnownHash != null && !streamingTorrentHashes.contains(finalKnownHash) &&
                            pendingStreamingGenerationByHash[finalKnownHash] == requestGeneration) {
                            removeStreamingHandle(sm, finalKnownHash)
                        }
                    }
                    promise.reject("STREAM_CANCELLED", "Torrent request cancelled because the player was closed")
                    return@Thread
                }

                if (addError != null) {
                    synchronized(lifecycleLock) {
                        if (streaming && finalKnownHash != null && !streamingTorrentHashes.contains(finalKnownHash) &&
                            pendingStreamingGenerationByHash[finalKnownHash] == requestGeneration) {
                            removeStreamingHandle(sm, finalKnownHash)
                        }
                    }
                    promise.reject("ADD_ERROR", addError)
                    return@Thread
                }

                if (!gotMetadata) {
                    synchronized(lifecycleLock) {
                        if (streaming && finalKnownHash != null && !streamingTorrentHashes.contains(finalKnownHash) &&
                            pendingStreamingGenerationByHash[finalKnownHash] == requestGeneration) {
                            removeStreamingHandle(sm, finalKnownHash)
                        }
                    }
                    promise.reject("TIMEOUT", "Timed out waiting for torrent metadata")
                    return@Thread
                }

                val finalHashHex = finalKnownHash
                    ?: return@Thread promise.reject("INVALID_HANDLE", "Could not determine torrent info hash from metadata alerts")
                
                val th = sm.find(Sha1Hash.parseHex(finalHashHex))
                Log.d(TAG, "Found handle for $finalHashHex: valid=${th?.isValid}, hasMetadata=${try { th?.status()?.hasMetadata() } catch(_:Exception) { "error" }}")
                if (th == null || !th.isValid) {
                    synchronized(lifecycleLock) {
                        if (streaming && !streamingTorrentHashes.contains(finalHashHex) &&
                            pendingStreamingGenerationByHash[finalHashHex] == requestGeneration) {
                            removeStreamingHandle(sm, finalHashHex)
                        }
                    }
                    promise.reject("INVALID_HANDLE", "Torrent handle became invalid after addition")
                    return@Thread
                }
                
                try {
                    torrentHandles[finalHashHex] = th
                    torrentSavePaths[finalHashHex] = downloadDir
                    if (th.status().hasMetadata()) {
                        if (fileName != null) {
                            try {
                                val ti = th.torrentFile()
                                if (ti != null) {
                                    var maxIdx = 0
                                    var maxSize = 0L
                                    val fs = ti.files()
                                    for (i in 0 until fs.numFiles()) {
                                        val size = fs.fileSize(i)
                                        if (size > maxSize) {
                                            maxSize = size
                                            maxIdx = i
                                        }
                                    }
                                    if (maxSize > 0) {
                                        val originalPath = fs.filePath(maxIdx)
                                        val ext = File(originalPath).extension
                                        val newName = if (ext.isNotEmpty()) "$fileName.$ext" else fileName
                                        th.renameFile(maxIdx, newName)
                                        torrentOutputPaths[finalHashHex] = File(downloadDir, newName).absolutePath
                                        Log.d(TAG, "Renamed torrent file $originalPath to $newName")
                                    }
                                }
                            } catch (e: Exception) {
                                Log.e(TAG, "Failed to rename torrent file", e)
                            }
                        }
                        
                        if (streaming) {
                            // Streaming torrents must never start downloading the entire movie.
                            // Keep every piece ignored until the HTTP range server explicitly
                            // prioritizes the current playback window.
                            try {
                                val streamingTorrentInfo = th.torrentFile()
                                if (streamingTorrentInfo != null) {
                                    val pieceCount = streamingTorrentInfo.numPieces()
                                    for (pieceIndex in 0 until pieceCount) {
                                        th.piecePriority(pieceIndex, Priority.IGNORE)
                                    }
                                }
                                streamingTorrentHashes.add(finalHashHex)
                                pendingStreamingHashes.remove(finalHashHex)
                                pendingStreamingGenerationByHash.remove(finalHashHex)
                            } catch (priorityError: Exception) {
                                Log.w(TAG, "Failed to set streaming piece priorities", priorityError)
                            }
                        }
                        server.registerTorrent(finalHashHex, File(downloadDir))
                        Log.d(TAG, "Registered torrent with stream server: $finalHashHex, streaming=$streaming")
                    }
                    promise.resolve(buildTorrentInfo(th))
                } catch(e: Exception) {
                    promise.reject("INVALID_HANDLE", "Torrent handle error: ${e.message}")
                }

            } catch (e: Exception) {
                try {
                    val pendingListener = requestListener
                    val targetSession = listenerSession
                    if (pendingListener != null && targetSession != null) {
                        targetSession.removeListener(pendingListener)
                    }
                } catch (_: Exception) {}
                val cleanupHash = requestHashForCleanup
                if (streaming && requestWasSubmitted && cleanupHash != null &&
                    !streamingTorrentHashes.contains(cleanupHash) &&
                    pendingStreamingGenerationByHash[cleanupHash] == requestGeneration) {
                    val requestSession = requestSessionForCleanup
                    if (requestSession != null) {
                        synchronized(lifecycleLock) {
                            if (!streamingTorrentHashes.contains(cleanupHash) &&
                                pendingStreamingGenerationByHash[cleanupHash] == requestGeneration) {
                                removeStreamingHandle(requestSession, cleanupHash)
                            }
                        }
                    }
                }
                Log.e(TAG, "addTorrent failed", e)
                if (e.message?.contains("STREAM_CANCELLED") == true) {
                    promise.reject("STREAM_CANCELLED", "Torrent request cancelled because the player was closed")
                } else {
                    promise.reject("ADD_ERROR", e.message, e)
                }
            }
        }.start()
    }

    @ReactMethod
    fun getStats(infoHash: String, promise: Promise) {
        try {
            val th = try { ensureSession().find(Sha1Hash.parseHex(infoHash)) } catch(e: Exception) { null }
            if (th == null || !th.isValid) {
                promise.reject("NOT_FOUND", "Torrent handle not found or invalid")
                return
            }
            
            val status = try { th.status() } catch(e: Exception) {
                promise.reject("INVALID_HANDLE", "Torrent handle is no longer valid")
                return
            }
            
            val result = WritableNativeMap().apply {
                putString("state", mapState(status.state()))
                putDouble("progress", status.progress().toDouble())
                putDouble("downloadRate", status.downloadRate().toDouble())
                putDouble("uploadRate", status.uploadRate().toDouble())
                putInt("numPeers", status.numPeers())
                putInt("numSeeds", status.numSeeds())
                putDouble("totalDone", status.totalDone().toDouble())
                putDouble("totalWanted", status.totalWanted().toDouble())
                putBoolean("hasMetadata", status.hasMetadata())
            }
            promise.resolve(result)
        } catch (e: Exception) {
            promise.reject("STATS_ERROR", e.message, e)
        }
    }

    @ReactMethod
    fun stopStreamingTorrent(infoHash: String, promise: Promise) {
        try {
            synchronized(lifecycleLock) {
                // Stop only this info-hash. Do not advance the global streaming
                // generation here: stale cleanup for an older player request must not
                // cancel a newer request for a different torrent.
                val sm = sessionManager
                val th = try { sm?.find(Sha1Hash.parseHex(infoHash)) } catch (_: Exception) { null }
                try { th?.pause() } catch (_: Exception) {}
                try { th?.let { sm?.remove(it) } } catch (_: Exception) {}
                try { streamServer?.unregisterTorrent(infoHash) } catch (_: Exception) {}
                torrentHandles.remove(infoHash)
                torrentSavePaths.remove(infoHash)
                torrentOutputPaths.remove(infoHash)
                streamingTorrentHashes.remove(infoHash)
                pendingStreamingHashes.remove(infoHash)
                pendingStreamingGenerationByHash.remove(infoHash)
                if (torrentHandles.isEmpty() && streamingTorrentHashes.isEmpty() && pendingStreamingHashes.isEmpty()) {
                    try { streamServer?.stop() } catch (_: Exception) {}
                    streamServer = null
                    try { sm?.stop() } catch (_: Exception) {}
                    sessionManager = null
                }
            }
            promise.resolve(null)
        } catch (e: Exception) {
            promise.reject("STOP_STREAM_ERROR", e.message, e)
        }
    }

    @ReactMethod
    fun stopAllStreamingTorrents(promise: Promise) {
        try {
            synchronized(lifecycleLock) {
                // Invalidate pending metadata work first, then release active handles.
                streamingGeneration.incrementAndGet()
                val hashes = (streamingTorrentHashes + pendingStreamingHashes).toList()
                hashes.forEach { hash ->
                    val sm = sessionManager
                    val th = try { sm?.find(Sha1Hash.parseHex(hash)) } catch (_: Exception) { null }
                    try { th?.pause() } catch (_: Exception) {}
                    try { th?.let { sm?.remove(it) } } catch (_: Exception) {}
                    try { streamServer?.unregisterTorrent(hash) } catch (_: Exception) {}
                    torrentHandles.remove(hash)
                    torrentSavePaths.remove(hash)
                    torrentOutputPaths.remove(hash)
                    streamingTorrentHashes.remove(hash)
                    pendingStreamingHashes.remove(hash)
                    pendingStreamingGenerationByHash.remove(hash)
                }
                if (streamingTorrentHashes.isEmpty() && pendingStreamingHashes.isEmpty() && torrentHandles.isEmpty()) {
                    try { streamServer?.stop() } catch (_: Exception) {}
                    streamServer = null
                    try { sessionManager?.stop() } catch (_: Exception) {}
                    sessionManager = null
                }
            }
            promise.resolve(null)
        } catch (e: Exception) {
            promise.reject("STOP_STREAMS_ERROR", e.message, e)
        }
    }

    @ReactMethod
    fun getStreamUrl(infoHash: String, fileIndex: Int, promise: Promise) {
        try {
            val server = ensureServer()
            var filename = "video.mp4"
            val th = try { ensureSession().find(Sha1Hash.parseHex(infoHash)) } catch(e: Exception) { null }
            if (th != null && th.isValid) {
                try {
                    val ti = th.torrentFile()
                    filename = ti.files().fileName(fileIndex)
                } catch(e: Exception) {}
            }
            val encodedFilename = java.net.URLEncoder.encode(filename, "UTF-8").replace("+", "%20")
            val url = "http://127.0.0.1:${server.listeningPort}/stream/$infoHash/$fileIndex/$encodedFilename"
            promise.resolve(url)
        } catch (e: Exception) {
            promise.reject("STREAM_ERROR", e.message, e)
        }
    }

    @ReactMethod
    fun prepareVideoFile(infoHash: String, fileIndex: Int, promise: Promise) {
        Thread {
            try {
                Log.d(TAG, "prepareVideoFile: infoHash=$infoHash, fileIndex=$fileIndex")
                val sm = ensureSession()
                val th = sm.find(Sha1Hash.parseHex(infoHash))
                if (th == null || !th.isValid) {
                    promise.reject("NOT_FOUND", "Torrent handle not found or invalid")
                    return@Thread
                }
                
                if (!th.status().hasMetadata()) {
                    promise.reject("NO_METADATA", "No metadata yet")
                    return@Thread
                }
                
                val ti = try { th.torrentFile() } catch(e: Exception) { null }
                if (ti == null) {
                    promise.reject("INVALID_HANDLE", "Torrent handle invalid")
                    return@Thread
                }
                
                val fs = ti.files()
                if (fileIndex >= fs.numFiles() || fileIndex < 0) {
                    promise.reject("INVALID_INDEX", "File index out of bounds")
                    return@Thread
                }
                
                val fileOffset = fs.fileOffset(fileIndex)
                val fileSize = fs.fileSize(fileIndex)
                val pieceLength = ti.pieceLength().toLong()
                val startPiece = (fileOffset / pieceLength).toInt()
                val startupEndOffset = fileOffset + minOf(fileSize, STREAM_STARTUP_BYTES) - 1L
                val startupEndPiece = (startupEndOffset / pieceLength).toInt()

                th.unsetFlags(TorrentFlags.SEQUENTIAL_DOWNLOAD)
                val filePriorities = Priority.array(Priority.IGNORE, fs.numFiles())
                // Do not mark the whole movie as high priority. Streaming is driven
                // by piece-level priorities below so only the playback window downloads.
                filePriorities[fileIndex] = Priority.IGNORE
                th.prioritizeFiles(filePriorities)

                for (pieceIndex in startPiece..startupEndPiece) {
                    if (!th.havePiece(pieceIndex)) {
                        th.piecePriority(pieceIndex, Priority.TOP_PRIORITY)
                        th.setPieceDeadline(pieceIndex, 700 + (pieceIndex - startPiece) * 150)
                    }
                }

                Log.d(
                    TAG,
                    "prepareVideoFile: file=$fileIndex, pieces=$startPiece-$startupEndPiece, startupBytes=${minOf(fileSize, STREAM_STARTUP_BYTES)}"
                )

                var waitCount = 0
                while (th.isValid && waitCount < 3000) {
                    if (th.havePiece(startPiece)) {
                        promise.resolve(true)
                        return@Thread
                    }
                    Thread.sleep(100)
                    waitCount++
                }

                if (!th.isValid) {
                    promise.reject("INVALID_HANDLE", "Torrent handle became invalid while preparing video")
                } else {
                    promise.reject("TIMEOUT", "Timed out waiting for the first video piece")
                }
            } catch (e: Exception) {
                promise.reject("PREPARE_ERROR", e.message, e)
            }
        }.start()
    }

    @ReactMethod
    fun getFiles(infoHash: String, promise: Promise) {
        try {
            val th = try { ensureSession().find(Sha1Hash.parseHex(infoHash)) } catch(e: Exception) { null }
            if (th == null || !th.isValid) {
                promise.reject("NOT_FOUND", "Torrent handle not found or invalid")
                return
            }

            val status = try { th.status() } catch(e: Exception) {
                promise.reject("INVALID_HANDLE", "Torrent handle is no longer valid")
                return
            }

            if (!status.hasMetadata()) {
                promise.reject("NO_METADATA", "Torrent metadata not available")
                return
            }

            val ti = try { th.torrentFile() } catch(e: Exception) { null }
            if (ti == null) {
                promise.reject("INVALID_HANDLE", "Torrent handle invalid")
                return
            }
            val files = WritableNativeArray()
            val fs = ti.files()
            for (i in 0 until fs.numFiles()) {
                val file = WritableNativeMap().apply {
                    putInt("index", i)
                    putString("name", fs.fileName(i))
                    putString("path", fs.filePath(i))
                    putDouble("size", fs.fileSize(i).toDouble())
                }
                files.pushMap(file)
            }
            promise.resolve(files)
        } catch (e: Exception) {
            promise.reject("FILES_ERROR", e.message, e)
        }
    }

    @ReactMethod
    fun pauseTorrent(infoHash: String, promise: Promise) {
        try {
            val th = try { ensureSession().find(Sha1Hash.parseHex(infoHash)) } catch(e: Exception) { null }
            th?.pause()
            promise.resolve(null)
        } catch (e: Exception) {
            promise.reject("PAUSE_ERROR", e.message, e)
        }
    }

    @ReactMethod
    fun resumeTorrent(infoHash: String, promise: Promise) {
        try {
            val th = try { ensureSession().find(Sha1Hash.parseHex(infoHash)) } catch(e: Exception) { null }
            th?.resume()
            promise.resolve(null)
        } catch (e: Exception) {
            promise.reject("RESUME_ERROR", e.message, e)
        }
    }

    @ReactMethod
    fun completeTorrent(infoHash: String, promise: Promise) {
        try {
            val outputPath = torrentOutputPaths[infoHash]
            if (outputPath == null) {
                promise.reject("OUTPUT_NOT_FOUND", "Torrent output path is unavailable")
                return
            }
            val outputFile = File(outputPath)
            if (!outputFile.exists() || outputFile.length() <= 0L) {
                promise.reject("OUTPUT_NOT_FOUND", "Torrent output file is missing")
                return
            }
            val result = WritableNativeMap().apply {
                putBoolean("success", true)
                putString("outputPath", outputFile.absolutePath)
                putString("fileName", outputFile.name)
                putDouble("size", outputFile.length().toDouble())
            }
            promise.resolve(result)
        } catch (e: Exception) {
            promise.reject("COMPLETE_ERROR", e.message, e)
        }
    }

    @ReactMethod
    fun deleteTorrent(infoHash: String, deleteFiles: Boolean, promise: Promise) {
        Log.e(TAG, "deleteTorrent called for infoHash: $infoHash, deleteFiles: $deleteFiles")
        try {
            val sm = ensureSession()
            val th = try { sm.find(Sha1Hash.parseHex(infoHash)) } catch(e: Exception) { null }
            
            val pathsToDelete = mutableListOf<String>()
            val savePath = torrentSavePaths[infoHash]
            torrentOutputPaths[infoHash]?.let { pathsToDelete.add(it) }
            if (deleteFiles && th != null && savePath != null) {
                try {
                    val ti = th.torrentFile()
                    if (ti != null) {
                        val fs = ti.files()
                        for (i in 0 until fs.numFiles()) {
                            // If we renamed the file, we can't easily query th for the new name without extra bindings.
                            // But libtorrent's session remove(th) might not delete files.
                            // We will delete the original file paths.
                            pathsToDelete.add(File(savePath, fs.filePath(i)).absolutePath)
                        }
                    }
                } catch (_: Exception) {}
            }
            
            if (th != null) {
                try { th.pause() } catch (_: Exception) {}
                try { sm.remove(th) } catch (_: Exception) {}
            }
            
            streamServer?.unregisterTorrent(infoHash)
            torrentHandles.remove(infoHash)
            torrentSavePaths.remove(infoHash)
            torrentOutputPaths.remove(infoHash)

            for (path in pathsToDelete) {
                try { 
                    val f = File(path)
                    f.delete()
                    // Delete parent dir if it's empty and not the root savePath
                    val parent = f.parentFile
                    if (parent != null && parent.absolutePath != savePath && parent.list()?.isEmpty() == true) {
                        parent.delete()
                    }
                } catch (_: Exception) {}
            }

            if (torrentHandles.isEmpty()) {
                try { streamServer?.stop() } catch (_: Exception) {}
                streamServer = null
                try { sessionManager?.stop() } catch (_: Exception) {}
                sessionManager = null
            }
            promise.resolve(null)
        } catch (e: Exception) {
            promise.reject("DELETE_ERROR", e.message, e)
        }
    }

    private fun extractInfoHash(value: String): String? {
        val raw = Regex("(?:btih:|^)([a-fA-F0-9]{40})(?:$|[&?#])", RegexOption.IGNORE_CASE)
            .find(value)?.groupValues?.get(1)
        if (raw != null) return raw.lowercase()

        // A magnet may encode the SHA-1 hash in Base32 instead of hexadecimal.
        val base32 = Regex("btih:([A-Z2-7]{32})", RegexOption.IGNORE_CASE)
            .find(value)?.groupValues?.get(1)
        if (base32 != null) return decodeBase32Hex(base32)
        return null
    }

    private fun decodeBase32Hex(value: String): String? {
        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
        var buffer = 0
        var bits = 0
        val bytes = ArrayList<Byte>(20)
        for (char in value.uppercase()) {
            val digit = alphabet.indexOf(char)
            if (digit < 0) return null
            buffer = (buffer shl 5) or digit
            bits += 5
            if (bits >= 8) {
                bits -= 8
                bytes.add(((buffer shr bits) and 0xff).toByte())
            }
        }
        if (bytes.size != 20) return null
        return bytes.joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
    }

    private fun downloadTorrentFile(sourceUrl: String, destinationDir: File): File {
        val file = File(destinationDir, ".streamx-torrent-${Integer.toHexString(sourceUrl.hashCode())}.torrent")
        val connection = (URL(sourceUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "StreamX/5.0")
        }
        try {
            connection.connect()
            val status = connection.responseCode
            if (status !in 200..299) throw IllegalArgumentException("Torrent URL returned HTTP $status")
            var bytesCopied = 0L
            connection.inputStream.use { input ->
                FileOutputStream(file).use { output ->
                    val buffer = ByteArray(8192)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        bytesCopied += read
                        if (bytesCopied > 8L * 1024L * 1024L) {
                            throw IllegalArgumentException("Torrent file is unexpectedly large")
                        }
                        output.write(buffer, 0, read)
                    }
                }
            }
            return file
        } catch (e: Exception) {
            try { file.delete() } catch (_: Exception) {}
            throw e
        } finally {
            connection.disconnect()
        }
    }

    private fun removeStreamingHandle(sm: SessionManager, infoHash: String) {
        try {
            val handle = sm.find(Sha1Hash.parseHex(infoHash))
            if (handle != null && handle.isValid) {
                try { handle.pause() } catch (_: Exception) {}
                try { sm.remove(handle) } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        try { streamServer?.unregisterTorrent(infoHash) } catch (_: Exception) {}
        torrentHandles.remove(infoHash)
        torrentSavePaths.remove(infoHash)
        torrentOutputPaths.remove(infoHash)
        streamingTorrentHashes.remove(infoHash)
        pendingStreamingHashes.remove(infoHash)
        pendingStreamingGenerationByHash.remove(infoHash)
    }

    private fun buildTorrentInfo(th: TorrentHandle): WritableMap {
        val hasMeta = try { th.status().hasMetadata() } catch(e: Exception) { false }
        val infoHash = try { th.infoHash().toHex() } catch(e: Exception) { "" }
        
        val result = WritableNativeMap().apply {
            putString("infoHash", infoHash)
            putBoolean("hasMetadata", hasMeta)
        }

        if (hasMeta) {
            try {
                val ti = th.torrentFile()
                if (ti != null) {
                    result.putString("name", ti.name())
                    result.putDouble("totalSize", ti.totalSize().toDouble())
        
                    val files = WritableNativeArray()
                    val fs = ti.files()
                    for (i in 0 until fs.numFiles()) {
                        val file = WritableNativeMap().apply {
                            putInt("index", i)
                            putString("name", fs.fileName(i))
                            putString("path", fs.filePath(i))
                            putDouble("size", fs.fileSize(i).toDouble())
                        }
                        files.pushMap(file)
                    }
                    result.putArray("files", files)
                }
            } catch(e: Exception) {}
        }
        return result
    }

    private fun mapState(state: TorrentStatus.State): String {
        return when (state) {
            TorrentStatus.State.CHECKING_FILES -> "checking"
            TorrentStatus.State.DOWNLOADING_METADATA -> "metadata"
            TorrentStatus.State.DOWNLOADING -> "downloading"
            TorrentStatus.State.FINISHED -> "finished"
            TorrentStatus.State.SEEDING -> "seeding"
            TorrentStatus.State.CHECKING_RESUME_DATA -> "checking"
            else -> "unknown"
        }
    }
}

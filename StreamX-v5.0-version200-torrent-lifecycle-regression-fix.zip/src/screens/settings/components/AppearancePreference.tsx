import React, {useState} from 'react';
import {Pressable, View} from 'react-native';
import {isDynamicColorAvailable} from '@expo/ui/jetpack-compose';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import useThemeStore from '../../../lib/zustand/themeStore';
import {M3_SEEDS, readableOnColor} from '../../../theme/seeds';
import {useM3Colors} from '../../../theme/M3PaletteContext';
import AppText from '../../../components/ui/Text';
import SettingsSection from '../../../components/ui/SettingsSection';
import SettingsSwitchRow from '../../../components/ui/SettingsSwitchRow';
import {settingsStorage} from '../../../lib/storage';
import {withAlpha} from '../../../theme/glass';


const AppearancePreference = () => {
  const source = useThemeStore(state => state.source);
  const setSource = useThemeStore(state => state.setSource);
  const primary = useThemeStore(state => state.primary);
  const setPrimary = useThemeStore(state => state.setPrimary);
  const colors = useM3Colors();
  const [dynamicInfoAccentEnabled, setDynamicInfoAccentEnabled] = useState(() =>
    settingsStorage.isDynamicInfoAccentEnabled(),
  );

  const wallpaperActive = source === 'wallpaper';

  return (
    <SettingsSection title="Appearance">
      <Pressable
        testID="accent-source-wallpaper"
        disabled={!isDynamicColorAvailable}
        onPress={() => setSource('wallpaper')}
        style={({pressed}) => ({
          backgroundColor: pressed
            ? withAlpha(colors.primary, 0.15)
            : 'transparent',
          opacity: !isDynamicColorAvailable ? 0.5 : 1,
        })}>
        <View
          style={{
            minHeight: 70,
            flexDirection: 'row',
            alignItems: 'center',
            paddingHorizontal: 12,
            paddingVertical: 7,
            borderBottomWidth: 1,
            borderBottomColor: withAlpha(colors.primary, 0.17),
          }}>
          <View
            style={{
              width: 40,
              height: 40,
              borderRadius: 13,
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: withAlpha(colors.primary, 0.18),
            }}>
            <MaterialCommunityIcons
              name="wallpaper"
              size={21}
              color={colors.primary}
            />
          </View>
          <View style={{flex: 1, minWidth: 0, marginLeft: 11, marginRight: 8}}>
            <AppText role="bodyLargeEmphasized" style={{color: colors.onSurface}}>
              Wallpaper colors
            </AppText>
            <AppText role="bodySmall" numberOfLines={2} style={{color: colors.onSurfaceVariant, marginTop: 1}}>
              {isDynamicColorAvailable
                ? 'Match the system Material You palette'
                : 'Requires Android 12 or newer'}
            </AppText>
          </View>
          {wallpaperActive && isDynamicColorAvailable ? (
            <MaterialCommunityIcons name="check-circle" size={21} color={colors.primary} />
          ) : null}
        </View>
      </Pressable>

      <View
        style={{
          minHeight: 78,
          paddingHorizontal: 12,
          paddingVertical: 9,
          borderBottomWidth: 1,
          borderBottomColor: withAlpha(colors.primary, 0.17),
        }}>
        <AppText role="bodyLargeEmphasized" style={{color: colors.onSurface}}>
          Accent color
        </AppText>
        <AppText role="bodySmall" numberOfLines={2} style={{color: colors.onSurfaceVariant, marginTop: 1}}>
          Choose a curated seed for StreamX's dark palette
        </AppText>
        <View style={{marginTop: 8, flexDirection: 'row', flexWrap: 'wrap', gap: 8}}>
          {M3_SEEDS.map(seed => {
            const isSelected =
              source === 'custom' &&
              primary.toLowerCase() === seed.color.toLowerCase();
            return (
              <Pressable
                key={seed.color}
                testID={`accent-seed-${seed.name}`}
                accessibilityRole="button"
                accessibilityLabel={`${seed.name} accent color`}
                accessibilityState={{selected: isSelected}}
                onPress={() => {
                  setSource('custom');
                  setPrimary(seed.color);
                }}
                style={{
                  backgroundColor: seed.color,
                  borderColor: isSelected ? colors.primary : withAlpha(colors.primary, 0.3),
                  borderRadius: 14,
                  borderWidth: isSelected ? 2 : 1,
                  height: 42,
                  width: 42,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <MaterialCommunityIcons
                  name={isSelected ? 'check' : 'palette'}
                  size={19}
                  color={readableOnColor(seed.color)}
                />
              </Pressable>
            );
          })}
        </View>
      </View>

      <SettingsSwitchRow
        title="Dynamic info accent"
        description="Match the info page accent to each title's artwork"
        value={dynamicInfoAccentEnabled}
        onValueChange={enabled => {
          setDynamicInfoAccentEnabled(enabled);
          settingsStorage.setDynamicInfoAccentEnabled(enabled);
        }}
      />
    </SettingsSection>
  );
};

export default AppearancePreference;

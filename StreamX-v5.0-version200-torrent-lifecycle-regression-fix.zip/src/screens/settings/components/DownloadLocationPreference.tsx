import React, {useEffect, useState} from 'react';
import {Alert, ToastAndroid, View} from 'react-native';
import {
  getDownloadLocationDisplayValue,
  getLastDownloadLocationValidationError,
  resolveDownloadLocationLabel,
  selectDownloadLocation,
  validateDownloadLocationAccess,
} from '../../../lib/downloadLocation';
import {settingsStorage} from '../../../lib/storage';
import {syncFromSharedFolder} from '../../../lib/sync/syncService';
import IconButton from '../../../components/ui/IconButton';
import SettingsRow from '../../../components/ui/SettingsRow';
import SettingsSection from '../../../components/ui/SettingsSection';
import SettingsSwitchRow from '../../../components/ui/SettingsSwitchRow';

type DownloadLocationPreferenceProps = {
  primary: string;
};

const DownloadLocationPreference = ({
  primary: _primary,
}: DownloadLocationPreferenceProps) => {
  const [downloadLocation, setDownloadLocation] = useState(
    settingsStorage.getDownloadLocation(),
  );
  const [isPickingFolder, setIsPickingFolder] = useState(false);
  const [alwaysUseExternalDownload, setAlwaysUseExternalDownload] = useState(
    settingsStorage.getBool('alwaysExternalDownloader') || false,
  );

  // Old versions persisted provider IDs such as "msd/1000393198" as labels.
  // Resolve the real SAF display name on screen entry, keeping the URI/grant
  // (the actual destination) unchanged.
  useEffect(() => {
    let active = true;
    const current = settingsStorage.getDownloadLocationConfig();
    if (current?.type === 'saf') {
      resolveDownloadLocationLabel(current)
        .then(label => {
          if (!active || !label) return;
          const latest = settingsStorage.getDownloadLocationConfig();
          if (!latest || latest.type !== 'saf' || latest.uri !== current.uri) return;
          if (latest.label !== label) {
            const corrected = {...latest, label};
            settingsStorage.setDownloadLocation(corrected);
          }
          setDownloadLocation(label);
        })
        .catch(error => {
          console.warn('[StreamX] Could not resolve saved download folder label:', error);
        });
    }
    return () => {
      active = false;
    };
  }, []);

  const saveDownloadLocation = (
    location: NonNullable<
      ReturnType<typeof settingsStorage.getDownloadLocationConfig>
    >,
  ) => {
    settingsStorage.setDownloadLocation(location);
    setDownloadLocation(getDownloadLocationDisplayValue(location));
    syncFromSharedFolder().catch(e =>
      console.warn('[StreamXSync] Folder change sync failed:', e),
    );
    ToastAndroid.show('Download location updated', ToastAndroid.SHORT);
  };

  const pickDownloadLocation = async () => {
    if (isPickingFolder) {
      return;
    }

    setIsPickingFolder(true);
    try {
      const pickedLocation = await selectDownloadLocation();
      if (pickedLocation) {
        const accessible = await validateDownloadLocationAccess(pickedLocation);
        if (!accessible) {
          Alert.alert(
            'Folder access unavailable',
            getLastDownloadLocationValidationError() ||
              'Choose a writable folder under Internal storage or Downloads and grant access in Android’s folder picker.',
          );
          return;
        }
        saveDownloadLocation(pickedLocation);
        return;
      }

      ToastAndroid.show('No folder selected', ToastAndroid.SHORT);
    } catch (error) {
      console.log('Error picking download folder:', error);
      ToastAndroid.show('Unable to open folder picker', ToastAndroid.SHORT);
    } finally {
      setIsPickingFolder(false);
    }
  };

  return (
    <View className="mb-6">
      <SettingsSection title="Downloads">
        <SettingsRow
          title="Download location"
          description={downloadLocation}
          divider
          trailing={
            <IconButton
              icon="folder-open-outline"
              label="Choose download location"
              disabled={isPickingFolder}
              onPress={pickDownloadLocation}
            />
          }
        />
        <SettingsSwitchRow
          title="External downloader"
          description="Send every download to another app"
          value={alwaysUseExternalDownload}
          onValueChange={next => {
            settingsStorage.setBool('alwaysExternalDownloader', next);
            setAlwaysUseExternalDownload(next);
          }}
        />
        <SettingsRow
          title="Reset download location"
          description="Choose a folder again on the next download"
          divider={false}
          trailing={
            <IconButton
              icon="restore"
              label="Reset download location"
              onPress={() => {
                settingsStorage.resetDownloadLocation();
                setDownloadLocation('Select a download folder');
                ToastAndroid.show(
                  'Download location cleared',
                  ToastAndroid.SHORT,
                );
              }}
            />
          }
        />
      </SettingsSection>
    </View>
  );
};

export default DownloadLocationPreference;

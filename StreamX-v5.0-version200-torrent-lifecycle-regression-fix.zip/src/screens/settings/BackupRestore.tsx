import React, {useCallback, useState} from 'react';
import {DevSettings, Platform, Pressable, ToastAndroid, View} from 'react-native';
import * as Updates from 'expo-updates';
import Animated from 'react-native-reanimated';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {MaterialCommunityIcons} from '@expo/vector-icons';
import {SettingsStackParamList} from '../../App';
import AppText from '../../components/ui/Text';
import IconButton from '../../components/ui/IconButton';
import SettingsSection from '../../components/ui/SettingsSection';
import useTabBarScrollVisibility from '../../lib/hooks/useTabBarScrollVisibility';
import {useM3Colors} from '../../theme/M3PaletteContext';
import {withAlpha} from '../../theme/glass';
import {createAndSaveBackup, pickAndRestoreBackup} from '../../lib/backupRestore';
import {showAppDialog} from '../../lib/zustand/appDialogStore';

type Props = NativeStackScreenProps<SettingsStackParamList, 'BackupRestore'>;

type ActionRowProps = {
  icon: React.ComponentProps<typeof MaterialCommunityIcons>['name'];
  title: string;
  description: string;
  disabled?: boolean;
  onPress: () => void;
};

const ActionRow = ({icon, title, description, disabled = false, onPress}: ActionRowProps) => {
  const colors = useM3Colors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{disabled}}
      disabled={disabled}
      onPress={onPress}
      style={({pressed}) => ({
        minHeight: 70,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 12,
        paddingVertical: 7,
        opacity: disabled ? 0.48 : pressed ? 0.8 : 1,
      })}>
      <View
        pointerEvents="none"
        style={{
          width: 40,
          height: 40,
          borderRadius: 13,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: colors.primaryContainer,
        }}>
        <MaterialCommunityIcons name={icon} size={21} color={colors.primary} />
      </View>
      <View pointerEvents="none" style={{flex: 1, minWidth: 0, marginLeft: 11}}>
        <AppText role="bodyLargeEmphasized" style={{color: colors.onSurface}}>
          {title}
        </AppText>
        <AppText role="bodySmall" numberOfLines={2} style={{color: colors.onSurfaceVariant, marginTop: 1}}>
          {description}
        </AppText>
      </View>
    </Pressable>
  );
};

const BackupRestore = ({navigation}: Props) => {
  const colors = useM3Colors();
  const insets = useSafeAreaInsets();
  const tabBarScroll = useTabBarScrollVisibility();
  const [busy, setBusy] = useState<'backup' | 'restore' | null>(null);

  const showToast = useCallback((message: string) => {
    if (Platform.OS === 'android') ToastAndroid.show(message, ToastAndroid.SHORT);
  }, []);

  const handleBackup = useCallback(async () => {
    if (busy) return;
    setBusy('backup');
    try {
      const result = await createAndSaveBackup();
      if (!result.canceled) showToast(`Backup saved: ${result.fileName}`);
    } catch (error) {
      console.error('[BackupRestore] Backup failed:', error);
      showToast('Unable to create backup');
    } finally {
      setBusy(null);
    }
  }, [busy, showToast]);

  const restoreNow = useCallback(async () => {
    if (busy) return;
    setBusy('restore');
    try {
      const result = await pickAndRestoreBackup();
      if (result.canceled) return;
      showToast('Backup restored. Reloading app…');
      if (Updates.isEnabled) {
        await Updates.reloadAsync();
        return;
      }
      DevSettings.reload('StreamX backup restored');
    } catch (error) {
      console.error('[BackupRestore] Restore failed:', error);
      showToast(error instanceof Error ? error.message : 'Unable to restore backup');
    } finally {
      setBusy(null);
    }
  }, [busy, showToast]);

  const handleRestore = useCallback(() => {
    if (busy) return;
    showAppDialog({
      title: 'Restore backup?',
      message: 'This will replace the app settings, installed add-ons, watchlist and saved app data covered by the backup. Cache data will not be restored.',
      actions: [
        {label: 'Cancel'},
        {label: 'Restore', onPress: restoreNow},
      ],
    });
  }, [busy, restoreNow]);

  return (
    <View style={{flex: 1, backgroundColor: colors.background}}>
      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        onScroll={tabBarScroll.onScroll}
        onScrollBeginDrag={tabBarScroll.onScrollBeginDrag}
        onScrollEndDrag={tabBarScroll.onScrollEndDrag}
        onMomentumScrollBegin={tabBarScroll.onMomentumScrollBegin}
        onMomentumScrollEnd={tabBarScroll.onMomentumScrollEnd}
        scrollEventThrottle={32}
        contentContainerStyle={{paddingHorizontal: 18, paddingTop: insets.top + 18, paddingBottom: 138}}>
        <View style={{flexDirection: 'row', alignItems: 'center', marginBottom: 12}}>
          <IconButton icon="arrow-left" label="Back" buttonSize={40} onPress={() => navigation.goBack()} contentColor={colors.onSurface} />
          <AppText role="headlineLargeEmphasized" style={{color: colors.onBackground, fontSize: 30, lineHeight: 36, marginLeft: 2}}>
            Backup & Restore
          </AppText>
        </View>

        <SettingsSection title="Backup & Restore">
          <ActionRow
            icon="backup-restore"
            title="Create Backup"
            description="Save settings, add-ons, watchlist and saved app data to a JSON backup."
            disabled={busy !== null}
            onPress={() => void handleBackup()}
          />
          <View style={{height: 1, backgroundColor: withAlpha(colors.primary, 0.24), opacity: 0.7}} />
          <ActionRow
            icon="restore"
            title="Restore Backup"
            description="Select a StreamX backup file and replace the saved app data with it."
            disabled={busy !== null}
            onPress={handleRestore}
          />
        </SettingsSection>
      </Animated.ScrollView>
    </View>
  );
};

export default BackupRestore;

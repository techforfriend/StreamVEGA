import {View, ScrollView, Pressable} from 'react-native';
import React, {useState} from 'react';
import {settingsStorage} from '../../lib/storage';
import RNReactNativeHapticFeedback from 'react-native-haptic-feedback';
import Constants from 'expo-constants';
import DownloadLocationPreference from './components/DownloadLocationPreference';
import useNavigationPreferencesStore from '../../lib/zustand/navigationPreferencesStore';
import DownloadConcurrencyPreference from './components/DownloadConcurrencyPreference';
import TmdbApiKeyPreference from './components/TmdbApiKeyPreference';
import AppText from '../../components/ui/Text';
import SettingsSection from '../../components/ui/SettingsSection';
import SettingsSwitchRow from '../../components/ui/SettingsSwitchRow';
import {useM3Colors} from '../../theme/M3PaletteContext';
import {withAlpha} from '../../theme/glass';
import useTabBarScrollVisibility from '../../lib/hooks/useTabBarScrollVisibility';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {
  getAnalytics,
  getCrashlytics,
  isFirebaseNativeReady,
} from '../../lib/utils/firebaseSafe';

const Preferences = () => {
  const hasFirebase =
    Boolean(Constants?.expoConfig?.extra?.hasFirebase) &&
    isFirebaseNativeReady();
  const colors = useM3Colors();
  const tabBarScroll = useTabBarScrollVisibility();
  const insets = useSafeAreaInsets();
  // const [showRecentlyWatched, setShowRecentlyWatched] = useState(
  //   settingsStorage.getBool('showRecentlyWatched') || false,
  // );
  const [disableDrawer, setDisableDrawer] = useState(
    settingsStorage.getBool('disableDrawer') || false,
  );

  const [ExcludedQualities, setExcludedQualities] = useState(
    settingsStorage.getExcludedQualities(),
  );

  const [showMediaControls, setShowMediaControls] = useState<boolean>(
    settingsStorage.showMediaControls(),
  );

  const [showHamburgerMenu, setShowHamburgerMenu] = useState<boolean>(
    settingsStorage.showHamburgerMenu(),
  );

  const [hideSeekButtons, setHideSeekButtons] = useState<boolean>(
    settingsStorage.hideSeekButtons(),
  );

  const [showEpisodeSidebar, setShowEpisodeSidebar] = useState<boolean>(
    settingsStorage.showPlayerEpisodeSidebar(),
  );

  const [_enable2xGesture, _setEnable2xGesture] = useState<boolean>(
    settingsStorage.isEnable2xGestureEnabled(),
  );

  const [enableSwipeGesture, setEnableSwipeGesture] = useState<boolean>(
    settingsStorage.isSwipeGestureEnabled(),
  );

  const hideTabBarLabels = useNavigationPreferencesStore(
    state => state.hideTabBarLabels,
  );
  const setHideTabBarLabels = useNavigationPreferencesStore(
    state => state.setHideTabBarLabels,
  );
  const hideDownloadsTab = useNavigationPreferencesStore(
    state => state.hideDownloadsTab,
  );
  const setHideDownloadsTab = useNavigationPreferencesStore(
    state => state.setHideDownloadsTab,
  );

  const [OpenExternalPlayer, setOpenExternalPlayer] = useState(
    settingsStorage.getBool('useExternalPlayer', false),
  );


  const [telemetryOptIn, setTelemetryOptIn] = useState<boolean>(
    settingsStorage.isTelemetryOptIn(),
  );

  return (
    <ScrollView
      className="h-full w-full bg-m3-background"
      showsVerticalScrollIndicator={false}
        onScroll={tabBarScroll.onScroll}
        onScrollBeginDrag={tabBarScroll.onScrollBeginDrag}
        onScrollEndDrag={tabBarScroll.onScrollEndDrag}
        onMomentumScrollBegin={tabBarScroll.onMomentumScrollBegin}
        onMomentumScrollEnd={tabBarScroll.onMomentumScrollEnd}
        scrollEventThrottle={32}
      contentContainerStyle={{paddingBottom: 138, paddingTop: insets.top + 18}}>
      <View className="px-[18px]">
        <AppText
          role="headlineLargeEmphasized"
          style={{color: colors.onBackground, fontSize: 30, lineHeight: 36}}>
          Preferences
        </AppText>
        <AppText
          role="bodyLarge"
          style={{color: colors.onSurfaceVariant, marginTop: 2, marginBottom: 12}}>
          Shape how StreamX looks, plays, and downloads
        </AppText>

        <SettingsSection title="Experience">
          <SettingsSwitchRow
            title="Hide downloads tab"
            value={hideDownloadsTab}
            onValueChange={setHideDownloadsTab}
          />
          <SettingsSwitchRow
            title="Hide bottom navigation labels"
            description="Show only navigation icons in the bottom pill"
            value={hideTabBarLabels}
            onValueChange={setHideTabBarLabels}
          />
          <SettingsSwitchRow
            title="Hamburger menu"
            value={showHamburgerMenu}
            onValueChange={next => {
              settingsStorage.setShowHamburgerMenu(next);
              setShowHamburgerMenu(next);
            }}
          />
          {/* <SettingsSwitchRow
            title="Recently watched"
            description="Keep your resume rail on Home"
            value={showRecentlyWatched}
            onValueChange={next => {
              settingsStorage.setBool('showRecentlyWatched', next);
              setShowRecentlyWatched(next);
            }}
          /> */}
          <SettingsSwitchRow
            title="Disable drawer"
            value={disableDrawer}
            onValueChange={next => {
              settingsStorage.setBool('disableDrawer', next);
              setDisableDrawer(next);
            }}
          />
        </SettingsSection>

        {hasFirebase ? (
          <SettingsSection title="Privacy">
            <SettingsSwitchRow
              title="Usage and crash reports"
              description="Help improve StreamX with anonymous diagnostics"
              value={telemetryOptIn}
              divider={false}
              onValueChange={async next => {
                setTelemetryOptIn(next);
                settingsStorage.setTelemetryOptIn(next);
                try {
                  const crashlytics = getCrashlytics();
                  crashlytics &&
                    (await crashlytics().setCrashlyticsCollectionEnabled(next));
                } catch {}
                try {
                  const analytics = getAnalytics();
                  analytics &&
                    (await analytics().setAnalyticsCollectionEnabled(next));
                  analytics &&
                    (await analytics().setConsent({
                      analytics_storage: next,
                      ad_storage: next,
                      ad_user_data: next,
                      ad_personalization: next,
                    }));
                } catch {}
              }}
            />
          </SettingsSection>
        ) : null}

        <TmdbApiKeyPreference />

        <SettingsSection title="Playback">
          <SettingsSwitchRow
            title="External player"
            description="Open streams in your preferred video app"
            value={OpenExternalPlayer}
            onValueChange={next => {
              settingsStorage.setBool('useExternalPlayer', next);
              setOpenExternalPlayer(next);
            }}
          />
          <SettingsSwitchRow
            title="Media controls"
            value={showMediaControls}
            onValueChange={next => {
              settingsStorage.setShowMediaControls(next);
              setShowMediaControls(next);
            }}
          />
          <SettingsSwitchRow
            title="Hide seek buttons"
            value={hideSeekButtons}
            onValueChange={next => {
              settingsStorage.setHideSeekButtons(next);
              setHideSeekButtons(next);
            }}
          />
          <SettingsSwitchRow
            title="Episode list button"
            description="Show button on the right edge to quickly open the episode list sidebar"
            value={showEpisodeSidebar}
            onValueChange={next => {
              settingsStorage.setShowPlayerEpisodeSidebar(next);
              setShowEpisodeSidebar(next);
            }}
          />
          <SettingsSwitchRow
            title="Swipe gestures"
            description="Adjust playback with gestures over the video"
            value={enableSwipeGesture}
            divider={false}
            onValueChange={next => {
              settingsStorage.setSwipeGestureEnabled(next);
              setEnableSwipeGesture(next);
            }}
          />
        </SettingsSection>

        <DownloadLocationPreference primary={colors.primary} />

        <DownloadConcurrencyPreference primary={colors.primary} />

        <SettingsSection title="Quality">
          <View style={{paddingHorizontal: 12, paddingVertical: 9}}>
            <AppText role="bodyLarge" className="text-m3-on-surface">
              Excluded Qualities
            </AppText>
            <AppText
              role="bodySmall"
              className="mb-4 mt-1 text-m3-on-surface-variant">
              Hide lower resolutions from stream results
            </AppText>
            <View className="flex-row flex-wrap gap-3">
              {['360p', '480p', '720p', '1080p', '2K', '4K', 'HDR', 'SDR'].map(quality => {
                const selected = ExcludedQualities.includes(quality);
                return (
                  <Pressable
                    key={quality}
                    onPress={() => {
                      if (settingsStorage.isHapticFeedbackEnabled()) {
                        RNReactNativeHapticFeedback.trigger('effectTick');
                      }
                      const newExcluded = ExcludedQualities.includes(quality)
                        ? ExcludedQualities.filter(q => q !== quality)
                        : [...ExcludedQualities, quality];
                      setExcludedQualities(newExcluded);
                      settingsStorage.setExcludedQualities(newExcluded);
                    }}
                    style={{
                      backgroundColor: selected
                        ? withAlpha(colors.primary, 0.26)
                        : withAlpha(colors.surfaceContainerHigh, 0.76),
                      borderColor: selected
                        ? colors.primary
                        : withAlpha(colors.primary, 0.26),
                      borderRadius: 16,
                      borderWidth: 1,
                      paddingHorizontal: 18,
                      paddingVertical: 10,
                    }}>
                    <AppText
                      role="labelLargeEmphasized"
                      style={{
                        color: colors.onSurface,
                      }}>
                      {quality}
                    </AppText>
                  </Pressable>
                );
              })}
            </View>
          </View>
        </SettingsSection>
      </View>
    </ScrollView>
  );
};

export default Preferences;

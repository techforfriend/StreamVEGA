import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import React from 'react';
import {Pressable, View, useWindowDimensions} from 'react-native';
import SkeletonLoader from '../../../components/Skeleton';

const InfoSkeleton = ({onBack}: {onBack: () => void}) => {
  const {width, height} = useWindowDimensions();
  const heroHeight = Math.max(220, Math.min(340, Math.round(height * 0.34)));
  const sidePadding = Math.max(16, Math.min(22, Math.round(width * 0.045)));

  return (
    <View style={{backgroundColor: '#000000', flex: 1}}>
      {/* Backdrop placeholder mirrors the details hero's aspect and position. */}
      <View style={{height: heroHeight, overflow: 'hidden', width: '100%'}}>
        <SkeletonLoader
          show
          height="100%"
          width="100%"
          marginVertical={0}
          style={{borderRadius: 0}}
        />
        <Pressable
          accessibilityLabel="Go back"
          accessibilityRole="button"
          hitSlop={8}
          onPress={onBack}
          style={{
            alignItems: 'center',
            height: 48,
            justifyContent: 'center',
            left: 10,
            position: 'absolute',
            top: Math.max(20, Math.round(height * 0.035)),
            width: 48,
          }}>
          <MaterialCommunityIcons name="arrow-left" color="#FFFFFF" size={28} />
        </Pressable>
      </View>

      {/* Content placeholders follow ContentOverview's overlapping poster/title row. */}
      <View
        style={{
          gap: 12,
          marginTop: -38,
          paddingHorizontal: sidePadding,
          paddingBottom: 150,
        }}>
        <View style={{alignItems: 'flex-end', flexDirection: 'row', gap: 12}}>
          <SkeletonLoader
            show
            height={78}
            width={56}
            marginVertical={0}
            style={{borderRadius: 12, flexShrink: 0}}
          />
          <View style={{flex: 1, gap: 9, paddingBottom: 2}}>
            <SkeletonLoader
              show
              height={31}
              width="78%"
              marginVertical={0}
              style={{borderRadius: 7}}
            />
            <View style={{flexDirection: 'row', flexWrap: 'wrap', gap: 7}}>
              <SkeletonLoader show height={22} width={62} marginVertical={0} />
              <SkeletonLoader show height={22} width={78} marginVertical={0} />
              <SkeletonLoader show height={22} width={54} marginVertical={0} />
            </View>
          </View>
        </View>

        <SkeletonLoader show height={21} width={138} marginVertical={0} />
        <View style={{gap: 6}}>
          <SkeletonLoader show height={16} width="100%" marginVertical={0} />
          <SkeletonLoader show height={16} width="92%" marginVertical={0} />
          <SkeletonLoader show height={16} width="76%" marginVertical={0} />
        </View>

        {/* Rounded action chips mirror the live details page controls. */}
        <View style={{flexDirection: 'row', gap: 8, marginTop: 3}}>
          <SkeletonLoader
            show
            height={42}
            width="24%"
            marginVertical={0}
            style={{borderRadius: 22}}
          />
          <SkeletonLoader
            show
            height={42}
            width="24%"
            marginVertical={0}
            style={{borderRadius: 22}}
          />
          <SkeletonLoader
            show
            height={42}
            width="24%"
            marginVertical={0}
            style={{borderRadius: 22}}
          />
        </View>

        {/* Link/episode cards match the compact rounded content cards below the fold. */}
        <SkeletonLoader
          show
          height={66}
          width="100%"
          marginVertical={0}
          style={{borderRadius: 16, marginTop: 4}}
        />
        <SkeletonLoader
          show
          height={66}
          width="100%"
          marginVertical={0}
          style={{borderRadius: 16}}
        />
      </View>
    </View>
  );
};

export default InfoSkeleton;

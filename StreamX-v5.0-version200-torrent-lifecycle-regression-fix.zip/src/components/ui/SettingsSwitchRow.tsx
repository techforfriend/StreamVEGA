import React from 'react';
import {View} from 'react-native';
import AppText from './Text';
import {useM3Colors} from '../../theme/M3PaletteContext';
import {withAlpha} from '../../theme/glass';
import CompactSwitch from './CompactSwitch';

interface SettingsSwitchRowProps {
  title: string;
  description?: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
  divider?: boolean;
}

const SettingsSwitchRow = ({
  title,
  description,
  value,
  onValueChange,
  divider = true,
}: SettingsSwitchRowProps) => {
  const colors = useM3Colors();

  return (
    <View
      style={{
        minHeight: description ? 70 : 58,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 12,
        paddingVertical: 7,
        borderBottomColor: withAlpha(colors.primary, 0.17),
        borderBottomWidth: divider ? 1 : 0,
      }}>
      <View style={{flex: 1, minWidth: 0, marginRight: 10}}>
        <AppText role="bodyLargeEmphasized" style={{color: colors.onSurface}}>
          {title}
        </AppText>
        {description ? (
          <AppText
            role="bodySmall"
            numberOfLines={2}
            style={{color: colors.onSurfaceVariant, marginTop: 1}}>
            {description}
          </AppText>
        ) : null}
      </View>
      <CompactSwitch
        accessibilityLabel={title}
        value={value}
        onValueChange={onValueChange}
      />
    </View>
  );
};

export default SettingsSwitchRow;

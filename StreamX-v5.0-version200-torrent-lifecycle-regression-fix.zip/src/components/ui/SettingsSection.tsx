import React, {ReactNode} from 'react';
import {StyleSheet, View} from 'react-native';
import AppText from './Text';
import {useM3Colors} from '../../theme/M3PaletteContext';
import {withAlpha} from '../../theme/glass';

interface SettingsSectionProps {
  title: string;
  children: ReactNode;
}

const SettingsSection = ({title, children}: SettingsSectionProps) => {
  const colors = useM3Colors();
  return (
    <View style={{marginBottom: 12}}>
      <AppText
        role="labelMediumEmphasized"
        style={{
          color: colors.primary,
          letterSpacing: 1.25,
          marginLeft: 2,
          marginBottom: 6,
        }}>
        {title.toUpperCase()}
      </AppText>
      <View
        style={{
          // Use an opaque Material surface on Android. Semi-transparent nested surfaces
          // can expose rectangular child backgrounds through the rounded glass card.
          backgroundColor: colors.surfaceContainerHigh,
          borderRadius: 22,
          borderWidth: StyleSheet.hairlineWidth + 0.5,
          borderColor: withAlpha(colors.primary, 0.36),
          overflow: 'hidden',
          shadowColor: colors.primary,
          shadowOffset: {width: 0, height: 3},
          shadowOpacity: 0.08,
          shadowRadius: 10,
          elevation: 2,
        }}>
        {children}
      </View>
    </View>
  );
};

export default SettingsSection;

import * as RNFS from '@dr.pogodin/react-native-fs';
import * as FileSystem from 'expo-file-system/legacy';
import {NativeModules, Platform} from 'react-native';
import {takePersistableUriPermission} from './uriPermission';

export type PathDownloadLocation = {
  type: 'path';
  path: string;
  label?: string;
};

export type SafDownloadLocation = {
  type: 'saf';
  uri: string;
  label: string;
};

export type DownloadLocationConfig = PathDownloadLocation | SafDownloadLocation;

const DOWNLOAD_LOCATION_PREFIX = 'download-location:';

const isUnhelpfulSafFolderLabel = (label: string): boolean => {
  const value = label.trim();
  return (
    !value ||
    /^content:\/\//i.test(value) ||
    /^msd\/\d+$/i.test(value) ||
    /^\d+$/.test(value) ||
    /^selected folder$/i.test(value)
  );
};

type NativeSafChild = {
  uri: string;
  name: string;
  isDirectory: boolean;
  size?: number;
};

type NativeSafBridge = {
  validateTreeUri?: (uri: string) => Promise<{
    valid: boolean;
    persisted?: boolean;
    reason?: string;
    treeUri?: string;
  }>;
  listSafChildren?: (parentUri: string) => Promise<NativeSafChild[]>;
  ensureSafDirectory?: (parentUri: string, name: string) => Promise<string>;
  createSafFile?: (parentUri: string, name: string, mimeType: string) => Promise<string>;
  deleteSafUri?: (uri: string) => Promise<boolean>;
  getTreeDisplayName?: (uri: string) => Promise<string>;
};

let lastDownloadLocationValidationError: string | undefined;

const getNativeSafBridge = (): NativeSafBridge | undefined =>
  Platform.OS === 'android'
    ? (NativeModules.HttpDownloadModule as NativeSafBridge | undefined)
    : undefined;

export const getLastDownloadLocationValidationError = (): string | undefined =>
  lastDownloadLocationValidationError;

export const serializeDownloadLocation = (
  config: DownloadLocationConfig,
): string => {
  return `${DOWNLOAD_LOCATION_PREFIX}${JSON.stringify(config)}`;
};

export const parseDownloadLocation = (
  storedValue?: string | null,
): DownloadLocationConfig | null => {
  if (!storedValue) {
    return null;
  }

  if (!storedValue.startsWith(DOWNLOAD_LOCATION_PREFIX)) {
    if (Platform.OS === 'android') {
      return null;
    }
    return {
      type: 'path',
      path: storedValue,
      label: storedValue,
    };
  }

  try {
    const parsed = JSON.parse(
      storedValue.slice(DOWNLOAD_LOCATION_PREFIX.length),
    ) as DownloadLocationConfig;

    if (parsed.type === 'saf' && parsed.uri && parsed.label) {
      return parsed;
    }

    if (parsed.type === 'path' && parsed.path && Platform.OS !== 'android') {
      return {
        type: 'path',
        path: parsed.path,
        label: parsed.label || parsed.path,
      };
    }
  } catch (error) {
    console.log('Failed to parse download location:', error);
  }

  return null;
};

export const isSafDownloadLocation = (
  config: DownloadLocationConfig,
): config is SafDownloadLocation => {
  return config.type === 'saf';
};

export const getDownloadLocationDisplayValue = (
  config?: DownloadLocationConfig | null,
): string => {
  if (!config) {
    return 'Select a download folder';
  }
  if (config.type === 'saf') {
    return isUnhelpfulSafFolderLabel(config.label)
      ? 'Selected folder'
      : config.label;
  }
  return config.path;
};

export const getDownloadLocationPath = (
  config?: DownloadLocationConfig | null,
): string | null => {
  return config?.type === 'path' ? config.path : null;
};

export const getAndroidDirectoryLabel = (directoryUri: string): string => {
  const treeMarker = '/tree/';
  const treeIndex = directoryUri.indexOf(treeMarker);
  if (treeIndex === -1) {
    return 'Custom folder';
  }

  const documentId = decodeURIComponent(
    directoryUri.slice(treeIndex + treeMarker.length),
  );
  const [volume, relativePath = ''] = documentId.split(':');
  if (!relativePath) {
    return volume === 'primary' ? 'Internal storage' : volume;
  }
  return `${volume === 'primary' ? 'Internal storage' : volume}/${relativePath}`;
};

/** Resolve the human-readable folder name from Android's SAF provider. */
export const resolveSafTreeDisplayName = async (directoryUri: string): Promise<string> => {
  const nativeSaf = getNativeSafBridge();
  if (nativeSaf?.getTreeDisplayName) {
    try {
      const actualName = (await nativeSaf.getTreeDisplayName(directoryUri))?.trim();
      if (actualName && !isUnhelpfulSafFolderLabel(actualName)) {
        return actualName;
      }
    } catch (error) {
      console.warn('[StreamX] Could not read SAF folder display name:', error);
    }
  }

  const uriLabel = getAndroidDirectoryLabel(directoryUri);
  if (isUnhelpfulSafFolderLabel(uriLabel)) {
    return 'Selected folder';
  }
  // When possible show just the selected folder name, not an opaque provider
  // ID or a long storage path.
  const leaf = uriLabel.split('/').filter(Boolean).pop() || uriLabel;
  return isUnhelpfulSafFolderLabel(leaf) ? 'Selected folder' : leaf;
};

export const resolveDownloadLocationLabel = async (
  location?: DownloadLocationConfig | null,
): Promise<string> => {
  if (!location) return 'Select a download folder';
  if (location.type === 'path') return location.label || location.path;
  return resolveSafTreeDisplayName(location.uri);
};

export const selectDownloadLocation = async (): Promise<
  DownloadLocationConfig | undefined
> => {
  if (Platform.OS === 'android') {
    const permissions =
      await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();
    if (!permissions.granted) {
      return undefined;
    }
    return {
      type: 'saf',
      uri: permissions.directoryUri,
      label: await resolveSafTreeDisplayName(permissions.directoryUri),
    };
  }

  const pickedFolders = await RNFS.pickFile({pickerType: 'folder'});
  const pickedFolder = pickedFolders[0];
  if (!pickedFolder) {
    return undefined;
  }
  const path = pickedFolder.replace(/^file:\/\//, '');
  return {type: 'path', path, label: path};
};

export const validateDownloadLocationAccess = async (
  location?: DownloadLocationConfig | null,
): Promise<boolean> => {
  lastDownloadLocationValidationError = undefined;
  if (!location) {
    lastDownloadLocationValidationError = 'No download folder has been selected.';
    return false;
  }
  try {
    if (location.type === 'saf') {
      const nativeSaf = getNativeSafBridge();
      if (nativeSaf?.validateTreeUri) {
        // Use Android's DocumentsContract API directly. Expo's SAF directory
        // adapter can fail on some document providers even when the granted
        // tree URI is writable; the native bridge does a real create/write/
        // delete probe against the same URI the download backend will use.
        const result = await nativeSaf.validateTreeUri(location.uri);
        if (result?.valid) {
          // Store the canonical tree URI returned by Android so the exact same
          // URI is used for persisted-grant lookup and future file operations.
          if (result.treeUri) location.uri = result.treeUri;
          lastDownloadLocationValidationError = undefined;
          return true;
        }
        lastDownloadLocationValidationError = result?.reason ||
          'Android could not write to the selected folder. Choose a normal folder in Internal storage or Downloads and grant access.';
        console.warn('[StreamX] SAF folder validation failed:', lastDownloadLocationValidationError);
        return false;
      }

      await takePersistableUriPermission(location.uri);
      try {
        await FileSystem.StorageAccessFramework.readDirectoryAsync(location.uri);
        return true;
      } catch (readError) {
        const probeName = `.streamx-write-test-${Date.now()}.tmp`;
        let probeUri: string | undefined;
        try {
          probeUri = await FileSystem.StorageAccessFramework.createFileAsync(
            location.uri,
            probeName,
            'application/octet-stream',
          );
          await FileSystem.StorageAccessFramework.deleteAsync(probeUri);
          return true;
        } catch (writeError) {
          if (probeUri) {
            await FileSystem.StorageAccessFramework.deleteAsync(probeUri).catch(() => undefined);
          }
          lastDownloadLocationValidationError = writeError instanceof Error
            ? writeError.message
            : 'Android could not create a file in the selected folder.';
          console.warn('SAF download folder is not writable:', readError, writeError);
          return false;
        }
      }
    }
    if (Platform.OS === 'android') {
      lastDownloadLocationValidationError = 'Android downloads require a folder selected from the system folder picker.';
      return false;
    }
    if (!(await RNFS.exists(location.path))) {
      await RNFS.mkdir(location.path);
    }
    return true;
  } catch (error) {
    lastDownloadLocationValidationError = error instanceof Error
      ? error.message
      : 'The selected download folder is unavailable.';
    console.log('Download location is unavailable:', error);
    return false;
  }
};

export const ensureDownloadLocationAccess = async (
  location?: DownloadLocationConfig | null,
): Promise<DownloadLocationConfig | undefined> => {
  if (await validateDownloadLocationAccess(location)) {
    return location || undefined;
  }
  const selectedLocation = await selectDownloadLocation();
  return (await validateDownloadLocationAccess(selectedLocation))
    ? selectedLocation
    : undefined;
};

export const getDownloadFileName = (fileName: string, fileType: string) => {
  return `${fileName}.${fileType}`;
};

export const getSafEntryName = (entryUri: string): string => {
  const decodedUri = decodeURIComponent(entryUri).replace(/\/+$/, '');
  const lastSlash = decodedUri.lastIndexOf('/');
  const afterSlash =
    lastSlash !== -1 ? decodedUri.slice(lastSlash + 1) : decodedUri;
  const lastColon = afterSlash.lastIndexOf(':');
  return lastColon !== -1 ? afterSlash.slice(lastColon + 1) : afterSlash;
};

export type SafDirectoryEntry = {
  uri: string;
  name: string;
  isDirectory: boolean;
  size?: number;
};

export const listSafDirectoryEntries = async (
  parentUri: string,
): Promise<SafDirectoryEntry[]> => {
  const nativeSaf = getNativeSafBridge();
  if (nativeSaf?.listSafChildren) {
    return nativeSaf.listSafChildren(parentUri);
  }
  const entries = await FileSystem.StorageAccessFramework.readDirectoryAsync(parentUri);
  return entries.map(uri => ({
    uri,
    name: getSafEntryName(uri),
    isDirectory: false,
  }));
};

export const createSafFile = async (
  directoryUri: string,
  fileName: string,
  mimeType: string,
): Promise<string> => {
  const nativeSaf = getNativeSafBridge();
  if (nativeSaf?.createSafFile) {
    return nativeSaf.createSafFile(directoryUri, fileName, mimeType);
  }
  return FileSystem.StorageAccessFramework.createFileAsync(
    directoryUri,
    fileName,
    mimeType,
  );
};

export const deleteSafDocument = async (uri: string): Promise<boolean> => {
  const nativeSaf = getNativeSafBridge();
  if (nativeSaf?.deleteSafUri) {
    try {
      const deleted = await nativeSaf.deleteSafUri(uri);
      if (deleted) return true;
    } catch (error) {
      console.warn('[StreamX] Native SAF deletion failed; trying Expo fallback:', error);
    }
  }
  await FileSystem.StorageAccessFramework.deleteAsync(uri);
  return true;
};

export const getOrCreateSafDirectory = async (
  parentUri: string,
  directoryName: string,
): Promise<string> => {
  const nativeSaf = getNativeSafBridge();
  if (nativeSaf?.ensureSafDirectory) {
    return nativeSaf.ensureSafDirectory(parentUri, directoryName);
  }
  const entries = await FileSystem.StorageAccessFramework.readDirectoryAsync(parentUri);
  const existing = entries.find(entry => getSafEntryName(entry) === directoryName);
  return existing || FileSystem.StorageAccessFramework.makeDirectoryAsync(parentUri, directoryName);
};

export const findSafEntryByName = async (
  parentUri: string,
  entryName: string,
): Promise<string | undefined> => {
  const entries = await listSafDirectoryEntries(parentUri);
  return entries.find(entry => entry.name === entryName)?.uri;
};

export const findDownloadedFileByBaseName = async (
  location: DownloadLocationConfig | null,
  fileName: string,
) => {
  if (!location) {
    return false;
  }
  try {
    if (location.type === 'path') {
      const files = await RNFS.readDir(location.path);

      const file = files.find(fileItem => {
        const nameWithoutExtension = fileItem.name
          .split('.')
          .slice(0, -1)
          .join('.');
        return nameWithoutExtension === fileName;
      });

      return file ? file.path : false;
    }

    const files = await listSafDirectoryEntries(location.uri);

    const file = files.find(fileEntry => {
      const nameWithoutExtension = fileEntry.name.split('.').slice(0, -1).join('.');
      return !fileEntry.isDirectory && nameWithoutExtension === fileName;
    });

    return file?.uri || false;
  } catch (error) {
    console.log('Error reading download location:', error);
    return false;
  }
};

export const getDownloadMimeType = (fileType: string) => {
  switch (fileType.toLowerCase()) {
    case 'mp4':
      return 'video/mp4';
    case 'mkv':
      return 'video/x-matroska';
    case 'mov':
      return 'video/quicktime';
    case 'avi':
      return 'video/x-msvideo';
    case 'srt':
      return 'application/x-subrip';
    case 'vtt':
      return 'text/vtt';
    case 'ass':
      return 'text/plain';
    case 'mp3':
      return 'audio/mpeg';
    default:
      return 'application/octet-stream';
  }
};

export const copyFileToSaf = async ({
  fromPath,
  directoryUri,
  fileName,
  fileType,
}: {
  fromPath: string;
  directoryUri: string;
  fileName: string;
  fileType: string;
}) => {
  const targetFileName = getDownloadFileName(fileName, fileType);
  const fileUri = await createSafFile(
    directoryUri,
    targetFileName,
    getDownloadMimeType(fileType),
  );

  const safCopyModule = NativeModules.SafCopyModule as
    | {
        copyFileToUri: (
          fromFilePath: string,
          toFileUri: string,
        ) => Promise<void>;
      }
    | undefined;

  try {
    if (!safCopyModule?.copyFileToUri) {
      throw new Error('SAF file copy bridge is unavailable');
    }

    await safCopyModule.copyFileToUri(fromPath, fileUri);
    return fileUri;
  } catch (error) {
    await deleteSafDocument(fileUri).catch(() => false);
    throw error;
  }
};

export const deleteDownloadedFileByBaseName = async (
  location: DownloadLocationConfig | null,
  fileName: string,
) => {
  const foundFile = await findDownloadedFileByBaseName(location, fileName);

  if (!foundFile) {
    return false;
  }

  if (location?.type === 'path') {
    await RNFS.unlink(foundFile);
    return true;
  }

  await deleteSafDocument(foundFile);
  return true;
};

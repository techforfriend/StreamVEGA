import {NativeModules, Platform} from 'react-native';

const {TorrentModule} = NativeModules;

export interface TorrentFile {
  index: number;
  name: string;
  path: string;
  size: number;
}

export interface TorrentAddResult {
  infoHash: string;
  state: string;
  hasMetadata: boolean;
  name?: string;
  totalSize?: number;
  files?: TorrentFile[];
}

export interface TorrentStats {
  state: string;
  progress: number;
  downloadRate: number;
  uploadRate: number;
  numPeers: number;
  numSeeds: number;
  totalDone: number;
  totalWanted: number;
  hasMetadata: boolean;
}

export interface TorrentCompleteResult {
  success: boolean;
  outputPath: string;
  fileName: string;
  size: number;
}

// Match official Vega v5.0.3: libtorrent native bridge expects a 40-char
// hexadecimal BTIH. Some providers return the same hash in Base32 form.
const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
const BASE32_BTIH = /(xt(?:\.\d+)?=urn:btih:)([a-z2-7]{32})(?=[&#]|$)/gi;

export function base32ToHex(input: string): string {
  let bits = 0;
  let value = 0;
  let hex = '';
  for (const char of input.toUpperCase()) {
    const index = BASE32_ALPHABET.indexOf(char);
    if (index === -1) throw new Error(`Invalid base32 character: ${char}`);
    value = ((value << 5) | index) & 0xfff;
    bits += 5;
    if (bits >= 8) {
      bits -= 8;
      hex += ((value >>> bits) & 0xff).toString(16).padStart(2, '0');
    }
  }
  return hex;
}

export function normalizeMagnetLink(magnetOrUrl: string): string {
  if (!/^magnet:/i.test(magnetOrUrl)) return magnetOrUrl;
  return magnetOrUrl.replace(
    BASE32_BTIH,
    (_match, prefix: string, hash: string) => prefix + base32ToHex(hash),
  );
}

class TorrentManager {
  private streamPort: number | null = null;
  private isInitialized = false;

  async init(): Promise<void> {
    if (Platform.OS !== 'android') {
      throw new Error('Torrent streaming is only supported on Android');
    }
    if (this.isInitialized) {
      return;
    }

    try {
      const result = await TorrentModule.initEngine();
      this.streamPort = result.streamPort;
      this.isInitialized = true;
      console.log('TorrentManager initialized, stream port:', this.streamPort);
    } catch (error) {
      console.error('Failed to init TorrentModule:', error);
      throw error;
    }
  }

  async addTorrent(
    magnetOrUrl: string,
    options?: {output_folder?: string; file_name?: string; streaming?: boolean},
  ): Promise<TorrentAddResult> {
    await this.init();
    return await TorrentModule.addTorrent(
      normalizeMagnetLink(magnetOrUrl),
      options?.output_folder || null,
      options?.file_name || null,
      options?.streaming === true,
    );
  }

  async getStats(infoHash: string): Promise<TorrentStats> {
    await this.init();
    return await TorrentModule.getStats(infoHash);
  }

  async getFiles(infoHash: string): Promise<TorrentFile[]> {
    await this.init();
    return await TorrentModule.getFiles(infoHash);
  }

  async prepareVideoFile(infoHash: string, fileIndex = 0): Promise<boolean> {
    await this.init();
    return await TorrentModule.prepareVideoFile(infoHash, fileIndex);
  }

  async getStreamUrl(infoHash: string, fileIndex = 0): Promise<string> {
    await this.init();
    return await TorrentModule.getStreamUrl(infoHash, fileIndex);
  }

  async pauseTorrent(infoHash: string): Promise<void> {
    await this.init();
    await TorrentModule.pauseTorrent(infoHash);
  }

  async resumeTorrent(infoHash: string): Promise<void> {
    await this.init();
    await TorrentModule.resumeTorrent(infoHash);
  }

  async completeTorrent(infoHash: string): Promise<TorrentCompleteResult> {
    await this.init();
    return await TorrentModule.completeTorrent(infoHash);
  }

  async stopStreamingTorrent(infoHash: string): Promise<void> {
    if (Platform.OS !== 'android') return;
    if (!TorrentModule?.stopStreamingTorrent) return;
    await TorrentModule.stopStreamingTorrent(infoHash);
  }

  async stopAllStreamingTorrents(): Promise<void> {
    if (Platform.OS !== 'android') return;
    if (!TorrentModule?.stopAllStreamingTorrents) return;
    await TorrentModule.stopAllStreamingTorrents();
  }

  async deleteTorrent(infoHash: string, deleteFiles = true): Promise<void> {
    await this.init();
    await TorrentModule.deleteTorrent(infoHash, deleteFiles);
  }
}

export const torrentManager = new TorrentManager();

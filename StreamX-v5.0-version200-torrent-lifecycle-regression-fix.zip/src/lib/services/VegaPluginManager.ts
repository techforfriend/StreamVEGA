import axios from 'axios';
import {MMKVLoader} from 'react-native-mmkv-storage';
import {mainStorage} from '../storage';
import {providerContext} from '../providers/providerContext';
import type {Catalog, EpisodeLink, Info, Post, SettingsField, Stream} from '../providers/types';
import {isPotentiallyPlayableStream} from '../streamUtils';

export interface VegaPluginSource {
  author: string;
  url: string;
}

export interface VegaPluginManifest {
  display_name: string;
  value: string;
  version: string;
  icon?: string;
  type?: string;
  disabled?: boolean;
  source: VegaPluginSource;
  installed?: boolean;
}

export interface VegaPluginModule {
  value: string;
  sourceAuthor: string;
  version: string;
  modules: Record<string, string | undefined>;
  cachedAt: number;
}

const SOURCE_KEY = 'vegaPlugins.source';
const INSTALLED_KEY = 'vegaPlugins.installed';
const MODULE_KEY = 'vegaPlugins.modules';
const ENABLED_KEY = 'vegaPlugins.enabled';
const settingsStorageKey = (value: string) => `vegaPlugins.settings.${value}`;

export interface VegaPluginTestResult {
  passed: boolean;
  stages: Array<{name: string; passed: boolean; detail: string}>;
}

const normalizeSource = (input: string): VegaPluginSource => {
  let value = input.trim().replace(/\/+$/, '');
  if (!value) throw new Error('Enter a Vega provider username or repository URL.');

  // Vega's official shorthand sources. These are usernames in the Vega UI,
  // but they resolve to the canonical vega-providers repository.
  const shorthand = value.toLowerCase();
  if (shorthand === 'zenda-cross') {
    return {
      author: 'Zenda-Cross',
      url: 'https://raw.githubusercontent.com/Zenda-Cross/vega-providers/main',
    };
  }
  if (shorthand === 'vega-org') {
    return {
      author: 'vega-org',
      url: 'https://raw.githubusercontent.com/Zenda-Cross/vega-providers/main',
    };
  }

  // For any other provider source, Vega supports entering only the GitHub
  // username when the repository is named `vega-providers`.
  if (/^[A-Za-z0-9-]+$/.test(value)) {
    return {
      author: value,
      url: `https://raw.githubusercontent.com/${value}/vega-providers/main`,
    };
  }

  if (/^https?:\/\//i.test(value) && /\/manifest\.json$/i.test(value)) {
    value = value.slice(0, -'/manifest.json'.length);
  }
  if (/^github\.com\//i.test(value)) value = `https://${value}`;

  const parsed = new URL(value);
  if (parsed.hostname.toLowerCase() === 'github.com') {
    const parts = parsed.pathname.split('/').filter(Boolean);
    if (parts.length >= 2) {
      const owner = parts[0];
      const repo = parts[1];
      // GitHub currently redirects the historical vega-org/vega-providers
      // repository to Zenda-Cross/vega-providers. Resolve it explicitly so
      // raw.githubusercontent.com does not depend on redirect handling.
      if (owner.toLowerCase() === 'vega-org' && repo.toLowerCase() === 'vega-providers') {
        return {
          author: 'vega-org',
          url: 'https://raw.githubusercontent.com/Zenda-Cross/vega-providers/main',
        };
      }
      return {
        author: owner,
        url: `https://raw.githubusercontent.com/${owner}/${repo}/main`,
      };
    }
  }
  return {author: parsed.hostname + parsed.pathname, url: value};
};

const getManifestUrl = (source: VegaPluginSource) => `${source.url.replace(/\/+$/, '')}/manifest.json`;


class VegaPluginManager {
  private installed: VegaPluginManifest[] = mainStorage.getArray<VegaPluginManifest>(INSTALLED_KEY) || [];
  private modules: Record<string, VegaPluginModule> = mainStorage.getObject<Record<string, VegaPluginModule>>(MODULE_KEY) || {};
  private enabled: Record<string, boolean> = mainStorage.getObject<Record<string, boolean>>(ENABLED_KEY) || {};

  getSource(): VegaPluginSource | undefined {
    const source = mainStorage.getObject<VegaPluginSource>(SOURCE_KEY);
    return source?.url ? source : undefined;
  }

  setSource(input: string): VegaPluginSource {
    const source = normalizeSource(input);
    mainStorage.setObject(SOURCE_KEY, source);
    return source;
  }

  listInstalled(): VegaPluginManifest[] {
    return this.installed.map(item => ({...item, installed: true, disabled: !this.isEnabled(item.value)}));
  }

  isEnabled(value: string): boolean {
    return this.enabled[value] !== false;
  }

  setEnabled(value: string, enabled: boolean): void {
    this.enabled[value] = enabled;
    mainStorage.setObject(ENABLED_KEY, this.enabled);
  }

  async fetchAvailable(sourceInput?: string, force = true): Promise<VegaPluginManifest[]> {
    const source = sourceInput ? this.setSource(sourceInput) : this.getSource();
    if (!source) throw new Error('Configure a Vega provider repository first.');
    const response = await axios.get(getManifestUrl(source), {timeout: 15000});
    if (!Array.isArray(response.data)) throw new Error('Invalid Vega provider manifest.');
    return response.data
      .filter((item: any) => item && item.value && item.display_name && !item.disabled)
      .map((item: any) => ({
        display_name: String(item.display_name),
        value: String(item.value),
        version: String(item.version || '1.0.0'),
        icon: item.icon ? String(item.icon) : '',
        type: item.type || 'global',
        disabled: Boolean(item.disabled),
        source,
        installed: this.installed.some(p => p.value === item.value && p.source.author === source.author),
      }));
  }

  async install(plugin: VegaPluginManifest): Promise<void> {
    await this.downloadModules(plugin);
    this.installed = [
      ...this.installed.filter(p => !(p.value === plugin.value && p.source.author === plugin.source.author)),
      {...plugin, installed: true, disabled: false},
    ];
    this.enabled[plugin.value] = true;
    this.persist();
  }

  async refresh(plugin: VegaPluginManifest): Promise<void> {
    await this.downloadModules(plugin);
    this.installed = this.installed.map(item =>
      item.value === plugin.value && item.source.author === plugin.source.author
        ? {...plugin, installed: true, disabled: !this.isEnabled(plugin.value)}
        : item,
    );
    this.persist();
  }

  remove(value: string, author?: string): void {
    mainStorage.delete(settingsStorageKey(value));
    this.clearProviderStorage(value);
    this.installed = this.installed.filter(item => !(item.value === value && (!author || item.source.author === author)));
    delete this.modules[this.moduleKey(value, author)];
    delete this.enabled[value];
    this.persist();
  }

  getInstalledSources(): VegaPluginManifest[] {
    return this.listInstalled().filter(item => this.isEnabled(item.value));
  }

  getPlugin(value: string): VegaPluginManifest | undefined {
    return this.installed.find(item => item.value === value);
  }

  private moduleKey(value: string, author?: string) {
    return `${author || this.getPlugin(value)?.source.author || 'unknown'}:${value}`;
  }

  private async downloadModules(plugin: VegaPluginManifest): Promise<void> {
    const base = `${plugin.source.url.replace(/\/+$/, '')}/dist/${encodeURIComponent(plugin.value)}`;
    const names = ['posts', 'meta', 'stream', 'catalog', 'episodes', 'settings'];
    const modules: Record<string, string | undefined> = {};
    await Promise.all(names.map(async name => {
      try {
        const response = await axios.get(`${base}/${name}.js`, {timeout: 20000, responseType: 'text'});
        if (typeof response.data === 'string' && response.data.trim()) modules[name] = response.data;
      } catch (error) {
        if (['posts', 'meta', 'stream', 'catalog'].includes(name)) throw new Error(`Failed to download ${name}.js for ${plugin.display_name}.`);
      }
    }));
    for (const required of ['posts', 'meta', 'stream', 'catalog']) {
      if (!modules[required]) throw new Error(`Vega plugin ${plugin.display_name} is missing ${required}.js.`);
    }
    this.modules[this.moduleKey(plugin.value, plugin.source.author)] = {
      value: plugin.value,
      sourceAuthor: plugin.source.author,
      version: plugin.version,
      modules,
      cachedAt: Date.now(),
    };
    this.persist();
  }

  private getModule(value: string): VegaPluginModule {
    const plugin = this.getPlugin(value);
    if (!plugin) throw new Error(`Vega plugin not installed: ${value}`);
    const module = this.modules[this.moduleKey(value, plugin.source.author)];
    if (!module) throw new Error(`Vega plugin modules are not installed: ${value}`);
    return module;
  }

  private execute(code: string, args: Record<string, unknown> = {}): any {
    const module = {exports: {}} as any;
    const exports = module.exports;
    const require = (name: string) => {
      const normalized = String(name || '').toLowerCase();
      if (normalized === 'axios' || normalized.endsWith('/axios')) return {default: axios, ...axios};
      if (normalized.includes('cheerio')) return {default: providerContext.cheerio, ...providerContext.cheerio};
      if (normalized.includes('providercontext') || normalized.includes('provider-context')) return {providerContext, default: providerContext, ...providerContext};
      if (normalized.includes('crypto')) return {default: providerContext.Crypto, ...providerContext.Crypto};
      return {};
    };
    const fn = new Function('exports', 'module', 'require', 'console', 'Promise', 'Object', `${code}\n//# sourceURL=streamx-vega-plugin.js`);
    fn(exports, module, require, console, Promise, Object);
    return module.exports;
  }

  getSettings(value: string): Record<string, unknown> {
    return mainStorage.getObject<Record<string, unknown>>(settingsStorageKey(value)) || {};
  }

  saveSettings(value: string, settings: Record<string, unknown>): void {
    mainStorage.setObject(settingsStorageKey(value), settings);
  }

  async testProvider(value: string): Promise<VegaPluginTestResult> {
    const stages: VegaPluginTestResult['stages'] = [];
    let catalogs: Catalog[] = [];
    let posts: Post[] = [];
    try {
      catalogs = await this.getCatalog(value);
      stages.push({name: 'Catalog', passed: catalogs.length > 0, detail: `${catalogs.length} catalog(s) found`});
    } catch (error) {
      stages.push({name: 'Catalog', passed: false, detail: error instanceof Error ? error.message : 'Catalog request failed'});
    }
    if (catalogs.length > 0) {
      try {
        posts = await this.getPosts(value, catalogs[0].filter, 1, new AbortController().signal);
        stages.push({name: 'Posts', passed: posts.length > 0, detail: `${posts.length} item(s) returned`});
      } catch (error) {
        stages.push({name: 'Posts', passed: false, detail: error instanceof Error ? error.message : 'Posts request failed'});
      }
    } else {
      stages.push({name: 'Posts', passed: false, detail: 'Skipped because no catalog was available'});
    }
    if (posts[0]?.link) {
      try {
        const info = await this.getMetaData(value, posts[0].link);
        stages.push({name: 'Metadata', passed: Boolean(info.title || info.synopsis || info.linkList?.length), detail: info.title ? `Loaded “${info.title}”` : 'Metadata response received'});
        const sourceLink = (info.linkList || []).flatMap(item => item.directLinks || []).find(item => item?.link)?.link
          || (info.linkList || []).find(item => item?.episodesLink)?.episodesLink;
        if (sourceLink) {
          try {
            const streams = await this.getStream(value, sourceLink, info.type || 'movie');
            stages.push({name: 'Streams', passed: streams.length > 0, detail: `${streams.length} playable stream(s) returned`});
          } catch (error) {
            stages.push({name: 'Streams', passed: false, detail: error instanceof Error ? error.message : 'Stream request failed'});
          }
        } else {
          stages.push({name: 'Streams', passed: false, detail: 'No stream/episode URL was exposed by metadata'});
        }
      } catch (error) {
        stages.push({name: 'Metadata', passed: false, detail: error instanceof Error ? error.message : 'Metadata request failed'});
      }
    } else {
      stages.push({name: 'Metadata', passed: false, detail: 'Skipped because no catalog item was returned'});
      stages.push({name: 'Streams', passed: false, detail: 'Skipped because no catalog item was returned'});
    }
    return {passed: stages.length > 0 && stages.every(stage => stage.passed), stages};
  }

  private async call(value: string, file: string, fnName: string, args: Record<string, unknown>): Promise<any> {
    const module = this.getModule(value);
    const code = module.modules[file];
    if (!code) throw new Error(`Vega plugin ${value} does not provide ${file}.js.`);
    const provider = this.getPlugin(value)!;
    const context = {
      ...providerContext,
      kvStore: this.createKvStore(value),
      settings: this.getSettings(value),
    };
    const moduleExports = this.execute(code, args);
    const fn = moduleExports[fnName];
    if (typeof fn !== 'function') throw new Error(`Vega plugin ${value} does not export ${fnName}.`);
    const signal = args.signal as AbortSignal | undefined;
    if (signal?.aborted) { const error = new Error('Aborted'); error.name = 'AbortError'; throw error; }
    let timeoutId: ReturnType<typeof setTimeout> | undefined;
    const timeoutMs = file === 'stream' ? 18000 : 12000;
    const timeoutPromise = new Promise<never>((_, reject) => {
      timeoutId = setTimeout(() => reject(new Error(`Vega plugin ${value} ${file} request timed out.`)), timeoutMs);
    });
    try {
      return await Promise.race([
        Promise.resolve().then(() => fn({...args, settings: this.getSettings(value), providerContext: context, providerValue: value})),
        timeoutPromise,
      ]);
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
    }
  }

  private createKvStore(value: string) {
    const instance = `vega-plugin-${value.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    const kv = new MMKVLoader().withInstanceID(instance).initialize();
    const keysKey = '__streamx_keys__';
    const readKeys = (): string[] => {
      try { return JSON.parse(kv.getString(keysKey) || '[]'); } catch { return []; }
    };
    const writeKey = (key: string) => {
      const keys = readKeys();
      if (!keys.includes(key)) kv.setString(keysKey, JSON.stringify([...keys, key]));
    };
    return {
      get: async <T = unknown>(key: string) => {
        const raw = kv.getString(key);
        if (raw == null) return undefined as T | undefined;
        try { return JSON.parse(raw) as T; } catch { return raw as T; }
      },
      set: async (key: string, val: unknown) => { writeKey(key); kv.setString(key, JSON.stringify(val)); },
      delete: async (key: string) => { const existed = kv.getString(key) != null; kv.removeItem(key); return existed; },
      keys: async () => readKeys().filter(key => key !== keysKey),
      clear: async () => kv.clearStore(),
    };
  }

  async getCatalog(value: string): Promise<Catalog[]> {
    const mod = this.getModule(value);
    const code = mod.modules.catalog;
    if (!code) return [];
    const exports = this.execute(code);
    return Array.isArray(exports.catalog) ? exports.catalog : [];
  }

  async getGenres(value: string): Promise<Catalog[]> {
    const mod = this.getModule(value);
    const code = mod.modules.catalog;
    if (!code) return [];
    const exports = this.execute(code);
    return Array.isArray(exports.genres) ? exports.genres : [];
  }

  getPosts(value: string, filter: string, page: number, signal: AbortSignal): Promise<Post[]> {
    return this.call(value, 'posts', 'getPosts', {filter, page, signal});
  }

  getSearchPosts(value: string, searchQuery: string, page: number, signal: AbortSignal): Promise<Post[]> {
    return this.call(value, 'posts', 'getSearchPosts', {searchQuery, page, signal});
  }

  async getMetaData(value: string, link: string): Promise<Info> {
    const raw = await this.call(value, 'meta', 'getMeta', {link});
    if (!raw || typeof raw !== 'object') throw new Error('Vega plugin returned invalid metadata.');
    const sourceType = String(raw.type || 'movie').toLowerCase();
    const linkList = Array.isArray(raw.linkList) ? raw.linkList : (Array.isArray(raw.links) ? raw.links : []);
    const normalizedLinks = linkList.map((item: any) => {
      if (!item || typeof item !== 'object') return null;
      const title = String(item.title || item.name || 'Play');
      const direct = Array.isArray(item.directLinks) ? item.directLinks
        .map((entry: any) => entry && typeof entry === 'object' ? ({...entry, title: String(entry.title || title), link: String(entry.link || entry.url || entry.externalUrl || '').trim(), type: entry.type || item.type || sourceType}) : null)
        .filter((entry: any) => entry && entry.link) : [];
      const directUrl = typeof item.link === 'string' ? item.link : (typeof item.url === 'string' ? item.url : '');
      const directLinks = direct.length ? direct : (directUrl.trim() ? [{title, link: directUrl.trim(), type: item.type || sourceType}] : undefined);
      return { ...item, title, directLinks, episodesLink: item.episodesLink || item.episodesUrl || undefined };
    }).filter(Boolean);
    return {
      ...raw,
      title: String(raw.title || ''),
      synopsis: String(raw.synopsis || raw.description || ''),
      image: String(raw.image || raw.background || raw.poster || ''),
      type: sourceType,
      linkList: normalizedLinks as Info['linkList'],
    } as Info;
  }

  async getStream(value: string, link: string, type: string, signal?: AbortSignal, isDownload?: boolean, _forceRefresh = false): Promise<Stream[]> {
    if (signal?.aborted) { const error = new Error('Aborted'); error.name = 'AbortError'; throw error; }
    if (typeof link !== 'string' || !link.trim()) return [];
    const result = await this.call(value, 'stream', 'getStream', {link: link.trim(), type, signal, isDownload});
    if (signal?.aborted) { const error = new Error('Aborted'); error.name = 'AbortError'; throw error; }
    const candidates = Array.isArray(result) ? result : Array.isArray(result?.streams) ? result.streams : (result && typeof result === 'object' ? [result] : []);
    const plugin = this.getPlugin(value);
    const output: Stream[] = [];
    const seen = new Set<string>();
    for (const candidate of candidates) {
      if (!candidate || typeof candidate !== 'object') continue;
      const streamLink = String(candidate.link || candidate.url || candidate.externalUrl || candidate.fileUrl || '').trim();
      const normalized = {
        ...candidate,
        server: String(candidate.server || candidate.provider || plugin?.display_name || value),
        link: streamLink,
        type: String(candidate.type || candidate.mimeType || 'video/mp4'),
      } as Stream;
      if (!isPotentiallyPlayableStream(normalized)) continue;
      const key = `${normalized.server}|${normalized.link}|${normalized.quality || ''}`;
      if (seen.has(key)) continue;
      seen.add(key);
      output.push(normalized);
    }
    return output;
  }

  async getEpisodes(value: string, url: string, signal?: AbortSignal): Promise<EpisodeLink[]> {
    const result = await this.call(value, 'episodes', 'getEpisodes', {url, signal});
    if (signal?.aborted) {
      const error = new Error('Aborted');
      error.name = 'AbortError';
      throw error;
    }
    // Third-party Vega plugins do not all return the same envelope. Accept
    // common episode-array shapes and normalize fields before rendering.
    const rows = Array.isArray(result)
      ? result
      : Array.isArray(result?.episodes)
        ? result.episodes
        : Array.isArray(result?.items)
          ? result.items
          : Array.isArray(result?.data)
            ? result.data
            : [];
    const normalized: EpisodeLink[] = [];
    const seen = new Set<string>();
    for (const raw of rows) {
      if (!raw || typeof raw !== 'object') continue;
      const link = String(raw.link || raw.url || raw.streamUrl || '').trim();
      const title = String(raw.title || raw.name || raw.episodeTitle || '').trim();
      if (!link || !title) continue;
      const seasonRaw = raw.season ?? raw.seasonNumber ?? raw.season_number;
      const episodeRaw = raw.episode ?? raw.episodeNumber ?? raw.episode_number;
      const seasonNum = seasonRaw === undefined || seasonRaw === null || seasonRaw === '' ? undefined : Number(seasonRaw);
      const episodeNum = episodeRaw === undefined || episodeRaw === null || episodeRaw === '' ? undefined : Number(episodeRaw);
      const item: EpisodeLink = {
        id: raw.id === undefined ? undefined : String(raw.id),
        title,
        link,
        sourceLink: raw.sourceLink ? String(raw.sourceLink) : undefined,
        description: raw.description || raw.synopsis ? String(raw.description || raw.synopsis) : undefined,
        image: raw.image || raw.thumbnail || raw.poster ? String(raw.image || raw.thumbnail || raw.poster) : undefined,
        season: seasonNum !== undefined && Number.isFinite(seasonNum) && seasonNum >= 0 ? seasonNum : undefined,
        episode: episodeNum !== undefined && Number.isFinite(episodeNum) && episodeNum >= 0 ? episodeNum : undefined,
        quickDownload: Boolean(raw.quickDownload ?? raw.quick_download),
        skip: Array.isArray(raw.skip) ? raw.skip : undefined,
      };
      const key = `${item.season ?? ''}|${item.episode ?? ''}|${item.title.toLowerCase()}|${item.link}`;
      if (seen.has(key)) continue;
      seen.add(key);
      normalized.push(item);
    }
    return normalized;
  }

  async getSettingsSchema(value: string): Promise<SettingsField[]> {
    const module = this.getModule(value);
    if (!module.modules.settings) return [];
    return this.call(value, 'settings', 'getSettingsSchema', {});
  }

  clearProviderStorage(value: string): void {
    mainStorage.delete(settingsStorageKey(value));
    const instance = `vega-plugin-${value.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    try { new MMKVLoader().withInstanceID(instance).initialize().clearStore(); } catch {}
  }

  private persist() {
    mainStorage.setArray(INSTALLED_KEY, this.installed);
    mainStorage.setObject(MODULE_KEY, this.modules);
    mainStorage.setObject(ENABLED_KEY, this.enabled);
  }
}

export const vegaPluginManager = new VegaPluginManager();
export default vegaPluginManager;

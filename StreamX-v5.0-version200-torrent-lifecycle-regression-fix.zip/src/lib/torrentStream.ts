/** Torrent-specific helpers shared by player code and regression tests. */
export const isTorrentStream = (stream?: {link?: string; type?: string}) =>
  stream?.type === 'torrent' || Boolean(stream?.link?.startsWith('magnet:'));

export const isDummyTorrentLink = (link: string) =>
  !link ||
  link.includes('d41d0cfbf8baa3ce04a7074b0c486243dd5fbd00') ||
  link.includes('d41d8cd98f00b204e9800998ecf8427e');

export interface ResolveTorrentStreamOptions {
  addTorrent: (link: string) => Promise<{infoHash: string}>;
  findVideoFileIndex: (infoHash: string) => Promise<number>;
  prepareVideoFile: (infoHash: string, fileIndex: number) => Promise<unknown>;
  getStreamUrl: (infoHash: string, fileIndex: number) => Promise<string>;
  onAdded: (infoHash: string) => void;
  isCancelled: () => boolean;
}

/**
 * Resolves the local stream URL without waiting for the first piece. Vega's
 * stream server fetches/prioritizes pieces in response to the player's HTTP
 * range requests; awaiting prepareVideoFile first can deadlock startup because
 * the player has not yet been given a URL to request.
 */
export async function resolveTorrentStream(
  link: string,
  options: ResolveTorrentStreamOptions,
): Promise<{streamUrl: string; preparation: Promise<unknown>} | null> {
  const torrent = await options.addTorrent(link);
  if (options.isCancelled()) return null;
  options.onAdded(torrent.infoHash);

  const fileIndex = await options.findVideoFileIndex(torrent.infoHash);
  if (options.isCancelled()) return null;

  // Start priority preparation, but do not wait for the first-piece promise
  // before obtaining the URL. Attach a rejection handler immediately.
  const preparation = options.prepareVideoFile(torrent.infoHash, fileIndex);
  preparation.catch(() => {});
  const streamUrl = await options.getStreamUrl(torrent.infoHash, fileIndex);
  if (options.isCancelled()) {
    preparation.catch(() => {});
    return null;
  }
  return {streamUrl, preparation};
}

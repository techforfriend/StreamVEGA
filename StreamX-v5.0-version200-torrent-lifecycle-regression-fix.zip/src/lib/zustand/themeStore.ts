import {create} from 'zustand';
import {persist, createJSONStorage} from 'zustand/middleware';
import {MMKVLoader} from 'react-native-mmkv-storage';
import {settingsStorage} from '../storage';

const storage = new MMKVLoader().initialize();

export type AccentSource = 'wallpaper' | 'custom';

export interface Theme {
  primary: string;
  isCustom: boolean;
  /** Where the Material 3 palette comes from: the device wallpaper or a curated seed. */
  source: AccentSource;
  setPrimary: (type: Theme['primary']) => void;
  setCustom: (isCustom: boolean) => void;
  setSource: (source: AccentSource) => void;
}

const useThemeStore = create<Theme>()(
  persist(
    set => ({
      primary: settingsStorage.getPrimaryColor(),
      isCustom: settingsStorage.isCustomTheme(),
      source: settingsStorage.getAccentSource(),

      setPrimary: (primary: Theme['primary']) => {
        set({primary});
        settingsStorage.setPrimaryColor(primary);
      },
      setCustom: (isCustom: Theme['isCustom']) => {
        set({isCustom});
        settingsStorage.setCustomTheme(isCustom);
      },
      setSource: (source: AccentSource) => {
        set({source});
        settingsStorage.setAccentSource(source);
      },
    }),
    {
      name: 'theme-storage',
      //@ts-expect-error
      storage: createJSONStorage(() => storage),
      // Older builds persisted `source: custom` even when the user had never
      // chosen an accent. Respect an explicit choice, otherwise migrate the
      // effective default to Android Monet when the platform supports it.
      merge: (persistedState, currentState) => {
        const persisted = (persistedState ?? {}) as Partial<Theme>;
        const source = settingsStorage.hasExplicitAccentSource()
          ? settingsStorage.getAccentSource()
          : currentState.source;
        return {...currentState, ...persisted, source};
      },
    },
  ),
);

export default useThemeStore;

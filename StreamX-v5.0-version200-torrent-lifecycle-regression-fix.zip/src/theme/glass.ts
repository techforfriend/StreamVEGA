/**
 * Return a Material/React Native hex color with a controlled alpha channel.
 * Expo UI's Material 3 palette can return #RRGGBBAA, while legacy/custom seed
 * colors are often #RRGGBB; support both and replace (rather than append) the
 * alpha byte so colors never become invalid 10-digit hex strings.
 */
export const withAlpha = (color: string, opacity: number): string => {
  const match = /^#([0-9a-f]{6})(?:[0-9a-f]{2})?$/i.exec(color.trim());
  if (!match) return color;
  const alpha = Math.round(Math.max(0, Math.min(1, opacity)) * 255)
    .toString(16)
    .padStart(2, '0');
  return `#${match[1]}${alpha}`;
};

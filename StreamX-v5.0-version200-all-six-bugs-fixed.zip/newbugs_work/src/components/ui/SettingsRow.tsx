import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import React, {ReactNode} from 'react';
import {TouchableOpacity, View} from 'react-native';
import {useM3Colors} from '../../theme/M3PaletteContext';
import AppText from './Text';

interface SettingsRowProps {
  title: string;
  description?: string;
  icon?: React.ComponentProps<typeof MaterialCommunityIcons>['name'];
  onPress?: () => void;
  trailing?: ReactNode;
  divider?: boolean;
  descriptionNumberOfLines?: number;
  descriptionSelectable?: boolean;
}

const SettingsRow = ({
  title,
  description,
  icon,
  onPress,
  trailing,
  divider = true,
  descriptionNumberOfLines = 2,
  descriptionSelectable = false,
}: SettingsRowProps) => {
  const colors = useM3Colors();

  return (
    <TouchableOpacity
      accessibilityRole={onPress ? 'button' : undefined}
      activeOpacity={0.68}
      disabled={!onPress}
      hitSlop={{top: 4, bottom: 4, left: 0, right: 0}}
      onPress={onPress}>
      <View
        style={{
          minHeight: description ? 70 : 58,
          flexDirection: 'row',
          alignItems: 'center',
          paddingHorizontal: 12,
          paddingVertical: 7,
          borderBottomColor: colors.outlineVariant,
          borderBottomWidth: divider ? 1 : 0,
        }}>
        {icon ? (
          <View
            style={{
              width: 40,
              height: 40,
              marginRight: 11,
              borderRadius: 13,
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: colors.primaryContainer,
            }}>
            <MaterialCommunityIcons
              name={icon}
              size={21}
              color={colors.primary}
              pointerEvents="none"
            />
          </View>
        ) : null}
        <View style={{marginRight: 8, minWidth: 0, flex: 1}}>
          <AppText
            role="bodyLargeEmphasized"
            numberOfLines={2}
            style={{color: colors.onSurface}}>
            {title}
          </AppText>
          {description ? (
            <AppText
              role="bodySmall"
              numberOfLines={descriptionNumberOfLines}
              selectable={descriptionSelectable}
              style={{color: colors.onSurfaceVariant, marginTop: 1}}>
              {description}
            </AppText>
          ) : null}
        </View>
        {trailing}
      </View>
    </TouchableOpacity>
  );
};

export default SettingsRow;

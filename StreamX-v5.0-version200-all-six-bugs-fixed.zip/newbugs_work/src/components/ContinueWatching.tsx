import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, Image, TouchableOpacity, View } from 'react-native';
import ReactNativeHapticFeedback, {
  HapticFeedbackTypes,
} from 'react-native-haptic-feedback';
import type { HomeStackParamList } from '../App';
import { useImageAccent } from '../lib/hooks/useImageAccent';
import { settingsStorage } from '../lib/storage';
import { showAppDialog } from '../lib/zustand/appDialogStore';
import useContinueWatchingStore, {
  type ContinueWatchingItem,
} from '../lib/zustand/continueWatchingStore';
import { useM3Colors } from '../theme/M3PaletteContext';
import AppText from './ui/Text';

interface ContinueWatchingCardProps {
  item: ContinueWatchingItem;
  selected?: boolean;
  selectionMode?: boolean;
  onOpen: (item: ContinueWatchingItem) => void;
  onLongPress: (item: ContinueWatchingItem) => void;
}

const ContinueWatchingCard = React.memo(({
  item,
  selected = false,
  selectionMode = false,
  onOpen,
  onLongPress,
}: ContinueWatchingCardProps) => {
  const colors = useM3Colors();
  const poster = item.poster || item.background;
  const episodeTitle =
    item.episodeTitle ||
    (item.episode?.title && item.episode.title !== item.title
      ? item.episode.title
      : undefined);
  const progressColor = useImageAccent(poster, colors.primary);
  const progress =
    item.duration > 0
      ? Math.min(100, Math.max(0, (item.position / item.duration) * 100))
      : 0;
  const remainingSeconds = Math.max(0, item.duration - item.position);
  const remainingLabel =
    remainingSeconds >= 3600
      ? `${Math.ceil(remainingSeconds / 3600)}h left`
      : `${Math.max(1, Math.ceil(remainingSeconds / 60))}m left`;

  return (
    <TouchableOpacity
      activeOpacity={0.78}
      accessibilityRole="button"
      accessibilityState={{selected}}
      onPress={() => onOpen(item)}
      onLongPress={() => onLongPress(item)}
      style={{
        backgroundColor: selected
          ? colors.secondaryContainer
          : colors.surfaceContainer,
        borderColor: selected ? colors.primary : colors.outlineVariant,
        borderRadius: 20,
        borderWidth: 1,
        flexDirection: 'row',
        height: 100,
        overflow: 'hidden',
        width: 258,
        elevation: 2,
      }}>
      {poster ? (
        <Image
          source={{uri: poster}}
          resizeMode="cover"
          style={{
            backgroundColor: colors.surfaceContainerHighest,
            height: 98,
            width: 70,
          }}
        />
      ) : (
        <View
          style={{
            alignItems: 'center',
            backgroundColor: colors.surfaceContainerHighest,
            height: 98,
            justifyContent: 'center',
            width: 70,
          }}>
          <MaterialCommunityIcons
            name="movie-open-outline"
            size={28}
            color={colors.onSurfaceVariant}
          />
        </View>
      )}
      <View style={{flex: 1, minWidth: 0, paddingHorizontal: 10, paddingVertical: 8}}>
        <AppText
          role="titleMediumEmphasized"
          numberOfLines={2}
          style={{color: colors.onSurface, fontSize: 14, lineHeight: 18}}>
          {item.title}
        </AppText>
        {episodeTitle ? (
          <AppText
            role="bodySmall"
            numberOfLines={1}
            style={{color: colors.onSurfaceVariant, fontSize: 12, lineHeight: 15, marginTop: 2}}>
            {episodeTitle}
          </AppText>
        ) : null}
        <View
          style={{
            backgroundColor: colors.surfaceContainerHighest,
            borderRadius: 3,
            height: 4,
            marginTop: 'auto',
            overflow: 'hidden',
          }}>
          <View
            style={{
              backgroundColor: progressColor,
              height: 4,
              width: `${progress}%`,
            }}
          />
        </View>
        <AppText
          role="labelSmall"
          numberOfLines={1}
          style={{color: colors.onSurfaceVariant, fontSize: 11, lineHeight: 14, marginTop: 4}}>
          {progress >= 98 ? 'Almost finished' : remainingLabel}
        </AppText>
      </View>
      {selectionMode && selected ? (
        <View
          style={{
            alignItems: 'center',
            backgroundColor: colors.primary,
            borderRadius: 12,
            height: 24,
            justifyContent: 'center',
            position: 'absolute',
            right: 8,
            top: 8,
            width: 24,
          }}>
          <MaterialCommunityIcons name="check" size={16} color={colors.onPrimary} />
        </View>
      ) : null}
    </TouchableOpacity>
  );
});

ContinueWatchingCard.displayName = 'ContinueWatchingCard';


const ContinueWatchingSeparator = React.memo(() => <View style={{width: 14}} />);
ContinueWatchingSeparator.displayName = 'ContinueWatchingSeparator';

const ContinueWatching = () => {
  const colors = useM3Colors();
  const navigation =
    useNavigation<NativeStackNavigationProp<HomeStackParamList>>();
  const storedItems = useContinueWatchingStore(state => state.items);
  const removeItem = useContinueWatchingStore(state => state.removeItem);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const isSelectionMode = selectedIds.size > 0;

  const items = useMemo(
    () =>
      storedItems
        .filter(
          (item): item is ContinueWatchingItem => Boolean(item.providerValue),
        )
        .sort((a, b) => b.updatedAt - a.updatedAt),
    [storedItems],
  );

  const triggerHaptic = useCallback(
    (type: HapticFeedbackTypes = HapticFeedbackTypes.effectTick) => {
      if (settingsStorage.isHapticFeedbackEnabled()) {
        ReactNativeHapticFeedback.trigger(type, {
          enableVibrateFallback: true,
          ignoreAndroidSystemSettings: false,
        });
      }
    },
    [],
  );

  const handleCardPress = useCallback(
    (item: ContinueWatchingItem) => {
      if (isSelectionMode) {
        triggerHaptic(HapticFeedbackTypes.effectTick);
        setSelectedIds(prev => {
          const next = new Set(prev);
          if (next.has(item.id)) {
            next.delete(item.id);
          } else {
            next.add(item.id);
          }
          return next;
        });
      } else {
        navigation.navigate('Info', {
          link: item.infoUrl,
          provider: item.providerValue,
          poster: item.poster || item.background,
        });
      }
    },
    [isSelectionMode, navigation, triggerHaptic],
  );

  const handleCardLongPress = useCallback(
    (item: ContinueWatchingItem) => {
      triggerHaptic(HapticFeedbackTypes.impactMedium);
      setSelectedIds(prev => {
        const next = new Set(prev);
        if (next.has(item.id)) {
          next.delete(item.id);
        } else {
          next.add(item.id);
        }
        return next;
      });
    },
    [triggerHaptic],
  );

  const handleExitSelection = useCallback(() => {
    triggerHaptic(HapticFeedbackTypes.effectClick);
    setSelectedIds(new Set());
  }, [triggerHaptic]);

  const handleToggleSelectAll = useCallback(() => {
    triggerHaptic(HapticFeedbackTypes.effectClick);
    if (selectedIds.size === items.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(items.map(item => item.id)));
    }
  }, [items, selectedIds.size, triggerHaptic]);

  const handleDeletePress = useCallback(() => {
    if (selectedIds.size === 0) return;

    triggerHaptic(HapticFeedbackTypes.effectHeavyClick);
    const count = selectedIds.size;

    showAppDialog({
      title: `Clear History?`,
      message: `Are you sure you want to remove ${count} ${count === 1 ? 'title' : 'titles'
        } from your continue watching history?`,
      variant: 'warning',
      actions: [
        { label: 'Cancel' },
        {
          label: 'Clear',
          variant: 'destructive',
          onPress: () => {
            selectedIds.forEach(id => {
              removeItem(id);
            });
            setSelectedIds(new Set());
          },
        },
      ],
    });
  }, [selectedIds, removeItem, triggerHaptic]);

  if (items.length === 0) {
    return null;
  }

  const isAllSelected = items.length > 0 && selectedIds.size === items.length;

  return (
    <View style={{ gap: 13, marginTop: 24 }}>
      <View
        style={{
          alignItems: 'center',
          flexDirection: 'row',
          justifyContent: 'space-between',
          paddingHorizontal: 18,
        }}>
        {isSelectionMode ? (
          <View
            style={{
              alignItems: 'center',
              flexDirection: 'row',
              gap: 8,
              flex: 1,
              marginRight: 8,
            }}>
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={handleExitSelection}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <MaterialCommunityIcons
                name="close"
                size={22}
                color={colors.onBackground}
              />
            </TouchableOpacity>
            <AppText
              role="titleLargeEmphasized"
              numberOfLines={1}
              style={{ color: colors.onBackground, flex: 1 }}>
              Continue watching
            </AppText>
          </View>
        ) : (
          <AppText
            role="titleLargeEmphasized"
            numberOfLines={1}
            style={{ color: colors.onBackground, flex: 1 }}>
            Continue watching
          </AppText>
        )}

        {/* Delete button where the see all button appears in slider */}
        {isSelectionMode ? (
          <View style={{ alignItems: 'center', flexDirection: 'row', gap: 6 }}>
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={handleToggleSelectAll}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              style={{
                alignItems: 'center',
                justifyContent: 'center',
                padding: 6,
              }}>
              <MaterialIcons
                name="select-all"
                size={22}
                color={isAllSelected ? colors.primary : colors.onSurfaceVariant}
              />
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={0.75}
              disabled={selectedIds.size === 0}
              onPress={handleDeletePress}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              style={{
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: colors.errorContainer,
                borderRadius: 10,
                width: 32,
                height: 32,
              }}>
              <MaterialCommunityIcons
                name="trash-can-outline"
                size={18}
                color={colors.onErrorContainer}
              />
            </TouchableOpacity>
          </View>
        ) : null}
      </View>

      <FlatList
        horizontal
        data={items}
        keyExtractor={item => item.id}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 4 }}
        ItemSeparatorComponent={ContinueWatchingSeparator}
        getItemLayout={(_, index) => ({length: 272, offset: 272 * index, index})}
        initialNumToRender={4}
        maxToRenderPerBatch={4}
        windowSize={5}
        removeClippedSubviews
        renderItem={({ item }) => (
          <ContinueWatchingCard
            item={item}
            selected={selectedIds.has(item.id)}
            selectionMode={isSelectionMode}
            onOpen={handleCardPress}
            onLongPress={handleCardLongPress}
          />
        )}
      />
    </View>
  );
};

export default ContinueWatching;
